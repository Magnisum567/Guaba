import { create } from 'zustand';
import type { MediaAsset } from '../types';
import { media as mediaApi } from '../api';

interface MediaState {
  assets: MediaAsset[];
  selectedAssetIds: Set<string>;
  previewAsset: MediaAsset | null;
  uploadProgress: Map<string, number>;
  isLoading: boolean;
  error: string | null;

  // Actions
  fetchMedia: (projectId: string) => Promise<void>;
  uploadMedia: (projectId: string, files: FileList | File[]) => Promise<void>;
  deleteMedia: (assetId: string) => Promise<void>;

  // Selection
  selectAsset: (assetId: string, multiSelect?: boolean) => void;
  deselectAsset: (assetId: string) => void;
  clearSelection: () => void;
  selectAll: () => void;
  toggleSelection: (assetId: string) => void;

  // Preview
  setPreviewAsset: (asset: MediaAsset | null) => void;

  // Utility
  getAssetById: (assetId: string) => MediaAsset | undefined;
  getSelectedAssets: () => MediaAsset[];
  clearError: () => void;
}

export const useMediaStore = create<MediaState>((set, get) => ({
  assets: [],
  selectedAssetIds: new Set(),
  previewAsset: null,
  uploadProgress: new Map(),
  isLoading: false,
  error: null,

  fetchMedia: async (projectId: string) => {
    set({ isLoading: true, error: null });
    try {
      const response = await mediaApi.list(projectId);
      set({ assets: response.data, isLoading: false });
    } catch (error: any) {
      set({
        isLoading: false,
        error: error.response?.data?.error || 'Failed to fetch media',
      });
    }
  },

  uploadMedia: async (projectId: string, files: FileList | File[]) => {
    set({ isLoading: true, error: null });
    const fileArray = Array.from(files);

    try {
      for (const file of fileArray) {
        const fileId = `${file.name}-${Date.now()}`;
        set((state) => ({
          uploadProgress: new Map(state.uploadProgress).set(fileId, 0),
        }));

        await mediaApi.upload(projectId, file);

        set((state) => {
          const newProgress = new Map(state.uploadProgress);
          newProgress.delete(fileId);
          return { uploadProgress: newProgress };
        });
      }

      // Refresh media list after uploads
      const response = await mediaApi.list(projectId);
      set({ assets: response.data, isLoading: false });
    } catch (error: any) {
      set({
        isLoading: false,
        error: error.response?.data?.error || 'Failed to upload media',
        uploadProgress: new Map(),
      });
      throw error;
    }
  },

  deleteMedia: async (assetId: string) => {
    try {
      await mediaApi.delete(assetId);
      set((state) => ({
        assets: state.assets.filter((a) => a.id !== assetId),
        selectedAssetIds: new Set(
          [...state.selectedAssetIds].filter((id) => id !== assetId)
        ),
        previewAsset:
          state.previewAsset?.id === assetId ? null : state.previewAsset,
      }));
    } catch (error: any) {
      set({ error: error.response?.data?.error || 'Failed to delete media' });
      throw error;
    }
  },

  selectAsset: (assetId: string, multiSelect = false) => {
    set((state) => {
      if (multiSelect) {
        const newSelection = new Set(state.selectedAssetIds);
        newSelection.add(assetId);
        return { selectedAssetIds: newSelection };
      }
      return { selectedAssetIds: new Set([assetId]) };
    });
  },

  deselectAsset: (assetId: string) => {
    set((state) => {
      const newSelection = new Set(state.selectedAssetIds);
      newSelection.delete(assetId);
      return { selectedAssetIds: newSelection };
    });
  },

  clearSelection: () => {
    set({ selectedAssetIds: new Set() });
  },

  selectAll: () => {
    set((state) => ({
      selectedAssetIds: new Set(state.assets.map((a) => a.id)),
    }));
  },

  toggleSelection: (assetId: string) => {
    set((state) => {
      const newSelection = new Set(state.selectedAssetIds);
      if (newSelection.has(assetId)) {
        newSelection.delete(assetId);
      } else {
        newSelection.add(assetId);
      }
      return { selectedAssetIds: newSelection };
    });
  },

  setPreviewAsset: (asset: MediaAsset | null) => {
    set({ previewAsset: asset });
  },

  getAssetById: (assetId: string) => {
    return get().assets.find((a) => a.id === assetId);
  },

  getSelectedAssets: () => {
    const { assets, selectedAssetIds } = get();
    return assets.filter((a) => selectedAssetIds.has(a.id));
  },

  clearError: () => {
    set({ error: null });
  },
}));
