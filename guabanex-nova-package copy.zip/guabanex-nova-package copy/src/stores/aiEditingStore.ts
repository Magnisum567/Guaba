import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  AIClipSuggestion,
  SceneBoundary,
  ClipMetadata,
  CutSuggestion,
  PacingAnalysis,
  PacingSuggestion,
  TransitionSuggestion,
  ContentContext,
  MediaAsset,
  Clip,
  ShotInfo,
} from '../types';

interface AIEditingState {
  // Suggestions
  clipSuggestions: AIClipSuggestion[];
  sceneBoundaries: SceneBoundary[];
  clipMetadata: Record<string, ClipMetadata>;
  cutSuggestions: CutSuggestion[];
  pacingAnalysis: PacingAnalysis | null;
  transitionSuggestions: TransitionSuggestion[];

  // Context
  contentContext: ContentContext | null;

  // Status
  isAnalyzing: boolean;
  analysisProgress: number;
  lastAnalyzedAt: string | null;

  // Actions
  analyzeMediaLibrary: (assets: MediaAsset[]) => Promise<void>;
  analyzeTimeline: (clips: Clip[], duration: number) => Promise<void>;
  generateClipSuggestions: (assets: MediaAsset[], existingClips: Clip[]) => Promise<void>;
  detectSceneBoundaries: (clips: Clip[]) => Promise<void>;
  analyzePacing: (clips: Clip[], duration: number) => Promise<void>;
  generateTransitionSuggestions: (clips: Clip[]) => Promise<void>;
  generateCutSuggestions: (clips: Clip[]) => Promise<void>;
  setContentContext: (context: ContentContext) => void;
  applyClipSuggestion: (suggestionId: string) => AIClipSuggestion | undefined;
  dismissSuggestion: (suggestionId: string) => void;
  clearSuggestions: () => void;
}

// Helper functions for generating intelligent suggestions
function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash);
}

const shotTypes: ShotInfo['type'][] = ['wide', 'medium', 'close-up', 'extreme-close-up', 'establishing', 'over-shoulder', 'pov', 'aerial'];
const movements: ShotInfo['movement'][] = ['static', 'pan', 'tilt', 'zoom', 'dolly', 'tracking', 'handheld', 'crane'];
const categories: AIClipSuggestion['category'][] = ['highlight', 'b-roll', 'transition', 'filler', 'opening', 'closing'];

const tagOptions = [
  ['action', 'dynamic', 'energetic', 'fast-paced'],
  ['calm', 'peaceful', 'serene', 'relaxing'],
  ['emotional', 'dramatic', 'intense', 'powerful'],
  ['funny', 'comedic', 'light-hearted', 'playful'],
  ['cinematic', 'artistic', 'stylized', 'beautiful'],
  ['documentary', 'authentic', 'real', 'candid'],
  ['urban', 'city', 'modern', 'metropolitan'],
  ['nature', 'outdoor', 'landscape', 'scenic'],
];

const reasonTemplates = {
  highlight: [
    'High visual interest with strong composition',
    'Peak emotional moment detected',
    'Key action sequence with good pacing',
    'Strong subject focus and clarity',
  ],
  'b-roll': [
    'Good supplementary footage for context',
    'Provides visual variety and texture',
    'Suitable for covering transitions',
    'Enhances narrative without dialogue',
  ],
  transition: [
    'Smooth motion for seamless transitions',
    'Visual elements align well with adjacent clips',
    'Good bridging content between scenes',
    'Natural flow from previous shot type',
  ],
  filler: [
    'Extends sequence without disrupting pace',
    'Maintains visual continuity',
    'Good backup option for timeline gaps',
    'Flexible placement options',
  ],
  opening: [
    'Strong establishing presence',
    'Sets tone effectively for the sequence',
    'Engaging hook for viewer attention',
    'Clear visual introduction',
  ],
  closing: [
    'Natural conclusion feel',
    'Provides satisfying visual closure',
    'Emotional resolution point',
    'Good fade-out potential',
  ],
};

function generateClipMetadata(assetId: string, asset?: MediaAsset): ClipMetadata {
  const hash = hashString(assetId);
  const tagSet = tagOptions[hash % tagOptions.length];

  return {
    mediaAssetId: assetId,
    tags: tagSet.slice(0, 2 + (hash % 3)),
    emotions: [
      { emotion: ['happy', 'sad', 'excited', 'calm', 'tense'][hash % 5], intensity: 0.5 + (hash % 50) / 100, timestamp: 0 },
      { emotion: ['curious', 'surprised', 'neutral', 'engaged'][hash % 4], intensity: 0.3 + (hash % 40) / 100, timestamp: (asset?.duration || 30) / 2 },
    ],
    shotType: shotTypes[hash % shotTypes.length],
    movement: movements[hash % movements.length],
    people: hash % 4,
    objects: ['person', 'building', 'vehicle', 'nature', 'furniture', 'technology'].slice(0, 2 + (hash % 3)),
    setting: ['indoor', 'outdoor', 'urban', 'rural', 'studio'][hash % 5],
    lighting: (['natural', 'artificial', 'mixed', 'low-key', 'high-key'] as const)[hash % 5],
    audio: {
      hasDialogue: hash % 3 === 0,
      hasMusic: hash % 2 === 0,
      hasSoundEffects: hash % 4 === 0,
      loudness: -20 + (hash % 15),
      silencePercentage: (hash % 30) / 100,
    },
  };
}

function generateShotInfo(hash: number, duration: number): ShotInfo {
  return {
    type: shotTypes[hash % shotTypes.length],
    movement: movements[hash % movements.length],
    duration,
    description: `${shotTypes[hash % shotTypes.length]} shot with ${movements[hash % movements.length]} movement`,
  };
}

export const useAIEditingStore = create<AIEditingState>()(
  persist(
    (set, get) => ({
      clipSuggestions: [],
      sceneBoundaries: [],
      clipMetadata: {},
      cutSuggestions: [],
      pacingAnalysis: null,
      transitionSuggestions: [],
      contentContext: null,
      isAnalyzing: false,
      analysisProgress: 0,
      lastAnalyzedAt: null,

      analyzeMediaLibrary: async (assets: MediaAsset[]) => {
        set({ isAnalyzing: true, analysisProgress: 0 });

        const metadata: Record<string, ClipMetadata> = {};
        for (let i = 0; i < assets.length; i++) {
          const asset = assets[i];
          metadata[asset.id] = generateClipMetadata(asset.id, asset);
          set({ analysisProgress: ((i + 1) / assets.length) * 50 });
          await new Promise(r => setTimeout(r, 100));
        }

        set({
          clipMetadata: { ...get().clipMetadata, ...metadata },
          analysisProgress: 50,
        });

        // Simulate additional analysis
        await new Promise(r => setTimeout(r, 500));

        set({
          isAnalyzing: false,
          analysisProgress: 100,
          lastAnalyzedAt: new Date().toISOString(),
        });
      },

      analyzeTimeline: async (clips: Clip[], duration: number) => {
        set({ isAnalyzing: true, analysisProgress: 0 });

        // Run all analyses in sequence
        await get().detectSceneBoundaries(clips);
        set({ analysisProgress: 25 });

        await get().analyzePacing(clips, duration);
        set({ analysisProgress: 50 });

        await get().generateTransitionSuggestions(clips);
        set({ analysisProgress: 75 });

        await get().generateCutSuggestions(clips);
        set({ analysisProgress: 100 });

        set({
          isAnalyzing: false,
          lastAnalyzedAt: new Date().toISOString(),
        });
      },

      generateClipSuggestions: async (assets: MediaAsset[], existingClips: Clip[]) => {
        set({ isAnalyzing: true, analysisProgress: 0 });

        await new Promise(r => setTimeout(r, 800));

        const existingAssetIds = new Set(existingClips.map(c => c.mediaAssetId));
        const availableAssets = assets.filter(a => !existingAssetIds.has(a.id));

        // Calculate next available time slot
        const lastEndTime = existingClips.reduce((max, clip) => Math.max(max, clip.endTime), 0);

        const suggestions: AIClipSuggestion[] = availableAssets.slice(0, 8).map((asset, index) => {
          const hash = hashString(asset.id);
          const category = categories[hash % categories.length];
          const duration = asset.duration || 5;
          const clipDuration = Math.min(duration, 3 + (hash % 5));

          return {
            id: `suggestion-${asset.id}-${Date.now()}`,
            mediaAssetId: asset.id,
            mediaAsset: asset,
            suggestedTrackIndex: 0,
            suggestedStartTime: lastEndTime + (index * clipDuration),
            suggestedEndTime: lastEndTime + ((index + 1) * clipDuration),
            inPoint: 0,
            outPoint: clipDuration,
            confidence: 0.70 + (hash % 25) / 100,
            reason: reasonTemplates[category][hash % reasonTemplates[category].length],
            category,
            tags: tagOptions[hash % tagOptions.length].slice(0, 3),
          };
        });

        // Sort by confidence
        suggestions.sort((a, b) => b.confidence - a.confidence);

        set({
          clipSuggestions: suggestions,
          isAnalyzing: false,
          analysisProgress: 100,
        });
      },

      detectSceneBoundaries: async (clips: Clip[]) => {
        await new Promise(r => setTimeout(r, 600));

        const boundaries: SceneBoundary[] = [];

        clips.forEach((clip, index) => {
          if (index === 0) return;

          const prevClip = clips[index - 1];
          const hash = hashString(clip.id + prevClip.id);
          const transitionTypes: SceneBoundary['type'][] = ['cut', 'fade', 'dissolve', 'wipe', 'motion'];

          boundaries.push({
            id: `boundary-${index}-${Date.now()}`,
            timestamp: clip.startTime,
            type: transitionTypes[hash % transitionTypes.length],
            confidence: 0.75 + (hash % 20) / 100,
            shotBefore: generateShotInfo(hashString(prevClip.id), prevClip.endTime - prevClip.startTime),
            shotAfter: generateShotInfo(hashString(clip.id), clip.endTime - clip.startTime),
          });
        });

        set({ sceneBoundaries: boundaries });
      },

      analyzePacing: async (clips: Clip[], duration: number) => {
        await new Promise(r => setTimeout(r, 500));

        if (clips.length === 0) {
          set({ pacingAnalysis: null });
          return;
        }

        const avgDuration = clips.reduce((sum, c) => sum + (c.endTime - c.startTime), 0) / clips.length;
        const pace: PacingAnalysis['overallPace'] = avgDuration > 8 ? 'slow' : avgDuration > 4 ? 'moderate' : avgDuration > 2 ? 'fast' : 'dynamic';

        // Generate energy curve
        const energyCurve: { timestamp: number; energy: number }[] = [];
        for (let t = 0; t <= duration; t += duration / 20) {
          const nearbyClips = clips.filter(c => c.startTime <= t && c.endTime >= t);
          const energy = nearbyClips.length > 0 ? 0.3 + Math.random() * 0.5 : 0.1;
          energyCurve.push({ timestamp: t, energy });
        }

        // Generate pacing suggestions
        const suggestions: PacingSuggestion[] = [];
        let gapStart = 0;
        clips.sort((a, b) => a.startTime - b.startTime).forEach((clip, i) => {
          // Check for gaps
          if (clip.startTime - gapStart > 2) {
            suggestions.push({
              id: `pacing-gap-${i}`,
              type: 'remove-gap' as const,
              startTime: gapStart,
              endTime: clip.startTime,
              reason: `${(clip.startTime - gapStart).toFixed(1)}s gap detected - consider adding content or closing`,
              priority: 'medium' as const,
            });
          }
          gapStart = clip.endTime;

          // Check for long clips
          const clipDuration = clip.endTime - clip.startTime;
          if (clipDuration > 10) {
            suggestions.push({
              id: `pacing-long-${i}`,
              type: 'speed-up' as const,
              startTime: clip.startTime,
              endTime: clip.endTime,
              reason: `Clip is ${clipDuration.toFixed(1)}s - consider trimming for better pacing`,
              priority: clipDuration > 15 ? 'high' as const : 'low' as const,
            });
          }
        });

        set({
          pacingAnalysis: {
            overallPace: pace,
            averageShotDuration: avgDuration,
            rhythmScore: 0.6 + Math.random() * 0.3,
            suggestions,
            energyCurve,
          },
        });
      },

      generateTransitionSuggestions: async (clips: Clip[]) => {
        await new Promise(r => setTimeout(r, 400));

        const suggestions: TransitionSuggestion[] = [];

        clips.forEach((clip, index) => {
          if (index === 0) return;

          const prevClip = clips[index - 1];
          const hash = hashString(clip.id + prevClip.id);
          const types: TransitionSuggestion['type'][] = ['cut', 'dissolve', 'fade', 'wipe', 'zoom', 'slide'];

          const reasons = [
            'Smooth visual flow between similar compositions',
            'Emotional beat suggests softer transition',
            'Scene change warrants distinct separation',
            'Motion continuity enables seamless connection',
            'Contrasting content benefits from clear break',
            'Pacing rhythm calls for rhythmic transition',
          ];

          suggestions.push({
            id: `transition-${index}-${Date.now()}`,
            fromClipId: prevClip.id,
            toClipId: clip.id,
            type: types[hash % types.length],
            duration: 0.5 + (hash % 10) / 10,
            confidence: 0.65 + (hash % 30) / 100,
            reason: reasons[hash % reasons.length],
            contextMatch: 0.7 + (hash % 25) / 100,
          });
        });

        set({ transitionSuggestions: suggestions });
      },

      generateCutSuggestions: async (clips: Clip[]) => {
        await new Promise(r => setTimeout(r, 400));

        const suggestions: CutSuggestion[] = [];

        clips.forEach((clip) => {
          const hash = hashString(clip.id);
          const clipDuration = clip.endTime - clip.startTime;

          // Suggest trimming long clips
          if (clipDuration > 8) {
            const trimAmount = clipDuration * 0.2;
            if (hash % 2 === 0) {
              suggestions.push({
                id: `cut-trim-start-${clip.id}`,
                clipId: clip.id,
                timestamp: clip.startTime + trimAmount,
                type: 'trim-start',
                confidence: 0.7 + (hash % 20) / 100,
                reason: 'First frames contain less essential content',
                frameAccurate: true,
              });
            } else {
              suggestions.push({
                id: `cut-trim-end-${clip.id}`,
                clipId: clip.id,
                timestamp: clip.endTime - trimAmount,
                type: 'trim-end',
                confidence: 0.7 + (hash % 20) / 100,
                reason: 'Final frames could be trimmed for punchier ending',
                frameAccurate: true,
              });
            }
          }

          // Suggest split points for very long clips
          if (clipDuration > 12) {
            const splitPoint = clip.startTime + clipDuration / 2;
            suggestions.push({
              id: `cut-split-${clip.id}`,
              clipId: clip.id,
              timestamp: splitPoint,
              type: 'split',
              confidence: 0.75 + (hash % 15) / 100,
              reason: 'Natural scene change detected mid-clip',
              frameAccurate: true,
            });
          }
        });

        set({ cutSuggestions: suggestions });
      },

      setContentContext: (context: ContentContext) => {
        set({ contentContext: context });
      },

      applyClipSuggestion: (suggestionId: string) => {
        const suggestion = get().clipSuggestions.find(s => s.id === suggestionId);
        if (suggestion) {
          set({
            clipSuggestions: get().clipSuggestions.filter(s => s.id !== suggestionId),
          });
        }
        return suggestion;
      },

      dismissSuggestion: (suggestionId: string) => {
        set({
          clipSuggestions: get().clipSuggestions.filter(s => s.id !== suggestionId),
          cutSuggestions: get().cutSuggestions.filter(s => s.id !== suggestionId),
          transitionSuggestions: get().transitionSuggestions.filter(s => s.id !== suggestionId),
        });
      },

      clearSuggestions: () => {
        set({
          clipSuggestions: [],
          sceneBoundaries: [],
          cutSuggestions: [],
          transitionSuggestions: [],
          pacingAnalysis: null,
        });
      },
    }),
    {
      name: 'guabanex-ai-editing',
      partialize: (state) => ({
        clipMetadata: state.clipMetadata,
        contentContext: state.contentContext,
        lastAnalyzedAt: state.lastAnalyzedAt,
      }),
    }
  )
);
