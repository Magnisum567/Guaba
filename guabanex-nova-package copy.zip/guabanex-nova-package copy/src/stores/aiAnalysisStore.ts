import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  AIAnalysisCache,
  SceneAnalysis,
  EmotionAnalysis,
  StyleAnalysis
} from '../types';
import { ai } from '../api';

// Cache expiration time (24 hours in milliseconds)
const CACHE_TTL = 24 * 60 * 60 * 1000;

interface AIAnalysisState {
  // Cache of analysis results by mediaAssetId (using Record for proper serialization)
  cache: Record<string, AIAnalysisCache>;

  // Currently analyzing assets
  analyzingIds: string[];

  // Actions
  getAnalysis: (mediaAssetId: string) => AIAnalysisCache | undefined;
  analyzeMedia: (mediaAssetId: string, forceRefresh?: boolean) => Promise<void>;
  setAnalysis: (mediaAssetId: string, analysis: Partial<AIAnalysisCache>) => void;
  clearCache: () => void;
  removeExpired: () => void;
  isAnalyzing: (mediaAssetId: string) => boolean;
}

// Varied mock data generators based on asset ID for consistent but varied results
const generateMockSceneAnalysis = (assetId: string): SceneAnalysis => {
  const hash = hashString(assetId);
  const sceneTypes = [
    { setting: 'exterior', objects: ['trees', 'sky', 'road'], actions: ['panning', 'tracking'] },
    { setting: 'interior', objects: ['furniture', 'windows', 'decor'], actions: ['static', 'dolly'] },
    { setting: 'urban', objects: ['buildings', 'cars', 'people'], actions: ['handheld', 'crane'] },
    { setting: 'nature', objects: ['mountains', 'water', 'wildlife'], actions: ['aerial', 'timelapse'] },
    { setting: 'studio', objects: ['backdrop', 'lighting', 'props'], actions: ['static', 'zoom'] },
  ];

  const type1 = sceneTypes[hash % sceneTypes.length];
  const type2 = sceneTypes[(hash + 2) % sceneTypes.length];

  const descriptions = [
    'Wide establishing shot with dynamic camera movement',
    'Medium close-up focusing on subject detail',
    'Tracking shot following main action',
    'Static composition with balanced framing',
    'Dynamic sequence with multiple focal points',
  ];

  return {
    scenes: [
      {
        startTime: 0,
        endTime: 12 + (hash % 8),
        description: descriptions[hash % descriptions.length],
        objects: type1.objects,
        actions: type1.actions,
        setting: type1.setting,
        confidence: 0.85 + (hash % 15) / 100,
      },
      {
        startTime: 12 + (hash % 8),
        endTime: 28 + (hash % 12),
        description: descriptions[(hash + 1) % descriptions.length],
        objects: type2.objects,
        actions: type2.actions,
        setting: type2.setting,
        confidence: 0.78 + (hash % 20) / 100,
      },
      {
        startTime: 28 + (hash % 12),
        endTime: 45 + (hash % 15),
        description: descriptions[(hash + 2) % descriptions.length],
        objects: [...type1.objects.slice(0, 2), type2.objects[0]],
        actions: [type1.actions[0], type2.actions[1]],
        setting: (hash % 2 === 0) ? type1.setting : type2.setting,
        confidence: 0.82 + (hash % 12) / 100,
      },
    ],
    dominantObjects: [...new Set([...type1.objects, ...type2.objects])].slice(0, 4),
    dominantActions: [...new Set([...type1.actions, ...type2.actions])].slice(0, 3),
    overallDescription: `A ${type1.setting === type2.setting ? type1.setting : 'mixed'} sequence featuring ${type1.objects[0]} and ${type2.objects[0]} with ${type1.actions[0]} camera work.`,
  };
};

const generateMockEmotionAnalysis = (assetId: string): EmotionAnalysis => {
  const hash = hashString(assetId);
  const emotions = ['happy', 'sad', 'excited', 'calm', 'tense', 'curious', 'neutral', 'surprised'];
  const arcs = [
    'neutral → positive',
    'tension → resolution',
    'calm → energetic',
    'curious → satisfied',
    'building excitement',
    'steady engagement',
  ];

  const emotion1 = emotions[hash % emotions.length];
  const emotion2 = emotions[(hash + 3) % emotions.length];
  const emotion3 = emotions[(hash + 5) % emotions.length];

  return {
    segments: [
      {
        startTime: 0,
        endTime: 18 + (hash % 7),
        emotions: [
          { emotion: emotion1, confidence: 0.65 + (hash % 25) / 100 },
          { emotion: 'neutral', confidence: 0.35 + (hash % 15) / 100 },
        ],
        faces: 1 + (hash % 2),
      },
      {
        startTime: 18 + (hash % 7),
        endTime: 35 + (hash % 10),
        emotions: [
          { emotion: emotion2, confidence: 0.72 + (hash % 20) / 100 },
          { emotion: emotion3, confidence: 0.45 + (hash % 20) / 100 },
        ],
        faces: 1 + (hash % 3),
      },
      {
        startTime: 35 + (hash % 10),
        endTime: 50 + (hash % 10),
        emotions: [
          { emotion: emotion3, confidence: 0.68 + (hash % 22) / 100 },
        ],
        faces: hash % 3,
      },
    ],
    dominantEmotion: emotion2,
    emotionalArc: arcs[hash % arcs.length],
    facesDetected: 1 + (hash % 4),
  };
};

const generateMockStyleAnalysis = (assetId: string): StyleAnalysis => {
  const hash = hashString(assetId);

  const palettes = [
    [
      { hex: '#2C3E50', name: 'Dark Blue-Gray', percentage: 35 },
      { hex: '#E67E22', name: 'Warm Orange', percentage: 25 },
      { hex: '#ECF0F1', name: 'Light Gray', percentage: 20 },
      { hex: '#27AE60', name: 'Forest Green', percentage: 12 },
      { hex: '#8E44AD', name: 'Deep Purple', percentage: 8 },
    ],
    [
      { hex: '#1A1A2E', name: 'Deep Navy', percentage: 40 },
      { hex: '#16213E', name: 'Midnight Blue', percentage: 25 },
      { hex: '#0F3460', name: 'Ocean Blue', percentage: 18 },
      { hex: '#E94560', name: 'Coral Red', percentage: 12 },
      { hex: '#FFFFFF', name: 'Pure White', percentage: 5 },
    ],
    [
      { hex: '#F5E6CC', name: 'Warm Cream', percentage: 30 },
      { hex: '#C4A77D', name: 'Golden Tan', percentage: 28 },
      { hex: '#8B7355', name: 'Earth Brown', percentage: 22 },
      { hex: '#5C4033', name: 'Dark Chocolate', percentage: 12 },
      { hex: '#2F2F2F', name: 'Charcoal', percentage: 8 },
    ],
    [
      { hex: '#004D40', name: 'Teal Deep', percentage: 32 },
      { hex: '#FF6F00', name: 'Vivid Orange', percentage: 28 },
      { hex: '#263238', name: 'Blue Gray', percentage: 20 },
      { hex: '#FFAB00', name: 'Amber', percentage: 12 },
      { hex: '#ECEFF1', name: 'Blue White', percentage: 8 },
    ],
  ];

  const moods = ['Cinematic / Dramatic', 'Bright / Energetic', 'Moody / Atmospheric', 'Warm / Nostalgic', 'Cool / Modern', 'Natural / Documentary'];
  const styles = ['Modern Narrative', 'Classic Film', 'Documentary', 'Music Video', 'Commercial', 'Artistic'];
  const lighting = ['Natural with fill', 'High-key studio', 'Low-key dramatic', 'Golden hour', 'Overcast soft', 'Mixed practical'];
  const contrasts: ('low' | 'medium' | 'high')[] = ['low', 'medium', 'high'];
  const saturations: ('desaturated' | 'neutral' | 'saturated' | 'vibrant')[] = ['desaturated', 'neutral', 'saturated', 'vibrant'];

  const lutStyles = [
    { name: 'Cinematic Warm', description: 'Golden hour warmth with deep shadows' },
    { name: 'Teal & Orange', description: 'Hollywood blockbuster color grade' },
    { name: 'Natural Film', description: 'Organic film-like color response' },
    { name: 'Film Noir', description: 'High contrast black and white inspired' },
    { name: 'Vintage', description: 'Faded retro color palette' },
    { name: 'Bleach Bypass', description: 'Desaturated with crushed blacks' },
    { name: 'High Contrast', description: 'Punchy modern look' },
    { name: 'Muted', description: 'Soft, pastel color grading' },
  ];

  const selectedPalette = palettes[hash % palettes.length];
  const selectedLuts = [
    { ...lutStyles[hash % lutStyles.length], similarity: 0.80 + (hash % 15) / 100 },
    { ...lutStyles[(hash + 2) % lutStyles.length], similarity: 0.65 + (hash % 20) / 100 },
    { ...lutStyles[(hash + 4) % lutStyles.length], similarity: 0.55 + (hash % 20) / 100 },
  ];

  return {
    colorPalette: selectedPalette,
    mood: moods[hash % moods.length],
    visualStyle: styles[hash % styles.length],
    lightingType: lighting[hash % lighting.length],
    contrast: contrasts[hash % contrasts.length],
    saturation: saturations[hash % saturations.length],
    suggestedLUT: selectedLuts[0].name.toLowerCase().replace(/\s+/g, '-'),
    matchingStyles: selectedLuts,
  };
};

// Simple hash function for consistent mock data
function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash);
}

// Check if cache entry is expired
function isCacheExpired(entry: AIAnalysisCache): boolean {
  const analyzedAt = new Date(entry.analyzedAt).getTime();
  return Date.now() - analyzedAt > CACHE_TTL;
}

export const useAIAnalysisStore = create<AIAnalysisState>()(
  persist(
    (set, get) => ({
      cache: {},
      analyzingIds: [],

      getAnalysis: (mediaAssetId: string) => {
        const entry = get().cache[mediaAssetId];
        if (entry && !isCacheExpired(entry)) {
          return entry;
        }
        return undefined;
      },

      isAnalyzing: (mediaAssetId: string) => {
        return get().analyzingIds.includes(mediaAssetId);
      },

      analyzeMedia: async (mediaAssetId: string, forceRefresh = false) => {
        const { cache, analyzingIds } = get();

        // Check if already analyzing
        if (analyzingIds.includes(mediaAssetId)) {
          return;
        }

        // Check if cached and not expired (unless force refresh)
        const cached = cache[mediaAssetId];
        if (!forceRefresh && cached && cached.status === 'complete' && !isCacheExpired(cached)) {
          return;
        }

        // Mark as analyzing
        set({
          analyzingIds: [...analyzingIds, mediaAssetId],
          cache: {
            ...cache,
            [mediaAssetId]: {
              mediaAssetId,
              status: 'analyzing',
              analyzedAt: new Date().toISOString(),
            },
          },
        });

        try {
          // Simulate analysis delay
          await new Promise((resolve) => setTimeout(resolve, 1200 + Math.random() * 800));

          let sceneAnalysis: SceneAnalysis;
          let emotionAnalysis: EmotionAnalysis;
          let styleAnalysis: StyleAnalysis;

          try {
            // Try to call real API endpoints in parallel
            const [sceneRes, emotionRes] = await Promise.allSettled([
              ai.sceneDetection(mediaAssetId),
              ai.emotionAnalysis(mediaAssetId),
            ]);

            sceneAnalysis = sceneRes.status === 'fulfilled'
              ? sceneRes.value.data
              : generateMockSceneAnalysis(mediaAssetId);
            emotionAnalysis = emotionRes.status === 'fulfilled'
              ? emotionRes.value.data
              : generateMockEmotionAnalysis(mediaAssetId);
            // Style analysis uses local generation
            styleAnalysis = generateMockStyleAnalysis(mediaAssetId);
          } catch {
            // Use mock data if API fails
            sceneAnalysis = generateMockSceneAnalysis(mediaAssetId);
            emotionAnalysis = generateMockEmotionAnalysis(mediaAssetId);
            styleAnalysis = generateMockStyleAnalysis(mediaAssetId);
          }

          // Update cache with results
          set((state) => ({
            cache: {
              ...state.cache,
              [mediaAssetId]: {
                mediaAssetId,
                sceneAnalysis,
                emotionAnalysis,
                styleAnalysis,
                status: 'complete',
                analyzedAt: new Date().toISOString(),
              },
            },
            analyzingIds: state.analyzingIds.filter(id => id !== mediaAssetId),
          }));
        } catch (error) {
          // Mark as failed
          set((state) => ({
            cache: {
              ...state.cache,
              [mediaAssetId]: {
                mediaAssetId,
                status: 'failed',
                analyzedAt: new Date().toISOString(),
              },
            },
            analyzingIds: state.analyzingIds.filter(id => id !== mediaAssetId),
          }));
        }
      },

      setAnalysis: (mediaAssetId: string, analysis: Partial<AIAnalysisCache>) => {
        set((state) => {
          const existing = state.cache[mediaAssetId];
          const merged: AIAnalysisCache = {
            ...existing,
            ...analysis,
            mediaAssetId,
            status: analysis.status || existing?.status || 'pending',
            analyzedAt: analysis.analyzedAt || existing?.analyzedAt || new Date().toISOString(),
          };
          return {
            cache: {
              ...state.cache,
              [mediaAssetId]: merged,
            },
          };
        });
      },

      removeExpired: () => {
        const { cache } = get();
        const newCache: Record<string, AIAnalysisCache> = {};

        Object.entries(cache).forEach(([id, entry]) => {
          if (!isCacheExpired(entry)) {
            newCache[id] = entry;
          }
        });

        set({ cache: newCache });
      },

      clearCache: () => {
        set({ cache: {}, analyzingIds: [] });
      },
    }),
    {
      name: 'guabanex-ai-analysis-cache',
      partialize: (state) => ({ cache: state.cache }),
    }
  )
);
