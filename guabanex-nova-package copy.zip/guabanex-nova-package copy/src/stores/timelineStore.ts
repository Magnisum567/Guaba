import { create } from 'zustand';
import { immer } from 'zustand/middleware/immer';
import type { Timeline, Clip, Track, Marker } from '../types';
import { timeline as timelineApi } from '../api';

interface TimelineState {
  timeline: Timeline | null;
  selectedClipIds: Set<string>;
  hoveredClipId: string | null;

  // Playback state
  currentTime: number;
  isPlaying: boolean;
  playbackRate: number;

  // UI state
  zoom: number;
  scrollPosition: number;
  snapEnabled: boolean;

  isLoading: boolean;
  error: string | null;

  // Timeline actions
  fetchTimeline: (id: string) => Promise<void>;
  setTimeline: (timeline: Timeline | null) => void;
  updateTimelineDuration: (duration: number) => void;

  // Clip actions
  addClip: (clip: Omit<Clip, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Clip>;
  updateClip: (clipId: string, updates: Partial<Clip>) => Promise<void>;
  deleteClip: (clipId: string) => Promise<void>;
  moveClip: (clipId: string, startTime: number, trackIndex: number) => void;
  trimClip: (clipId: string, inPoint: number, outPoint: number) => void;
  splitClip: (clipId: string, splitTime: number) => void;

  // Selection actions
  selectClip: (clipId: string, multiSelect?: boolean) => void;
  deselectClip: (clipId: string) => void;
  clearSelection: () => void;
  selectAllClips: () => void;
  setHoveredClip: (clipId: string | null) => void;

  // Playback actions
  setCurrentTime: (time: number) => void;
  play: () => void;
  pause: () => void;
  togglePlayback: () => void;
  setPlaybackRate: (rate: number) => void;
  seekTo: (time: number) => void;
  skipForward: (seconds?: number) => void;
  skipBackward: (seconds?: number) => void;
  goToStart: () => void;
  goToEnd: () => void;

  // UI actions
  setZoom: (zoom: number) => void;
  zoomIn: () => void;
  zoomOut: () => void;
  setScrollPosition: (position: number) => void;
  toggleSnap: () => void;

  // Track actions
  addTrack: (type: 'video' | 'audio' | 'text') => void;
  removeTrack: (index: number) => void;
  toggleTrackMute: (index: number) => void;
  toggleTrackLock: (index: number) => void;

  // Marker actions
  addMarker: (time: number, label: string, color?: string) => void;
  removeMarker: (id: string) => void;

  clearError: () => void;
}

export const useTimelineStore = create<TimelineState>()(
  immer((set, get) => ({
    timeline: null,
    selectedClipIds: new Set(),
    hoveredClipId: null,

    currentTime: 0,
    isPlaying: false,
    playbackRate: 1,

    zoom: 1,
    scrollPosition: 0,
    snapEnabled: true,

    isLoading: false,
    error: null,

    fetchTimeline: async (id: string) => {
      set({ isLoading: true, error: null });
      try {
        const response = await timelineApi.get(id);
        set({ timeline: response.data, isLoading: false });
      } catch (error: any) {
        set({
          isLoading: false,
          error: error.response?.data?.error || 'Failed to fetch timeline',
        });
      }
    },

    setTimeline: (timeline: Timeline | null) => {
      set({ timeline });
    },

    updateTimelineDuration: (duration: number) => {
      set((state) => {
        if (state.timeline) {
          state.timeline.duration = duration;
        }
      });
    },

    addClip: async (clipData) => {
      const { timeline } = get();
      if (!timeline) throw new Error('No timeline loaded');

      // Create clip locally first (optimistic update)
      const newClip: Clip = {
        id: `clip-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        timelineId: timeline.id,
        mediaAssetId: clipData.mediaAssetId,
        mediaAsset: clipData.mediaAsset, // Include the full media asset
        trackIndex: clipData.trackIndex,
        startTime: clipData.startTime,
        endTime: clipData.endTime,
        inPoint: clipData.inPoint,
        outPoint: clipData.outPoint,
        properties: clipData.properties || {
          volume: 100,
          speed: 1,
          opacity: 100,
          effects: [],
        },
        aiSuggestions: clipData.aiSuggestions || {},
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      // Add to local state immediately
      set((state) => {
        if (state.timeline) {
          state.timeline.clips = [...(state.timeline.clips || []), newClip];
        }
      });

      // Try to sync with backend (don't block on failure)
      try {
        const response = await timelineApi.addClip(timeline.id, clipData);
        // Update with server-generated ID if available
        set((state) => {
          if (state.timeline?.clips) {
            const idx = state.timeline.clips.findIndex(c => c.id === newClip.id);
            if (idx !== -1 && response.data?.id) {
              state.timeline.clips[idx] = { ...state.timeline.clips[idx], ...response.data };
            }
          }
        });
        return response.data || newClip;
      } catch (error: any) {
        console.warn('Failed to sync clip with backend:', error);
        // Return local clip - it's already added
        return newClip;
      }
    },

    updateClip: async (clipId: string, updates: Partial<Clip>) => {
      // Optimistic update - update local state immediately
      set((state) => {
        if (state.timeline?.clips) {
          const clipIndex = state.timeline.clips.findIndex((c) => c.id === clipId);
          if (clipIndex !== -1) {
            const existingClip = state.timeline.clips[clipIndex];

            // Deep merge properties if provided
            let mergedProperties = existingClip.properties;
            if (updates.properties) {
              mergedProperties = {
                ...existingClip.properties,
                ...updates.properties,
              };
              // Deep merge colorGrading if provided
              if (updates.properties.colorGrading) {
                mergedProperties.colorGrading = {
                  ...(existingClip.properties?.colorGrading || {}),
                  ...updates.properties.colorGrading,
                } as typeof existingClip.properties.colorGrading;
              }
            }

            state.timeline.clips[clipIndex] = {
              ...existingClip,
              ...updates,
              properties: mergedProperties,
            };
          }
        }
      });

      // Try to sync with backend (don't block on failure)
      try {
        await timelineApi.updateClip(clipId, updates);
      } catch (error: any) {
        console.warn('Failed to sync clip update with backend:', error);
        // Don't throw - we already updated locally
      }
    },

    deleteClip: async (clipId: string) => {
      // Optimistic update - delete locally first
      const { selectedClipIds } = get();
      const newSelectedIds = new Set(selectedClipIds);
      newSelectedIds.delete(clipId);

      set((state) => {
        if (state.timeline?.clips) {
          state.timeline.clips = state.timeline.clips.filter((c) => c.id !== clipId);
        }
      });
      set({ selectedClipIds: newSelectedIds });

      // Try to sync with backend (don't block on failure)
      try {
        await timelineApi.deleteClip(clipId);
      } catch (error: any) {
        console.warn('Failed to sync clip deletion with backend:', error);
      }
    },

    moveClip: (clipId: string, startTime: number, trackIndex: number) => {
      set((state) => {
        if (state.timeline?.clips) {
          const clip = state.timeline.clips.find((c) => c.id === clipId);
          if (clip) {
            const duration = clip.endTime - clip.startTime;
            clip.startTime = startTime;
            clip.endTime = startTime + duration;
            clip.trackIndex = trackIndex;
          }
        }
      });
    },

    trimClip: (clipId: string, inPoint: number, outPoint: number) => {
      set((state) => {
        if (state.timeline?.clips) {
          const clip = state.timeline.clips.find((c) => c.id === clipId);
          if (clip) {
            clip.inPoint = inPoint;
            clip.outPoint = outPoint;
          }
        }
      });
    },

    splitClip: (clipId: string, splitTime: number) => {
      const { timeline } = get();
      if (!timeline?.clips) return;

      const clipIndex = timeline.clips.findIndex((c) => c.id === clipId);
      if (clipIndex === -1) return;

      const clip = timeline.clips[clipIndex];
      if (splitTime <= clip.startTime || splitTime >= clip.endTime) return;

      // Calculate the split point relative to the clip's in/out points
      const splitOffset = splitTime - clip.startTime;

      // Create the new clip (second half)
      const newClip: Clip = {
        ...clip,
        id: `${clip.id}-split-${Date.now()}`,
        startTime: splitTime,
        inPoint: clip.inPoint + splitOffset,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      // Update original clip (first half)
      const updatedOriginalClip: Clip = {
        ...clip,
        endTime: splitTime,
        outPoint: clip.inPoint + splitOffset,
        updatedAt: new Date().toISOString(),
      };

      // Create new clips array
      const newClips = [
        ...timeline.clips.slice(0, clipIndex),
        updatedOriginalClip,
        newClip,
        ...timeline.clips.slice(clipIndex + 1),
      ];

      set((state) => {
        if (state.timeline) {
          state.timeline.clips = newClips;
        }
      });
    },

    selectClip: (clipId: string, multiSelect = false) => {
      const { selectedClipIds } = get();
      if (multiSelect) {
        const newSet = new Set(selectedClipIds);
        newSet.add(clipId);
        set({ selectedClipIds: newSet });
      } else {
        set({ selectedClipIds: new Set([clipId]) });
      }
    },

    deselectClip: (clipId: string) => {
      const { selectedClipIds } = get();
      const newSet = new Set(selectedClipIds);
      newSet.delete(clipId);
      set({ selectedClipIds: newSet });
    },

    clearSelection: () => {
      set({ selectedClipIds: new Set() });
    },

    selectAllClips: () => {
      const { timeline } = get();
      if (timeline?.clips) {
        set({ selectedClipIds: new Set(timeline.clips.map((c) => c.id)) });
      }
    },

    setHoveredClip: (clipId: string | null) => {
      set({ hoveredClipId: clipId });
    },

    setCurrentTime: (time: number) => {
      set({ currentTime: Math.max(0, time) });
    },

    play: () => {
      set({ isPlaying: true });
    },

    pause: () => {
      set({ isPlaying: false });
    },

    togglePlayback: () => {
      set((state) => ({ isPlaying: !state.isPlaying }));
    },

    setPlaybackRate: (rate: number) => {
      set({ playbackRate: Math.max(0.25, Math.min(4, rate)) });
    },

    seekTo: (time: number) => {
      const { timeline } = get();
      const maxTime = timeline?.duration || 0;
      set({ currentTime: Math.max(0, Math.min(time, maxTime)) });
    },

    skipForward: (seconds = 5) => {
      const { currentTime, timeline } = get();
      const maxTime = timeline?.duration || 0;
      set({ currentTime: Math.min(currentTime + seconds, maxTime) });
    },

    skipBackward: (seconds = 5) => {
      const { currentTime } = get();
      set({ currentTime: Math.max(currentTime - seconds, 0) });
    },

    goToStart: () => {
      set({ currentTime: 0 });
    },

    goToEnd: () => {
      const { timeline } = get();
      set({ currentTime: timeline?.duration || 0 });
    },

    setZoom: (zoom: number) => {
      set({ zoom: Math.max(0.1, Math.min(10, zoom)) });
    },

    zoomIn: () => {
      const { zoom } = get();
      set({ zoom: Math.min(zoom * 1.25, 10) });
    },

    zoomOut: () => {
      const { zoom } = get();
      set({ zoom: Math.max(zoom / 1.25, 0.1) });
    },

    setScrollPosition: (position: number) => {
      set({ scrollPosition: Math.max(0, position) });
    },

    toggleSnap: () => {
      set((state) => ({ snapEnabled: !state.snapEnabled }));
    },

    addTrack: (type: 'video' | 'audio' | 'text') => {
      set((state) => {
        if (state.timeline) {
          const existingTracks = state.timeline.tracks.filter((t) => t.type === type);
          const newTrack: Track = {
            id: `${type}-${Date.now()}`,
            name: `${type.charAt(0).toUpperCase() + type.slice(1)} ${existingTracks.length + 1}`,
            type,
            muted: false,
            locked: false,
            height: type === 'video' ? 60 : 40,
          };
          state.timeline.tracks.push(newTrack);
        }
      });
    },

    removeTrack: (index: number) => {
      set((state) => {
        if (state.timeline && state.timeline.tracks.length > 1) {
          state.timeline.tracks.splice(index, 1);
        }
      });
    },

    toggleTrackMute: (index: number) => {
      set((state) => {
        if (state.timeline?.tracks[index]) {
          state.timeline.tracks[index].muted = !state.timeline.tracks[index].muted;
        }
      });
    },

    toggleTrackLock: (index: number) => {
      set((state) => {
        if (state.timeline?.tracks[index]) {
          state.timeline.tracks[index].locked = !state.timeline.tracks[index].locked;
        }
      });
    },

    addMarker: (time: number, label: string, color = '#6366f1') => {
      set((state) => {
        if (state.timeline) {
          const marker: Marker = {
            id: `marker-${Date.now()}`,
            time,
            label,
            color,
          };
          state.timeline.markers.push(marker);
        }
      });
    },

    removeMarker: (id: string) => {
      set((state) => {
        if (state.timeline) {
          state.timeline.markers = state.timeline.markers.filter((m) => m.id !== id);
        }
      });
    },

    clearError: () => {
      set({ error: null });
    },
  }))
);
