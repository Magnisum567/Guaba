import { create } from 'zustand';
import type {
  ParsedPrompt,
  ClipSuggestion,
  DraftTimeline,
  TextToEditSettings,
} from '../types';
import api from '../api';

type WorkflowStep = 'idle' | 'parsing' | 'suggesting' | 'previewing' | 'applying' | 'complete';

interface TextToEditState {
  // Workflow state
  isOpen: boolean;
  step: WorkflowStep;

  // Input
  prompt: string;
  settings: TextToEditSettings;

  // AI Results
  parsedPrompt: ParsedPrompt | null;
  suggestions: ClipSuggestion[];
  draftTimeline: DraftTimeline | null;
  previewUrl: string | null;

  // Loading/Error
  isLoading: boolean;
  error: string | null;

  // Actions - Modal
  openModal: () => void;
  closeModal: () => void;
  reset: () => void;

  // Actions - Input
  setPrompt: (prompt: string) => void;
  updateSettings: (settings: Partial<TextToEditSettings>) => void;

  // Actions - Suggestions
  toggleClipSelection: (index: number) => void;
  swapClip: (index: number, alternative: ClipSuggestion) => void;
  reorderClips: (fromIndex: number, toIndex: number) => void;

  // Actions - API
  parsePrompt: (projectId: string) => Promise<void>;
  generateDraft: (projectId: string) => Promise<void>;
  applyEdits: (projectId: string) => Promise<void>;

  clearError: () => void;
}

const defaultSettings: TextToEditSettings = {
  targetDuration: undefined,
  includeTransitions: true,
  includeColorGrading: false,
  includeTextOverlays: false,
  audioMixing: true,
};

export const useTextToEditStore = create<TextToEditState>((set, get) => ({
  isOpen: false,
  step: 'idle',

  prompt: '',
  settings: { ...defaultSettings },

  parsedPrompt: null,
  suggestions: [],
  draftTimeline: null,
  previewUrl: null,

  isLoading: false,
  error: null,

  openModal: () => {
    set({ isOpen: true, step: 'idle' });
  },

  closeModal: () => {
    set({ isOpen: false });
  },

  reset: () => {
    set({
      isOpen: false,
      step: 'idle',
      prompt: '',
      settings: { ...defaultSettings },
      parsedPrompt: null,
      suggestions: [],
      draftTimeline: null,
      previewUrl: null,
      isLoading: false,
      error: null,
    });
  },

  setPrompt: (prompt: string) => {
    set({ prompt });
  },

  updateSettings: (settings: Partial<TextToEditSettings>) => {
    set((state) => ({
      settings: { ...state.settings, ...settings },
    }));
  },

  toggleClipSelection: (index: number) => {
    set((state) => {
      const newSuggestions = [...state.suggestions];
      if (newSuggestions[index]) {
        newSuggestions[index] = {
          ...newSuggestions[index],
          isSelected: !newSuggestions[index].isSelected,
        };
      }
      return { suggestions: newSuggestions };
    });
  },

  swapClip: (index: number, alternative: ClipSuggestion) => {
    set((state) => {
      const newSuggestions = [...state.suggestions];
      const current = newSuggestions[index];
      if (current) {
        // Move current to alternatives of the alternative
        const newAlternatives = [
          { ...current, isSelected: false },
          ...alternative.alternatives.filter(
            (a) => a.mediaAssetId !== alternative.mediaAssetId
          ),
        ];

        newSuggestions[index] = {
          ...alternative,
          isSelected: true,
          alternatives: newAlternatives,
        };
      }
      return { suggestions: newSuggestions };
    });
  },

  reorderClips: (fromIndex: number, toIndex: number) => {
    set((state) => {
      const newSuggestions = [...state.suggestions];
      const [removed] = newSuggestions.splice(fromIndex, 1);
      newSuggestions.splice(toIndex, 0, removed);
      return { suggestions: newSuggestions };
    });
  },

  parsePrompt: async (projectId: string) => {
    const { prompt, settings } = get();
    if (!prompt.trim()) {
      set({ error: 'Please enter a prompt' });
      return;
    }

    set({ isLoading: true, error: null, step: 'parsing' });

    try {
      const response = await api.post('/text-to-edit/parse', {
        projectId,
        prompt,
        settings,
      });

      const { parsedPrompt, suggestedClips } = response.data;

      set({
        parsedPrompt,
        suggestions: suggestedClips.map((clip: ClipSuggestion) => ({
          ...clip,
          isSelected: true,
        })),
        step: 'suggesting',
        isLoading: false,
      });
    } catch (error: any) {
      set({
        error: error.response?.data?.error || 'Failed to parse prompt',
        step: 'idle',
        isLoading: false,
      });
    }
  },

  generateDraft: async (projectId: string) => {
    const { parsedPrompt, suggestions, settings } = get();
    const selectedClips = suggestions.filter((s) => s.isSelected);

    if (selectedClips.length === 0) {
      set({ error: 'Please select at least one clip' });
      return;
    }

    set({ isLoading: true, error: null, step: 'previewing' });

    try {
      const response = await api.post('/text-to-edit/generate-draft', {
        projectId,
        parsedPrompt,
        selectedClips: selectedClips.map((c) => ({
          mediaAssetId: c.mediaAssetId,
          startTime: c.startTime,
          endTime: c.endTime,
        })),
        settings,
      });

      const { draftId, timeline, previewUrl } = response.data;

      set({
        draftTimeline: { ...timeline, id: draftId },
        previewUrl,
        step: 'previewing',
        isLoading: false,
      });
    } catch (error: any) {
      set({
        error: error.response?.data?.error || 'Failed to generate draft',
        step: 'suggesting',
        isLoading: false,
      });
    }
  },

  applyEdits: async (projectId: string) => {
    const { draftTimeline } = get();
    if (!draftTimeline) {
      set({ error: 'No draft to apply' });
      return;
    }

    set({ isLoading: true, error: null, step: 'applying' });

    try {
      await api.post('/text-to-edit/apply', {
        projectId,
        draftId: draftTimeline.id,
      });

      set({
        step: 'complete',
        isLoading: false,
      });

      // Auto-close after success
      setTimeout(() => {
        get().reset();
      }, 1500);
    } catch (error: any) {
      set({
        error: error.response?.data?.error || 'Failed to apply edits',
        step: 'previewing',
        isLoading: false,
      });
    }
  },

  clearError: () => {
    set({ error: null });
  },
}));
