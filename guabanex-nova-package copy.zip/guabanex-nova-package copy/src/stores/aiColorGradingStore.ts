import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  CinematicStyle,
  StyleMatchResult,
  AIColorSuggestion,
  ColorGrading,
} from '../types';

// Famous Cinematic Styles Database
export const CINEMATIC_STYLES: CinematicStyle[] = [
  // Director Styles
  {
    id: 'wes-anderson',
    name: 'Wes Anderson',
    director: 'Wes Anderson',
    description: 'Symmetrical compositions with pastel color palettes, warm yellows, and whimsical aesthetics',
    characteristics: ['Pastel colors', 'Warm yellows', 'High saturation', 'Symmetry', 'Vintage feel'],
    category: 'director',
    colorGrading: {
      brightness: 10,
      contrast: -5,
      saturation: 25,
      temperature: 15,
      tint: 5,
      exposure: 5,
      highlights: -10,
      shadows: 15,
      vibrance: 20,
      hue: 0,
      gamma: 5,
      lutIntensity: 100,
    },
  },
  {
    id: 'david-fincher',
    name: 'David Fincher',
    director: 'David Fincher',
    description: 'Dark, desaturated tones with green/yellow shadows and high contrast',
    characteristics: ['Desaturated', 'Green shadows', 'High contrast', 'Dark mood', 'Clinical'],
    category: 'director',
    colorGrading: {
      brightness: -10,
      contrast: 20,
      saturation: -25,
      temperature: -10,
      tint: 10,
      exposure: -5,
      highlights: -15,
      shadows: -20,
      vibrance: -15,
      hue: 0,
      gamma: -10,
      lutIntensity: 100,
    },
  },
  {
    id: 'christopher-nolan',
    name: 'Christopher Nolan',
    director: 'Christopher Nolan',
    description: 'IMAX-inspired clarity with natural colors, deep blacks, and rich contrast',
    characteristics: ['Natural colors', 'Deep blacks', 'Rich contrast', 'Clarity', 'Epic scale'],
    category: 'director',
    colorGrading: {
      brightness: 0,
      contrast: 15,
      saturation: 5,
      temperature: -5,
      tint: 0,
      exposure: 0,
      highlights: 10,
      shadows: -15,
      vibrance: 10,
      hue: 0,
      gamma: 0,
      lutIntensity: 100,
    },
  },
  {
    id: 'denis-villeneuve',
    name: 'Denis Villeneuve',
    director: 'Denis Villeneuve',
    description: 'Atmospheric with muted colors, orange/teal contrast, and hazy ambience',
    characteristics: ['Muted palette', 'Orange/teal', 'Atmospheric', 'Hazy', 'Otherworldly'],
    category: 'director',
    colorGrading: {
      brightness: -5,
      contrast: 10,
      saturation: -15,
      temperature: 10,
      tint: -5,
      exposure: -5,
      highlights: -20,
      shadows: 10,
      vibrance: -10,
      hue: 0,
      gamma: 5,
      lutIntensity: 100,
    },
  },
  {
    id: 'quentin-tarantino',
    name: 'Quentin Tarantino',
    director: 'Quentin Tarantino',
    description: 'Vibrant, saturated colors with warm tones and 70s film grain aesthetic',
    characteristics: ['Vibrant', 'Warm tones', '70s aesthetic', 'Saturated', 'Bold'],
    category: 'director',
    colorGrading: {
      brightness: 5,
      contrast: 10,
      saturation: 20,
      temperature: 20,
      tint: 5,
      exposure: 5,
      highlights: 5,
      shadows: 5,
      vibrance: 25,
      hue: 5,
      gamma: 0,
      lutIntensity: 100,
    },
  },
  {
    id: 'wong-kar-wai',
    name: 'Wong Kar-wai',
    director: 'Wong Kar-wai',
    description: 'Dreamlike with heavy color casts, neon accents, and romantic atmosphere',
    characteristics: ['Dreamlike', 'Neon colors', 'Romantic', 'Saturated', 'Moody'],
    category: 'director',
    colorGrading: {
      brightness: -5,
      contrast: 15,
      saturation: 30,
      temperature: 0,
      tint: 15,
      exposure: -5,
      highlights: -10,
      shadows: 0,
      vibrance: 35,
      hue: 10,
      gamma: -5,
      lutIntensity: 100,
    },
  },

  // Film Styles
  {
    id: 'blade-runner',
    name: 'Blade Runner',
    film: 'Blade Runner (1982)',
    director: 'Ridley Scott',
    year: 1982,
    description: 'Cyberpunk noir with neon blues, smoky atmosphere, and high contrast shadows',
    characteristics: ['Cyberpunk', 'Neon blues', 'Noir', 'Smoky', 'Futuristic'],
    category: 'film',
    colorGrading: {
      brightness: -15,
      contrast: 25,
      saturation: 10,
      temperature: -20,
      tint: 10,
      exposure: -10,
      highlights: -25,
      shadows: -10,
      vibrance: 15,
      hue: -10,
      gamma: -5,
      lutIntensity: 100,
    },
  },
  {
    id: 'blade-runner-2049',
    name: 'Blade Runner 2049',
    film: 'Blade Runner 2049 (2017)',
    director: 'Denis Villeneuve',
    year: 2017,
    description: 'Orange/teal extremes with heavy atmosphere, muted midtones, and epic scale',
    characteristics: ['Orange/teal', 'Atmospheric', 'Desaturated', 'Epic', 'Desolate'],
    category: 'film',
    colorGrading: {
      brightness: -10,
      contrast: 20,
      saturation: -10,
      temperature: 25,
      tint: -10,
      exposure: -5,
      highlights: -30,
      shadows: 15,
      vibrance: -5,
      hue: 5,
      gamma: 0,
      lutIntensity: 100,
    },
  },
  {
    id: 'mad-max-fury-road',
    name: 'Mad Max: Fury Road',
    film: 'Mad Max: Fury Road (2015)',
    director: 'George Miller',
    year: 2015,
    description: 'Extreme orange/teal with crushed blacks, high saturation, and intense contrast',
    characteristics: ['Orange/teal extreme', 'High contrast', 'Intense', 'Desert', 'Vivid'],
    category: 'film',
    colorGrading: {
      brightness: 5,
      contrast: 30,
      saturation: 35,
      temperature: 30,
      tint: -15,
      exposure: 5,
      highlights: 15,
      shadows: -25,
      vibrance: 40,
      hue: 10,
      gamma: 5,
      lutIntensity: 100,
    },
  },
  {
    id: 'the-matrix',
    name: 'The Matrix',
    film: 'The Matrix (1999)',
    director: 'Wachowskis',
    year: 1999,
    description: 'Iconic green tint with high contrast, desaturated reality, and digital aesthetic',
    characteristics: ['Green tint', 'High contrast', 'Digital', 'Desaturated', 'Iconic'],
    category: 'film',
    colorGrading: {
      brightness: -5,
      contrast: 20,
      saturation: -20,
      temperature: -15,
      tint: 25,
      exposure: -5,
      highlights: -10,
      shadows: -15,
      vibrance: -10,
      hue: 60,
      gamma: -5,
      lutIntensity: 100,
    },
  },
  {
    id: 'amelie',
    name: 'Amélie',
    film: 'Amélie (2001)',
    director: 'Jean-Pierre Jeunet',
    year: 2001,
    description: 'Warm golden greens with saturated reds, whimsical and romantic feel',
    characteristics: ['Golden green', 'Warm', 'Whimsical', 'Romantic', 'Saturated reds'],
    category: 'film',
    colorGrading: {
      brightness: 5,
      contrast: 5,
      saturation: 25,
      temperature: 10,
      tint: 20,
      exposure: 5,
      highlights: 0,
      shadows: 10,
      vibrance: 30,
      hue: 30,
      gamma: 5,
      lutIntensity: 100,
    },
  },
  {
    id: 'moonlight',
    name: 'Moonlight',
    film: 'Moonlight (2016)',
    director: 'Barry Jenkins',
    year: 2016,
    description: 'Deep blues and purples with rich skin tones and intimate lighting',
    characteristics: ['Deep blues', 'Rich skin tones', 'Intimate', 'Poetic', 'Warm shadows'],
    category: 'film',
    colorGrading: {
      brightness: -5,
      contrast: 10,
      saturation: 15,
      temperature: -10,
      tint: -10,
      exposure: -5,
      highlights: -15,
      shadows: 10,
      vibrance: 20,
      hue: -20,
      gamma: 0,
      lutIntensity: 100,
    },
  },
  {
    id: 'la-la-land',
    name: 'La La Land',
    film: 'La La Land (2016)',
    director: 'Damien Chazelle',
    year: 2016,
    description: 'Vivid, saturated colors with golden hour warmth and classic Hollywood glamour',
    characteristics: ['Vivid colors', 'Golden hour', 'Glamorous', 'Romantic', 'Musical'],
    category: 'film',
    colorGrading: {
      brightness: 10,
      contrast: 5,
      saturation: 30,
      temperature: 15,
      tint: 5,
      exposure: 10,
      highlights: 10,
      shadows: 15,
      vibrance: 35,
      hue: 0,
      gamma: 5,
      lutIntensity: 100,
    },
  },
  {
    id: 'joker',
    name: 'Joker',
    film: 'Joker (2019)',
    director: 'Todd Phillips',
    year: 2019,
    description: 'Gritty 70s aesthetic with desaturated tones and green/yellow color cast',
    characteristics: ['Gritty', '70s aesthetic', 'Desaturated', 'Green/yellow', 'Urban decay'],
    category: 'film',
    colorGrading: {
      brightness: -5,
      contrast: 15,
      saturation: -15,
      temperature: 5,
      tint: 15,
      exposure: -5,
      highlights: -10,
      shadows: 5,
      vibrance: -10,
      hue: 15,
      gamma: -5,
      lutIntensity: 100,
    },
  },
  {
    id: 'dune',
    name: 'Dune',
    film: 'Dune (2021)',
    director: 'Denis Villeneuve',
    year: 2021,
    description: 'Desert orange with muted blues, epic scale and otherworldly atmosphere',
    characteristics: ['Desert tones', 'Muted', 'Epic', 'Otherworldly', 'Sandy'],
    category: 'film',
    colorGrading: {
      brightness: 0,
      contrast: 15,
      saturation: -10,
      temperature: 20,
      tint: 0,
      exposure: 5,
      highlights: -15,
      shadows: 5,
      vibrance: -5,
      hue: 10,
      gamma: 5,
      lutIntensity: 100,
    },
  },

  // Genre Styles
  {
    id: 'film-noir',
    name: 'Film Noir',
    description: 'Classic black and white inspired with high contrast and dramatic shadows',
    characteristics: ['High contrast', 'Dramatic shadows', 'Desaturated', 'Mysterious', 'Classic'],
    category: 'genre',
    colorGrading: {
      brightness: -10,
      contrast: 35,
      saturation: -60,
      temperature: -5,
      tint: 0,
      exposure: -10,
      highlights: -20,
      shadows: -30,
      vibrance: -40,
      hue: 0,
      gamma: -10,
      lutIntensity: 100,
    },
  },
  {
    id: 'horror',
    name: 'Horror',
    description: 'Desaturated with teal shadows, crushed blacks, and unsettling atmosphere',
    characteristics: ['Desaturated', 'Teal shadows', 'Dark', 'Unsettling', 'Cold'],
    category: 'genre',
    colorGrading: {
      brightness: -15,
      contrast: 20,
      saturation: -30,
      temperature: -25,
      tint: -10,
      exposure: -15,
      highlights: -25,
      shadows: -20,
      vibrance: -20,
      hue: -15,
      gamma: -10,
      lutIntensity: 100,
    },
  },
  {
    id: 'romantic-comedy',
    name: 'Romantic Comedy',
    description: 'Warm, bright, and inviting with soft highlights and pleasant saturation',
    characteristics: ['Warm', 'Bright', 'Soft', 'Pleasant', 'Inviting'],
    category: 'genre',
    colorGrading: {
      brightness: 15,
      contrast: -5,
      saturation: 15,
      temperature: 15,
      tint: 5,
      exposure: 10,
      highlights: 15,
      shadows: 20,
      vibrance: 20,
      hue: 0,
      gamma: 5,
      lutIntensity: 100,
    },
  },
  {
    id: 'sci-fi',
    name: 'Sci-Fi',
    description: 'Cool blues with high-tech feel, clean contrast, and futuristic atmosphere',
    characteristics: ['Cool blues', 'High-tech', 'Clean', 'Futuristic', 'Sleek'],
    category: 'genre',
    colorGrading: {
      brightness: 0,
      contrast: 15,
      saturation: -5,
      temperature: -15,
      tint: -5,
      exposure: 0,
      highlights: 10,
      shadows: -10,
      vibrance: 5,
      hue: -10,
      gamma: 0,
      lutIntensity: 100,
    },
  },

  // Era Styles
  {
    id: 'vintage-70s',
    name: '1970s Vintage',
    description: 'Warm, faded look with lifted blacks and orange/brown tones',
    characteristics: ['Faded', 'Warm', 'Lifted blacks', 'Nostalgic', 'Film grain'],
    category: 'era',
    colorGrading: {
      brightness: 5,
      contrast: -10,
      saturation: -15,
      temperature: 25,
      tint: 10,
      exposure: 5,
      highlights: -15,
      shadows: 25,
      vibrance: -10,
      hue: 15,
      gamma: 10,
      lutIntensity: 100,
    },
  },
  {
    id: 'vintage-80s',
    name: '1980s Neon',
    description: 'Vibrant neons with magenta/cyan push and high saturation',
    characteristics: ['Neon', 'Magenta/cyan', 'Vibrant', 'Retro', 'Synthwave'],
    category: 'era',
    colorGrading: {
      brightness: 0,
      contrast: 15,
      saturation: 35,
      temperature: -10,
      tint: 20,
      exposure: 0,
      highlights: 5,
      shadows: 5,
      vibrance: 40,
      hue: -15,
      gamma: 0,
      lutIntensity: 100,
    },
  },

  // Mood Styles
  {
    id: 'golden-hour',
    name: 'Golden Hour',
    description: 'Warm, magical sunset lighting with golden highlights and soft shadows',
    characteristics: ['Warm', 'Golden', 'Magical', 'Soft', 'Romantic'],
    category: 'mood',
    colorGrading: {
      brightness: 10,
      contrast: 5,
      saturation: 20,
      temperature: 30,
      tint: 10,
      exposure: 10,
      highlights: 15,
      shadows: 15,
      vibrance: 25,
      hue: 10,
      gamma: 5,
      lutIntensity: 100,
    },
  },
  {
    id: 'blue-hour',
    name: 'Blue Hour',
    description: 'Cool, twilight tones with deep blues and subtle warmth in highlights',
    characteristics: ['Cool', 'Twilight', 'Deep blues', 'Atmospheric', 'Serene'],
    category: 'mood',
    colorGrading: {
      brightness: -10,
      contrast: 10,
      saturation: 15,
      temperature: -25,
      tint: -10,
      exposure: -10,
      highlights: 5,
      shadows: 0,
      vibrance: 10,
      hue: -20,
      gamma: -5,
      lutIntensity: 100,
    },
  },
  {
    id: 'moody-dark',
    name: 'Moody & Dark',
    description: 'Dramatic shadows with desaturated tones and intense atmosphere',
    characteristics: ['Dark', 'Moody', 'Dramatic', 'Intense', 'Atmospheric'],
    category: 'mood',
    colorGrading: {
      brightness: -20,
      contrast: 25,
      saturation: -20,
      temperature: -5,
      tint: 0,
      exposure: -15,
      highlights: -20,
      shadows: -25,
      vibrance: -15,
      hue: 0,
      gamma: -10,
      lutIntensity: 100,
    },
  },
  {
    id: 'bright-airy',
    name: 'Bright & Airy',
    description: 'Light, ethereal feel with lifted shadows and soft, dreamy highlights',
    characteristics: ['Bright', 'Airy', 'Ethereal', 'Soft', 'Dreamy'],
    category: 'mood',
    colorGrading: {
      brightness: 20,
      contrast: -15,
      saturation: -5,
      temperature: 5,
      tint: 0,
      exposure: 15,
      highlights: 20,
      shadows: 30,
      vibrance: 5,
      hue: 0,
      gamma: 10,
      lutIntensity: 100,
    },
  },
];

interface AIColorGradingState {
  // Available styles
  cinematicStyles: CinematicStyle[];

  // Current analysis
  styleMatches: StyleMatchResult[];
  colorSuggestions: AIColorSuggestion[];

  // Favorites
  favoriteStyleIds: string[];

  // Recent
  recentlyUsedIds: string[];

  // Status
  isAnalyzing: boolean;

  // Actions
  analyzeClipForStyle: (clipId: string, currentGrading: Partial<ColorGrading>) => Promise<void>;
  matchStyle: (styleId: string) => CinematicStyle | undefined;
  getStyleById: (styleId: string) => CinematicStyle | undefined;
  getStylesByCategory: (category: CinematicStyle['category']) => CinematicStyle[];
  searchStyles: (query: string) => CinematicStyle[];
  addToFavorites: (styleId: string) => void;
  removeFromFavorites: (styleId: string) => void;
  addToRecent: (styleId: string) => void;
  generateAutoCorrection: (currentGrading: Partial<ColorGrading>) => AIColorSuggestion;
  generateMoodEnhancement: (mood: string, currentGrading: Partial<ColorGrading>) => AIColorSuggestion;
  clearAnalysis: () => void;
}

function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash);
}

const defaultGrading: ColorGrading = {
  brightness: 0,
  contrast: 0,
  saturation: 0,
  temperature: 0,
  tint: 0,
  exposure: 0,
  highlights: 0,
  shadows: 0,
  vibrance: 0,
  hue: 0,
  gamma: 0,
  lutIntensity: 100,
};

export const useAIColorGradingStore = create<AIColorGradingState>()(
  persist(
    (set, get) => ({
      cinematicStyles: CINEMATIC_STYLES,
      styleMatches: [],
      colorSuggestions: [],
      favoriteStyleIds: [],
      recentlyUsedIds: [],
      isAnalyzing: false,

      analyzeClipForStyle: async (clipId: string, currentGrading: Partial<ColorGrading>) => {
        set({ isAnalyzing: true });

        await new Promise(r => setTimeout(r, 800));

        const hash = hashString(clipId);
        const styles = get().cinematicStyles;

        // Generate style matches based on clip characteristics
        const matches: StyleMatchResult[] = styles
          .map((style, index) => {
            const baseScore = 0.5 + ((hash + index) % 40) / 100;
            const reasons: string[] = [];

            // Generate match reasons
            if (style.colorGrading.temperature > 10 && (currentGrading.temperature || 0) > 0) {
              reasons.push('Warm color tones align well');
            }
            if (style.colorGrading.temperature < -10 && (currentGrading.temperature || 0) < 0) {
              reasons.push('Cool color palette matches');
            }
            if (Math.abs(style.colorGrading.contrast - (currentGrading.contrast || 0)) < 15) {
              reasons.push('Contrast levels are compatible');
            }
            if (style.colorGrading.saturation > 15 && (currentGrading.saturation || 0) > 0) {
              reasons.push('Vibrant saturation detected');
            }

            if (reasons.length === 0) {
              reasons.push('Visual characteristics suggest this style');
            }

            return {
              style,
              matchScore: baseScore + (reasons.length * 0.05),
              matchReasons: reasons,
              adjustments: style.colorGrading,
            };
          })
          .sort((a, b) => b.matchScore - a.matchScore)
          .slice(0, 6);

        // Generate color suggestions
        const suggestions: AIColorSuggestion[] = [
          get().generateAutoCorrection(currentGrading),
          get().generateMoodEnhancement('cinematic', currentGrading),
        ];

        set({
          styleMatches: matches,
          colorSuggestions: suggestions,
          isAnalyzing: false,
        });
      },

      matchStyle: (styleId: string) => {
        const style = get().cinematicStyles.find(s => s.id === styleId);
        if (style) {
          get().addToRecent(styleId);
        }
        return style;
      },

      getStyleById: (styleId: string) => {
        return get().cinematicStyles.find(s => s.id === styleId);
      },

      getStylesByCategory: (category: CinematicStyle['category']) => {
        return get().cinematicStyles.filter(s => s.category === category);
      },

      searchStyles: (query: string) => {
        const q = query.toLowerCase();
        return get().cinematicStyles.filter(s =>
          s.name.toLowerCase().includes(q) ||
          s.director?.toLowerCase().includes(q) ||
          s.film?.toLowerCase().includes(q) ||
          s.description.toLowerCase().includes(q) ||
          s.characteristics.some(c => c.toLowerCase().includes(q))
        );
      },

      addToFavorites: (styleId: string) => {
        const { favoriteStyleIds } = get();
        if (!favoriteStyleIds.includes(styleId)) {
          set({ favoriteStyleIds: [...favoriteStyleIds, styleId] });
        }
      },

      removeFromFavorites: (styleId: string) => {
        set({
          favoriteStyleIds: get().favoriteStyleIds.filter(id => id !== styleId),
        });
      },

      addToRecent: (styleId: string) => {
        const { recentlyUsedIds } = get();
        const filtered = recentlyUsedIds.filter(id => id !== styleId);
        set({
          recentlyUsedIds: [styleId, ...filtered].slice(0, 10),
        });
      },

      generateAutoCorrection: (currentGrading: Partial<ColorGrading>): AIColorSuggestion => {
        // Simulate auto-correction analysis
        const corrected: ColorGrading = {
          ...defaultGrading,
          ...currentGrading,
          exposure: Math.max(-20, Math.min(20, (currentGrading.exposure || 0) + 5)),
          contrast: Math.max(-20, Math.min(30, (currentGrading.contrast || 0) + 10)),
          shadows: Math.max(-30, Math.min(30, (currentGrading.shadows || 0) + 10)),
          highlights: Math.max(-30, Math.min(30, (currentGrading.highlights || 0) - 5)),
        };

        return {
          id: `auto-correct-${Date.now()}`,
          type: 'auto-correct',
          title: 'Auto Color Correction',
          description: 'Optimized exposure, contrast, and dynamic range based on content analysis',
          beforeGrading: currentGrading,
          afterGrading: corrected,
          confidence: 0.85,
        };
      },

      generateMoodEnhancement: (mood: string, currentGrading: Partial<ColorGrading>): AIColorSuggestion => {
        const moodStyles: Record<string, Partial<ColorGrading>> = {
          cinematic: { contrast: 15, saturation: -10, temperature: 5, shadows: -10 },
          warm: { temperature: 25, tint: 10, saturation: 10, vibrance: 15 },
          cool: { temperature: -20, tint: -5, saturation: -5, vibrance: 5 },
          dramatic: { contrast: 25, shadows: -20, highlights: -15, saturation: -15 },
          vibrant: { saturation: 30, vibrance: 35, contrast: 10, brightness: 5 },
        };

        const enhancement = moodStyles[mood] || moodStyles.cinematic;
        const enhanced: ColorGrading = {
          ...defaultGrading,
          ...currentGrading,
        };

        Object.keys(enhancement).forEach(key => {
          const k = key as keyof ColorGrading;
          if (typeof enhancement[k] === 'number' && typeof enhanced[k] === 'number') {
            (enhanced[k] as number) = ((currentGrading[k] as number) || 0) + (enhancement[k] as number);
          }
        });

        return {
          id: `mood-${mood}-${Date.now()}`,
          type: 'mood-enhance',
          title: `${mood.charAt(0).toUpperCase() + mood.slice(1)} Enhancement`,
          description: `Enhanced ${mood} mood with adjusted tones and atmosphere`,
          beforeGrading: currentGrading,
          afterGrading: enhanced,
          confidence: 0.78,
        };
      },

      clearAnalysis: () => {
        set({
          styleMatches: [],
          colorSuggestions: [],
        });
      },
    }),
    {
      name: 'guabanex-ai-color-grading',
      partialize: (state) => ({
        favoriteStyleIds: state.favoriteStyleIds,
        recentlyUsedIds: state.recentlyUsedIds,
      }),
    }
  )
);
