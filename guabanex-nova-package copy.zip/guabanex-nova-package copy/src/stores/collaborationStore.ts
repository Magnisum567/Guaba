import { create } from 'zustand';
import type { CollaboratorCursor, ResourceLock, PresenceInfo } from '../types';

interface CollaborationState {
  isConnected: boolean;
  projectId: string | null;

  // Active users
  activeUsers: Map<string, PresenceInfo>;

  // Cursors
  cursors: Map<string, CollaboratorCursor>;

  // Locks
  locks: Map<string, ResourceLock>;

  // Connection state
  connectionError: string | null;
  reconnectAttempts: number;

  // Actions
  setConnected: (connected: boolean) => void;
  setProjectId: (projectId: string | null) => void;

  // User presence
  addUser: (user: PresenceInfo) => void;
  removeUser: (userId: string) => void;
  updateUserPresence: (userId: string, updates: Partial<PresenceInfo>) => void;

  // Cursor tracking
  updateCursor: (cursor: CollaboratorCursor) => void;
  removeCursor: (userId: string) => void;

  // Resource locking
  setLock: (lock: ResourceLock) => void;
  removeLock: (resourceId: string) => void;
  isLocked: (resourceId: string) => boolean;
  getLockedBy: (resourceId: string) => string | null;

  // Connection management
  setConnectionError: (error: string | null) => void;
  incrementReconnectAttempts: () => void;
  resetReconnectAttempts: () => void;

  // Cleanup
  reset: () => void;
}

export const useCollaborationStore = create<CollaborationState>((set, get) => ({
  isConnected: false,
  projectId: null,
  activeUsers: new Map(),
  cursors: new Map(),
  locks: new Map(),
  connectionError: null,
  reconnectAttempts: 0,

  setConnected: (connected: boolean) => {
    set({ isConnected: connected });
    if (connected) {
      set({ connectionError: null, reconnectAttempts: 0 });
    }
  },

  setProjectId: (projectId: string | null) => {
    set({ projectId });
  },

  addUser: (user: PresenceInfo) => {
    set((state) => {
      const newUsers = new Map(state.activeUsers);
      newUsers.set(user.userId, user);
      return { activeUsers: newUsers };
    });
  },

  removeUser: (userId: string) => {
    set((state) => {
      const newUsers = new Map(state.activeUsers);
      newUsers.delete(userId);

      const newCursors = new Map(state.cursors);
      newCursors.delete(userId);

      return { activeUsers: newUsers, cursors: newCursors };
    });
  },

  updateUserPresence: (userId: string, updates: Partial<PresenceInfo>) => {
    set((state) => {
      const newUsers = new Map(state.activeUsers);
      const existing = newUsers.get(userId);
      if (existing) {
        newUsers.set(userId, { ...existing, ...updates });
      }
      return { activeUsers: newUsers };
    });
  },

  updateCursor: (cursor: CollaboratorCursor) => {
    set((state) => {
      const newCursors = new Map(state.cursors);
      newCursors.set(cursor.userId, cursor);
      return { cursors: newCursors };
    });
  },

  removeCursor: (userId: string) => {
    set((state) => {
      const newCursors = new Map(state.cursors);
      newCursors.delete(userId);
      return { cursors: newCursors };
    });
  },

  setLock: (lock: ResourceLock) => {
    set((state) => {
      const newLocks = new Map(state.locks);
      newLocks.set(lock.resourceId, lock);
      return { locks: newLocks };
    });
  },

  removeLock: (resourceId: string) => {
    set((state) => {
      const newLocks = new Map(state.locks);
      newLocks.delete(resourceId);
      return { locks: newLocks };
    });
  },

  isLocked: (resourceId: string) => {
    return get().locks.has(resourceId);
  },

  getLockedBy: (resourceId: string) => {
    const lock = get().locks.get(resourceId);
    return lock?.lockedBy || null;
  },

  setConnectionError: (error: string | null) => {
    set({ connectionError: error });
  },

  incrementReconnectAttempts: () => {
    set((state) => ({ reconnectAttempts: state.reconnectAttempts + 1 }));
  },

  resetReconnectAttempts: () => {
    set({ reconnectAttempts: 0 });
  },

  reset: () => {
    set({
      isConnected: false,
      projectId: null,
      activeUsers: new Map(),
      cursors: new Map(),
      locks: new Map(),
      connectionError: null,
      reconnectAttempts: 0,
    });
  },
}));
