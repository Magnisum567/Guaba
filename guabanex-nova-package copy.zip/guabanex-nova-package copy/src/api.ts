import axios from 'axios';

const API_URL = 'http://localhost:3001/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const auth = {
  register: (data: any) => api.post('/auth/register', data),
  login: (data: any) => api.post('/auth/login', data),
};

export const projects = {
  list: () => api.get('/projects'),
  get: (id: string) => api.get(`/projects/${id}`),
  create: (data: any) => api.post('/projects', data),
  update: (id: string, data: any) => api.put(`/projects/${id}`, data),
  delete: (id: string) => api.delete(`/projects/${id}`),
};

export const media = {
  list: (projectId: string) => api.get(`/media/project/${projectId}`),
  upload: (projectId: string, file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('projectId', projectId);
    return api.post('/media/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  delete: (id: string) => api.delete(`/media/${id}`),
};

export const timeline = {
  get: (id: string) => api.get(`/timeline/${id}`),
  update: (id: string, data: any) => api.put(`/timeline/${id}`, data),
  addClip: (id: string, data: any) => api.post(`/timeline/${id}/clips`, data),
  updateClip: (clipId: string, data: any) => api.put(`/timeline/clips/${clipId}`, data),
  deleteClip: (clipId: string) => api.delete(`/timeline/clips/${clipId}`),
};

export const ai = {
  sceneDetection: (mediaAssetId: string) =>
    api.post('/ai/scene-detection', { mediaAssetId }),
  emotionAnalysis: (mediaAssetId: string) =>
    api.post('/ai/emotion-analysis', { mediaAssetId }),
  speechToText: (mediaAssetId: string) =>
    api.post('/ai/speech-to-text', { mediaAssetId }),
  suggestTransitions: (clip1Id: string, clip2Id: string) =>
    api.post('/ai/suggest-transitions', { clip1Id, clip2Id }),
  getAnalysis: (id: string) => api.get(`/ai/analysis/${id}`),
};

export const exports = {
  create: (data: any) => api.post('/export', data),
  get: (id: string) => api.get(`/export/${id}`),
  download: (id: string) => api.get(`/export/${id}/download`, { responseType: 'blob' }),
  listByProject: (projectId: string) => api.get(`/export/project/${projectId}`),
};

export const autoEdit = {
  create: (data: any) => api.post('/auto-edit', data),
};

export const chatbot = {
  sendMessage: (message: string, context?: any) => api.post('/chatbot', { message, context }),
  getSuggestions: () => api.get('/chatbot/suggestions'),
};

export const textToEdit = {
  parse: (projectId: string, prompt: string, settings?: any) =>
    api.post('/text-to-edit/parse', { projectId, prompt, settings }),
  generateDraft: (projectId: string, parsedPrompt: any, selectedClips: any[], settings?: any) =>
    api.post('/text-to-edit/generate-draft', { projectId, parsedPrompt, selectedClips, settings }),
  getPreview: (draftId: string) =>
    api.get(`/text-to-edit/preview/${draftId}`),
  apply: (projectId: string, draftId: string) =>
    api.post('/text-to-edit/apply', { projectId, draftId }),
};

export default api;
