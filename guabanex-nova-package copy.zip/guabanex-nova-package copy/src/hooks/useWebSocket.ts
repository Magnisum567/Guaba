import { useEffect, useRef, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';
import { useAuthStore, useCollaborationStore, useTimelineStore } from '../stores';
import type { Clip } from '../types';

const SOCKET_URL = import.meta.env.VITE_WS_URL || 'http://localhost:3001';
const MAX_RECONNECT_ATTEMPTS = 5;
const RECONNECT_DELAY = 2000;

interface UseWebSocketOptions {
  projectId: string;
  autoConnect?: boolean;
}

interface WebSocketHookReturn {
  isConnected: boolean;
  connect: () => void;
  disconnect: () => void;
  joinProject: (projectId: string) => void;
  leaveProject: (projectId: string) => void;
  emitTimelineEdit: (action: string, clipId?: string, changes?: any) => void;
  emitClipUpdate: (clipId: string, properties: any) => void;
  emitCursorMove: (position: number, trackIndex?: number) => void;
  emitPlaybackState: (state: 'playing' | 'paused', position: number) => void;
  requestLock: (resourceId: string, resourceType: 'clip' | 'track' | 'timeline') => void;
  releaseLock: (resourceId: string) => void;
  sendChatMessage: (message: string) => void;
}

export function useWebSocket({ projectId, autoConnect = true }: UseWebSocketOptions): WebSocketHookReturn {
  const socketRef = useRef<Socket | null>(null);
  const reconnectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const { token, user } = useAuthStore();
  const {
    setConnected,
    setProjectId,
    addUser,
    removeUser,
    updateCursor,
    removeCursor,
    setLock,
    removeLock,
    setConnectionError,
    incrementReconnectAttempts,
    resetReconnectAttempts,
    reset,
    isConnected,
    reconnectAttempts,
  } = useCollaborationStore();

  const { setTimeline, addClip, deleteClip, updateClip } = useTimelineStore();

  // Color generator for user cursors
  const generateUserColor = useCallback((userId: string): string => {
    const colors = [
      '#ef4444', // red
      '#f97316', // orange
      '#eab308', // yellow
      '#22c55e', // green
      '#14b8a6', // teal
      '#3b82f6', // blue
      '#8b5cf6', // violet
      '#ec4899', // pink
    ];
    const hash = userId.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    return colors[hash % colors.length];
  }, []);

  // Connect to socket
  const connect = useCallback(() => {
    if (socketRef.current?.connected) return;
    if (!token) {
      setConnectionError('No authentication token');
      return;
    }

    const socket = io(SOCKET_URL, {
      auth: { token },
      transports: ['websocket', 'polling'],
      reconnection: false, // We'll handle reconnection ourselves
    });

    socketRef.current = socket;

    // Connection events
    socket.on('connect', () => {
      console.log('WebSocket connected');
      setConnected(true);
      resetReconnectAttempts();

      // Auto-join project if projectId is set
      if (projectId) {
        socket.emit('join_project', { projectId });
      }
    });

    socket.on('disconnect', (reason) => {
      console.log('WebSocket disconnected:', reason);
      setConnected(false);

      // Attempt reconnect unless intentionally closed
      if (reason !== 'io client disconnect' && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
        incrementReconnectAttempts();
        reconnectTimeoutRef.current = setTimeout(() => {
          connect();
        }, RECONNECT_DELAY * Math.pow(2, reconnectAttempts));
      }
    });

    socket.on('connect_error', (error) => {
      console.error('WebSocket connection error:', error.message);
      setConnectionError(error.message);
    });

    // Project events
    socket.on('project_joined', (data: { projectId: string; users: string[] }) => {
      setProjectId(data.projectId);
      // Initialize presence for existing users
      data.users.forEach((userId) => {
        if (userId !== user?.id) {
          addUser({
            userId,
            userName: userId, // Will be updated with actual name
            isActive: true,
            lastSeen: new Date(),
          });
        }
      });
    });

    socket.on('user_joined', (data: { userId: string; socketId: string; userInfo: any }) => {
      addUser({
        userId: data.userId,
        userName: data.userInfo?.username || data.userId,
        avatar: data.userInfo?.avatar,
        isActive: true,
        lastSeen: new Date(),
      });
    });

    socket.on('user_left', (data: { userId: string }) => {
      removeUser(data.userId);
      removeCursor(data.userId);
    });

    // Timeline sync events
    socket.on('timeline_update', (data: {
      userId: string;
      action: string;
      clipId?: string;
      changes: any;
    }) => {
      // Skip if from self
      if (data.userId === user?.id) return;

      switch (data.action) {
        case 'add_clip':
          if (data.changes) {
            addClip(data.changes as Clip);
          }
          break;
        case 'remove_clip':
          if (data.clipId) {
            deleteClip(data.clipId);
          }
          break;
        case 'update_clip':
          if (data.clipId && data.changes) {
            updateClip(data.clipId, data.changes);
          }
          break;
        case 'full_sync':
          if (data.changes) {
            setTimeline(data.changes);
          }
          break;
      }
    });

    socket.on('clip_changed', (data: { userId: string; clipId: string; properties: any }) => {
      if (data.userId !== user?.id) {
        updateClip(data.clipId, data.properties);
      }
    });

    // Cursor events
    socket.on('cursor_moved', (data: {
      userId: string;
      position: number;
      trackIndex?: number;
    }) => {
      const existing = useCollaborationStore.getState().cursors.get(data.userId);
      updateCursor({
        userId: data.userId,
        userName: existing?.userName || data.userId,
        color: existing?.color || generateUserColor(data.userId),
        position: data.position,
        trackIndex: data.trackIndex,
      });
    });

    // Playback sync
    socket.on('playback_sync', (_data: {
      userId: string;
      state: 'playing' | 'paused';
      position: number;
    }) => {
      // Optionally sync playback - could be user preference
      // useTimelineStore.getState().setCurrentTime(_data.position);
      // if (_data.state === 'playing') play(); else pause();
    });

    // Resource locking
    socket.on('lock_granted', (data: { resourceId: string; resourceType: string }) => {
      setLock({
        resourceId: data.resourceId,
        resourceType: data.resourceType as any,
        lockedBy: user?.id || '',
        lockedByName: user?.username || '',
        lockedAt: new Date(),
      });
    });

    socket.on('lock_denied', (data: { resourceId: string; lockedBy: string }) => {
      console.warn(`Lock denied for ${data.resourceId}, held by ${data.lockedBy}`);
      // Could show notification to user
    });

    socket.on('resource_locked', (data: {
      userId: string;
      resourceId: string;
      resourceType: string;
    }) => {
      const users = useCollaborationStore.getState().activeUsers;
      const lockedByUser = users.get(data.userId);

      setLock({
        resourceId: data.resourceId,
        resourceType: data.resourceType as any,
        lockedBy: data.userId,
        lockedByName: lockedByUser?.userName || data.userId,
        lockedAt: new Date(),
      });
    });

    socket.on('resource_unlocked', (data: { resourceId: string }) => {
      removeLock(data.resourceId);
    });

    // Chat events
    socket.on('chat_received', (data: {
      userId: string;
      userInfo: any;
      message: string;
      timestamp: number;
    }) => {
      // Chat messages could be handled by a separate chat store
      console.log('Chat message:', data);
    });

    // Typing indicators
    socket.on('user_typing', (_data: { userId: string }) => {
      // Could update UI to show typing indicator
    });

    socket.on('user_stopped_typing', (_data: { userId: string }) => {
      // Could update UI to hide typing indicator
    });

    // Export/AI progress
    socket.on('export_progress', (data: { exportId: string; progress: number; status: string }) => {
      console.log('Export progress:', data);
    });

    socket.on('ai_progress', (data: { analysisId: string; progress: number; status: string }) => {
      console.log('AI progress:', data);
    });
  }, [
    token,
    projectId,
    user,
    setConnected,
    setProjectId,
    addUser,
    removeUser,
    updateCursor,
    removeCursor,
    setLock,
    removeLock,
    setConnectionError,
    incrementReconnectAttempts,
    resetReconnectAttempts,
    reconnectAttempts,
    generateUserColor,
    addClip,
    deleteClip,
    updateClip,
    setTimeline,
  ]);

  // Disconnect from socket
  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    if (socketRef.current) {
      socketRef.current.disconnect();
      socketRef.current = null;
    }
    reset();
  }, [reset]);

  // Join a project
  const joinProject = useCallback((pid: string) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('join_project', { projectId: pid });
    }
  }, []);

  // Leave a project
  const leaveProject = useCallback((pid: string) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('leave_project', { projectId: pid });
    }
    reset();
  }, [reset]);

  // Emit timeline edit
  const emitTimelineEdit = useCallback((action: string, clipId?: string, changes?: any) => {
    if (socketRef.current?.connected && projectId) {
      socketRef.current.emit('timeline_edit', {
        projectId,
        action,
        clipId,
        changes,
      });
    }
  }, [projectId]);

  // Emit clip update
  const emitClipUpdate = useCallback((clipId: string, properties: any) => {
    if (socketRef.current?.connected && projectId) {
      socketRef.current.emit('clip_update', {
        projectId,
        clipId,
        properties,
      });
    }
  }, [projectId]);

  // Emit cursor movement
  const emitCursorMove = useCallback((position: number, trackIndex?: number) => {
    if (socketRef.current?.connected && projectId) {
      socketRef.current.emit('cursor_move', {
        projectId,
        position,
        trackIndex,
      });
    }
  }, [projectId]);

  // Emit playback state
  const emitPlaybackState = useCallback((state: 'playing' | 'paused', position: number) => {
    if (socketRef.current?.connected && projectId) {
      socketRef.current.emit('playback_state', {
        projectId,
        state,
        position,
      });
    }
  }, [projectId]);

  // Request resource lock
  const requestLock = useCallback((resourceId: string, resourceType: 'clip' | 'track' | 'timeline') => {
    if (socketRef.current?.connected && projectId) {
      socketRef.current.emit('request_lock', {
        projectId,
        resourceId,
        resourceType,
      });
    }
  }, [projectId]);

  // Release resource lock
  const releaseLock = useCallback((resourceId: string) => {
    if (socketRef.current?.connected && projectId) {
      socketRef.current.emit('release_lock', {
        projectId,
        resourceId,
      });
      removeLock(resourceId);
    }
  }, [projectId, removeLock]);

  // Send chat message
  const sendChatMessage = useCallback((message: string) => {
    if (socketRef.current?.connected && projectId) {
      socketRef.current.emit('chat_message', {
        projectId,
        message,
      });
    }
  }, [projectId]);

  // Auto-connect on mount
  useEffect(() => {
    if (autoConnect && token && projectId) {
      connect();
    }

    return () => {
      disconnect();
    };
  }, [autoConnect, token, projectId, connect, disconnect]);

  // Rejoin project when projectId changes
  useEffect(() => {
    if (socketRef.current?.connected && projectId) {
      joinProject(projectId);
    }
  }, [projectId, joinProject]);

  return {
    isConnected,
    connect,
    disconnect,
    joinProject,
    leaveProject,
    emitTimelineEdit,
    emitClipUpdate,
    emitCursorMove,
    emitPlaybackState,
    requestLock,
    releaseLock,
    sendChatMessage,
  };
}
