import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ProjectGrid } from '../components/dashboard';
import { useAuthStore, useProjectStore } from '../stores';

export function DashboardPage() {
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const { projects, isLoading, fetchProjects, createProject, deleteProject } =
    useProjectStore();

  useEffect(() => {
    fetchProjects();
  }, [fetchProjects]);

  const handleOpenProject = (projectId: string) => {
    navigate(`/editor/${projectId}`);
  };

  const handleCreateProject = async () => {
    const name = prompt('Project name:');
    if (name) {
      try {
        const project = await createProject({ name, description: 'New project' });
        navigate(`/editor/${project.id}`);
      } catch {
        // Error handled by store
      }
    }
  };

  const handleDeleteProject = async (projectId: string) => {
    try {
      await deleteProject(projectId);
    } catch {
      // Error handled by store
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="app">
      <header className="header">
        <h1>Guabanex Nova</h1>
        <div>
          <span>Welcome, {user?.firstName || user?.username}!</span>
          <button onClick={handleLogout} className="logout-btn">
            Logout
          </button>
        </div>
      </header>
      <main>
        <ProjectGrid
          projects={projects}
          isLoading={isLoading}
          onOpenProject={handleOpenProject}
          onCreateProject={handleCreateProject}
          onDeleteProject={handleDeleteProject}
        />
      </main>
    </div>
  );
}
