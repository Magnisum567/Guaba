import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import { LoginForm } from '../components/auth';
import { useAuthStore } from '../stores';

export function LoginPage() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuthStore();

  useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  const handleSwitchToRegister = () => {
    navigate('/register');
  };

  return <LoginForm onSwitchToRegister={handleSwitchToRegister} />;
}
