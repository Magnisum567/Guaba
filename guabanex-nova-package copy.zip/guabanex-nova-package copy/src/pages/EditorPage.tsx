import { useEffect, useState, useRef, useCallback, type ChangeEvent, type MouseEvent as ReactMouseEvent } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  useProjectStore,
  useMediaStore,
  useTimelineStore,
  useTextToEditStore,
} from '../stores';
import { autoEdit, chatbot } from '../api';
import type { ChatMessage, ColorGrading } from '../types';
import { TextToEditModal } from '../components/ai/TextToEdit';
import { ExportModal } from '../components/editor/ExportModal';
import { VideoPlayer } from '../components/editor/VideoPlayer';
import { Properties } from '../components/editor/Properties';
import { AISuggestions } from '../components/editor/AISuggestions';

export function EditorPage() {
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();

  const { currentProject, fetchProject } = useProjectStore();
  const { assets, selectedAssetIds, fetchMedia, uploadMedia, toggleSelection } =
    useMediaStore();
  const {
    timeline,
    currentTime,
    isPlaying,
    setTimeline,
    setCurrentTime,
    togglePlayback,
    selectedClipIds,
    selectClip,
    splitClip,
    updateClip,
    deleteClip,
    addClip,
    zoom,
  } = useTimelineStore();
  const { openModal: openTextToEdit } = useTextToEditStore();

  // Local state for legacy features (will be migrated)
  const [uploading, setUploading] = useState(false);
  const [showAutoEdit, setShowAutoEdit] = useState(false);
  const [showExport, setShowExport] = useState(false);
  const [showAISuggestions, setShowAISuggestions] = useState(false);
  const [script, setScript] = useState('');
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewPoster, setPreviewPoster] = useState<string | null>(null);
  const [autoEditing, setAutoEditing] = useState(false);
  const [isDraggingPlayhead, setIsDraggingPlayhead] = useState(false);
  const [cuttingMode, setCuttingMode] = useState(false);
  const [draggingAsset, setDraggingAsset] = useState<typeof assets[0] | null>(null);
  const [dropIndicator, setDropIndicator] = useState<{ trackIndex: number; time: number } | null>(null);
  const [draggingClip, setDraggingClip] = useState<{ id: string; startX: number; originalStartTime: number } | null>(null);
  const timelineRef = useRef<HTMLDivElement>(null);
  const timelineScrollRef = useRef<HTMLDivElement>(null);

  // Timeline constants
  const pixelsPerSecond = 50 * zoom;
  const timelineDuration = Math.max(timeline?.duration || 60, 60); // Minimum 60 seconds

  // Chatbot state
  const [showChatbot, setShowChatbot] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      role: 'assistant',
      content: "Hi! I'm your AI video editing assistant. How can I help you today?",
    },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const chatMessagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (projectId) {
      fetchProject(projectId);
      fetchMedia(projectId);
    }
  }, [projectId, fetchProject, fetchMedia]);

  // Create default timeline if none loaded (works without backend)
  useEffect(() => {
    if (currentProject?.timelines?.[0]) {
      setTimeline(currentProject.timelines[0]);
    } else if (!timeline) {
      // Create a default timeline so the editor works without backend
      setTimeline({
        id: `timeline-${Date.now()}`,
        projectId: projectId || 'demo-project',
        name: 'Main Timeline',
        duration: 60,
        tracks: [
          { id: 'video-1', name: 'Video 1', type: 'video', muted: false, locked: false, height: 60 },
          { id: 'audio-1', name: 'Audio 1', type: 'audio', muted: false, locked: false, height: 40 },
        ],
        markers: [],
        clips: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    }
  }, [currentProject, setTimeline, timeline, projectId]);

  useEffect(() => {
    if (chatMessagesEndRef.current) {
      chatMessagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages]);

  const handleFileUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    try {
      // Try backend upload first
      if (projectId) {
        await uploadMedia(projectId, files);
      }
    } catch {
      // If backend fails, create local media assets
      console.log('Backend unavailable, using local files');
    }

    // Always add files locally as fallback
    const localAssets = Array.from(files).map((file) => {
      const url = URL.createObjectURL(file);
      const isVideo = file.type.startsWith('video/');
      const isAudio = file.type.startsWith('audio/');
      const isImage = file.type.startsWith('image/');

      return {
        id: `local-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        projectId: projectId || 'demo-project',
        userId: 'local-user',
        filename: file.name,
        originalName: file.name,
        type: isVideo ? 'VIDEO' : isAudio ? 'AUDIO' : isImage ? 'IMAGE' : 'VIDEO',
        mimeType: file.type,
        size: file.size,
        duration: isVideo || isAudio ? 10 : undefined, // Default duration
        url: url,
        thumbnailUrl: isImage ? url : undefined,
        metadata: {},
        aiMetadata: {},
        status: 'READY',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      } as typeof assets[0];
    });

    // Add local assets to the store
    useMediaStore.setState((state) => ({
      assets: [...state.assets, ...localAssets],
    }));

    setUploading(false);
  };

  // Helper to get full URL (handles both local blob URLs and server URLs)
  const getFullUrl = (url: string) => {
    if (url.startsWith('blob:') || url.startsWith('http')) {
      return url;
    }
    return `http://localhost:3001${url}`;
  };

  const handleMediaClick = (asset: typeof assets[0]) => {
    toggleSelection(asset.id);

    // If it's a video or audio, set it as the preview
    if (asset.type === 'VIDEO' || asset.type === 'AUDIO') {
      setPreviewUrl(getFullUrl(asset.url));
      setPreviewPoster(asset.thumbnailUrl ? getFullUrl(asset.thumbnailUrl) : null);
    } else if (asset.type === 'IMAGE') {
      // For images, show them in the preview as well
      setPreviewUrl(null);
      setPreviewPoster(getFullUrl(asset.url));
    }
  };

  // Double-click to add media to timeline
  const handleMediaDoubleClick = async (asset: typeof assets[0]) => {
    if (!timeline) return;

    const trackIndex = asset.type === 'AUDIO' ? 1 : 0;
    const duration = asset.duration || 5;

    const trackClips = timeline.clips?.filter((c) => c.trackIndex === trackIndex) || [];
    const lastEndTime = trackClips.reduce((max, c) => Math.max(max, c.endTime), 0);

    try {
      const newClip = await addClip({
        timelineId: timeline.id,
        mediaAssetId: asset.id,
        mediaAsset: asset, // Pass full media asset for display
        trackIndex,
        startTime: lastEndTime,
        endTime: lastEndTime + duration,
        inPoint: 0,
        outPoint: duration,
        properties: {
          volume: 100,
          speed: 1,
          opacity: 100,
          effects: [],
        },
        aiSuggestions: {},
      });
      // Auto-select the newly added clip
      if (newClip) {
        selectClip(newClip.id);
      }
    } catch (error) {
      console.error('Failed to add clip:', error);
    }
  };

  // Drag and Drop handlers for media items
  const handleDragStart = (e: React.DragEvent, asset: typeof assets[0]) => {
    setDraggingAsset(asset);
    e.dataTransfer.effectAllowed = 'copy';
    e.dataTransfer.setData('application/json', JSON.stringify({ assetId: asset.id }));

    // Create a custom drag image
    const dragImage = document.createElement('div');
    dragImage.className = 'drag-ghost';
    dragImage.textContent = asset.originalName || asset.filename;
    dragImage.style.cssText = `
      position: absolute;
      top: -1000px;
      padding: 8px 16px;
      background: linear-gradient(90deg, #6366f1, #8b5cf6);
      color: white;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 500;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      white-space: nowrap;
    `;
    document.body.appendChild(dragImage);
    e.dataTransfer.setDragImage(dragImage, 0, 0);
    setTimeout(() => document.body.removeChild(dragImage), 0);
  };

  const handleDragEnd = () => {
    setDraggingAsset(null);
    setDropIndicator(null);
  };

  const handleTrackDragOver = (e: React.DragEvent, trackIndex: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';

    // Calculate drop position in time
    const trackContent = e.currentTarget as HTMLElement;
    const rect = trackContent.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const time = Math.max(0, x / pixelsPerSecond);

    // Snap to 0.5 second increments (or exact if shift is held)
    const snappedTime = e.shiftKey ? time : Math.round(time * 2) / 2;

    setDropIndicator({ trackIndex, time: snappedTime });
  };

  const handleTrackDragLeave = (e: React.DragEvent) => {
    // Only clear if leaving the track entirely
    const relatedTarget = e.relatedTarget as HTMLElement;
    if (!relatedTarget || !e.currentTarget.contains(relatedTarget)) {
      setDropIndicator(null);
    }
  };

  const handleTrackDrop = async (e: React.DragEvent, trackIndex: number) => {
    e.preventDefault();

    if (!draggingAsset || !timeline || !dropIndicator) return;

    const asset = draggingAsset;
    const duration = asset.duration || 5;
    const startTime = dropIndicator.time;

    try {
      const newClip = await addClip({
        timelineId: timeline.id,
        mediaAssetId: asset.id,
        mediaAsset: asset,
        trackIndex,
        startTime,
        endTime: startTime + duration,
        inPoint: 0,
        outPoint: duration,
        properties: {
          volume: 100,
          speed: 1,
          opacity: 100,
          effects: [],
        },
        aiSuggestions: {},
      });

      if (newClip) {
        selectClip(newClip.id);
      }
    } catch (error) {
      console.error('Failed to add clip via drag:', error);
    }

    setDraggingAsset(null);
    setDropIndicator(null);
  };

  // Clip dragging handlers (for moving clips on timeline)
  const handleClipDragStart = (e: React.MouseEvent, clipId: string, startTime: number) => {
    e.preventDefault();
    e.stopPropagation();

    const clip = timeline?.clips?.find((c) => c.id === clipId);

    // If in cutting mode, split the clip at click position
    if (cuttingMode && clip) {
      const rect = (e.target as HTMLElement).getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const clickTime = clip.startTime + (clickX / pixelsPerSecond);

      if (clickTime > clip.startTime && clickTime < clip.endTime) {
        splitClip(clipId, clickTime);
      }
      return;
    }

    // Start dragging
    setDraggingClip({
      id: clipId,
      startX: e.clientX,
      originalStartTime: startTime,
    });

    // Select the clip
    selectClip(clipId, e.shiftKey || e.metaKey);

    // Load preview
    if (clip?.mediaAsset) {
      const asset = clip.mediaAsset;
      if (asset.type === 'VIDEO' || asset.type === 'AUDIO') {
        setPreviewUrl(getFullUrl(asset.url));
        setPreviewPoster(asset.thumbnailUrl ? getFullUrl(asset.thumbnailUrl) : null);
      }
    }
  };

  useEffect(() => {
    if (!draggingClip) return;

    const handleMouseMove = (e: MouseEvent) => {
      const deltaX = e.clientX - draggingClip.startX;
      const deltaTime = deltaX / pixelsPerSecond;
      const newStartTime = Math.max(0, draggingClip.originalStartTime + deltaTime);

      // Snap to 0.5 second increments (or exact if shift is held)
      const snappedTime = e.shiftKey ? newStartTime : Math.round(newStartTime * 2) / 2;

      const clip = timeline?.clips?.find(c => c.id === draggingClip.id);
      if (clip) {
        const duration = clip.endTime - clip.startTime;
        updateClip(draggingClip.id, {
          startTime: snappedTime,
          endTime: snappedTime + duration,
        });
      }
    };

    const handleMouseUp = () => {
      setDraggingClip(null);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [draggingClip, pixelsPerSecond, timeline?.clips, updateClip]);

  // Get the currently selected clip
  const selectedClip = timeline?.clips?.find((c) => selectedClipIds.has(c.id)) || null;

  // Toggle cutting mode
  const toggleCuttingMode = () => {
    setCuttingMode(!cuttingMode);
  };

  // Handle clip updates from Properties panel
  const handleUpdateClip = async (clipId: string, updates: any) => {
    try {
      await updateClip(clipId, updates);
    } catch (error) {
      console.error('Failed to update clip:', error);
    }
  };

  // Handle clip split
  const handleSplitClip = (clipId: string, splitTime: number) => {
    splitClip(clipId, splitTime);
  };

  // Handle clip delete
  const handleDeleteClip = async (clipId: string) => {
    try {
      await deleteClip(clipId);
    } catch (error) {
      console.error('Failed to delete clip:', error);
    }
  };

  // Playhead/Scrubber handlers
  const getTimeFromMousePosition = useCallback((clientX: number): number => {
    if (!timelineRef.current) return 0;
    const rect = timelineRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const time = x / pixelsPerSecond;
    return Math.max(0, Math.min(time, timelineDuration));
  }, [pixelsPerSecond, timelineDuration]);

  const handleTimelineClick = (e: ReactMouseEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement;
    // Don't seek if clicking on a clip or playhead
    if (target.closest('.clip') || target.closest('.playhead')) {
      return;
    }
    const time = getTimeFromMousePosition(e.clientX);
    setCurrentTime(time);
  };

  const handlePlayheadMouseDown = (e: ReactMouseEvent) => {
    e.preventDefault();
    setIsDraggingPlayhead(true);
  };

  useEffect(() => {
    if (!isDraggingPlayhead) return;

    const handleMouseMove = (e: MouseEvent) => {
      const time = getTimeFromMousePosition(e.clientX);
      setCurrentTime(time);
    };

    const handleMouseUp = () => {
      setIsDraggingPlayhead(false);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDraggingPlayhead, getTimeFromMousePosition, setCurrentTime]);

  // Generate time ruler marks
  const generateTimeMarks = () => {
    const marks = [];
    const interval = zoom >= 1 ? 5 : zoom >= 0.5 ? 10 : 30; // Seconds between major marks
    for (let t = 0; t <= timelineDuration; t += interval) {
      marks.push(t);
    }
    return marks;
  };

  const handleAutoEdit = async () => {
    if (!script.trim() || selectedAssetIds.size === 0 || !projectId) {
      alert('Please provide a script and select at least one media file');
      return;
    }

    setAutoEditing(true);
    try {
      await autoEdit.create({
        projectId,
        script,
        mediaAssetIds: Array.from(selectedAssetIds),
      });

      alert('Auto-edit completed! Your timeline has been generated.');
      setShowAutoEdit(false);
      setScript('');
      // Refresh project to get new timeline
      fetchProject(projectId);
    } catch (error: any) {
      alert('Auto-edit failed: ' + (error.response?.data?.error || 'Unknown error'));
    } finally {
      setAutoEditing(false);
    }
  };

  const handleSendMessage = async () => {
    if (!chatInput.trim()) return;

    const userMessage = chatInput;
    setChatInput('');
    setChatMessages((prev) => [...prev, { role: 'user', content: userMessage }]);
    setChatLoading(true);

    try {
      const response = await chatbot.sendMessage(userMessage, { projectId });
      setChatMessages((prev) => [
        ...prev,
        { role: 'assistant', content: response.data.response },
      ]);
    } catch {
      setChatMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'Sorry, I encountered an error. Please try again.' },
      ]);
    } finally {
      setChatLoading(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="app">
      <header className="header">
        <button onClick={() => navigate('/dashboard')} className="back-btn">
          Back to Projects
        </button>
        <div className="header-brand">
          <span className="brand-name">Guabanex Nova</span>
          {currentProject?.name && <span className="project-name">{currentProject.name}</span>}
        </div>
        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button
            className={`btn-ai ${showAISuggestions ? 'active' : ''}`}
            onClick={() => setShowAISuggestions(!showAISuggestions)}
            title="AI Assistant"
          >
            <svg viewBox="0 0 24 24" width="16" height="16" style={{ marginRight: '0.25rem' }}>
              <path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
            </svg>
            AI
          </button>
          <button className="btn-primary" onClick={() => setShowAutoEdit(true)}>
            Auto-Edit
          </button>
          <button className="btn-primary" onClick={openTextToEdit}>
            Text-to-Edit
          </button>
          <button className="btn-secondary" onClick={() => setShowExport(true)}>Export</button>
        </div>
      </header>

      <main className="editor">
        {/* Media Library Sidebar */}
        <div className="editor-sidebar">
          <h3>Media Library</h3>
          <div
            className="media-upload"
            onClick={() => document.getElementById('file-input')?.click()}
          >
            <input
              id="file-input"
              type="file"
              accept="video/*,image/*,audio/*"
              multiple
              onChange={handleFileUpload}
            />
            <label>
              {uploading ? (
                <>
                  <div className="spinner"></div>
                  <p>Uploading...</p>
                </>
              ) : (
                <p>Click to upload media</p>
              )}
            </label>
          </div>
          <div className="media-list">
            {assets.length === 0 ? (
              <p className="empty">No media files yet</p>
            ) : (
              assets.map((asset) => (
                <div
                  key={asset.id}
                  className={`media-item ${selectedAssetIds.has(asset.id) ? 'selected' : ''} ${draggingAsset?.id === asset.id ? 'dragging' : ''}`}
                  onClick={() => handleMediaClick(asset)}
                  onDoubleClick={() => handleMediaDoubleClick(asset)}
                  draggable
                  onDragStart={(e) => handleDragStart(e, asset)}
                  onDragEnd={handleDragEnd}
                  style={{
                    borderColor: selectedAssetIds.has(asset.id)
                      ? 'var(--primary)'
                      : 'var(--border)',
                    background: selectedAssetIds.has(asset.id)
                      ? 'var(--bg-secondary)'
                      : 'var(--bg-tertiary)',
                    cursor: 'grab',
                  }}
                  title="Drag to timeline or double-click to add"
                >
                  {asset.thumbnailUrl && (
                    <img
                      src={getFullUrl(asset.thumbnailUrl)}
                      alt={asset.filename}
                      draggable={false}
                      style={{ width: '100%', height: '60px', objectFit: 'cover', borderRadius: '4px', marginBottom: '0.5rem' }}
                    />
                  )}
                  <p style={{ fontWeight: 500, marginBottom: '0.25rem', fontSize: '0.8rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {asset.originalName || asset.filename}
                  </p>
                  <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                    {asset.type} {asset.duration ? `• ${Math.floor(asset.duration / 60)}:${Math.floor(asset.duration % 60).toString().padStart(2, '0')}` : ''}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Main Editor Area */}
        <div className="editor-main">
          <div className="preview">
            <VideoPlayer
              src={previewUrl || undefined}
              poster={previewPoster || undefined}
            />
          </div>
          <div className={`timeline ${cuttingMode ? 'cutting-mode' : ''}`}>
            <div className="timeline-header">
              <div className="timeline-tools">
                <button
                  className={`tool-btn ${!cuttingMode ? 'active' : ''}`}
                  onClick={() => setCuttingMode(false)}
                  title="Selection Tool (V)"
                >
                  <svg viewBox="0 0 24 24" width="16" height="16">
                    <path fill="currentColor" d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z"/>
                  </svg>
                </button>
                <button
                  className={`tool-btn ${cuttingMode ? 'active' : ''}`}
                  onClick={toggleCuttingMode}
                  title="Razor/Cut Tool (C)"
                >
                  <svg viewBox="0 0 24 24" width="16" height="16">
                    <path fill="currentColor" d="M9.64 7.64c.23-.5.36-1.05.36-1.64 0-2.21-1.79-4-4-4S2 3.79 2 6s1.79 4 4 4c.59 0 1.14-.13 1.64-.36L10 12l-2.36 2.36C7.14 14.13 6.59 14 6 14c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4c0-.59-.13-1.14-.36-1.64L12 14l7 7h3v-1L9.64 7.64zM6 8c-1.1 0-2-.89-2-2s.9-2 2-2 2 .89 2 2-.9 2-2 2zm0 12c-1.1 0-2-.89-2-2s.9-2 2-2 2 .89 2 2-.9 2-2 2zm6-7.5c-.28 0-.5-.22-.5-.5s.22-.5.5-.5.5.22.5.5-.22.5-.5.5zM19 3l-6 6 2 2 7-7V3h-3z"/>
                  </svg>
                </button>
                <div className="tool-divider"></div>
                <button className="tool-btn" onClick={() => selectedClip && handleSplitClip(selectedClip.id, currentTime)} title="Split at Playhead (S)" disabled={!selectedClip}>
                  <svg viewBox="0 0 24 24" width="16" height="16">
                    <path fill="currentColor" d="M11 2v20h2V2h-2zm-4 8v4h2v-4H7zm8 0v4h2v-4h-2z"/>
                  </svg>
                </button>
                <button className="tool-btn" onClick={() => selectedClip && handleDeleteClip(selectedClip.id)} title="Delete Clip (Del)" disabled={!selectedClip}>
                  <svg viewBox="0 0 24 24" width="16" height="16">
                    <path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
                  </svg>
                </button>
              </div>
              <div className="timeline-playback">
                <button className="play-btn" onClick={togglePlayback} title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}>
                  {isPlaying ? '⏸' : '▶'}
                </button>
                <span className="current-time">{formatTime(currentTime)}</span>
                <span className="duration-separator">/</span>
                <span className="total-time">{formatTime(timelineDuration)}</span>
              </div>
            </div>

            {/* Time Ruler */}
            <div
              className="time-ruler"
              ref={timelineRef}
              onClick={handleTimelineClick}
              style={{ width: `${timelineDuration * pixelsPerSecond}px` }}
            >
              <div className="ruler-area">
                {generateTimeMarks().map((time) => (
                  <div
                    key={time}
                    className="ruler-mark"
                    style={{ left: `${time * pixelsPerSecond}px` }}
                  >
                    <span className="ruler-label">{formatTime(time)}</span>
                  </div>
                ))}
              </div>

              {/* Playhead */}
              <div
                className="playhead"
                style={{ left: `${currentTime * pixelsPerSecond}px` }}
                onMouseDown={handlePlayheadMouseDown}
              >
                <div className="playhead-head"></div>
                <div className="playhead-line"></div>
              </div>
            </div>

            {/* Timeline Scrubber Area (for seeking) */}
            <div
              className="timeline-scrubber"
              ref={timelineScrollRef}
              onClick={handleTimelineClick}
              style={{ width: `${timelineDuration * pixelsPerSecond}px` }}
            >
              {/* Playhead Line extends through tracks */}
              <div
                className="playhead-track-line"
                style={{ left: `${currentTime * pixelsPerSecond}px` }}
              ></div>

              <div className="timeline-tracks">
                <div className="track">
                  <span>Video</span>
                  <div
                    className={`track-content ${draggingAsset ? 'drop-target' : ''} ${dropIndicator?.trackIndex === 0 ? 'drop-active' : ''}`}
                    onClick={handleTimelineClick}
                    onDragOver={(e) => handleTrackDragOver(e, 0)}
                    onDragLeave={handleTrackDragLeave}
                    onDrop={(e) => handleTrackDrop(e, 0)}
                  >
                    {/* Drop Indicator */}
                    {dropIndicator?.trackIndex === 0 && draggingAsset && (
                      <div
                        className="drop-indicator"
                        style={{
                          left: `${dropIndicator.time * pixelsPerSecond}px`,
                          width: `${(draggingAsset.duration || 5) * pixelsPerSecond}px`,
                        }}
                      >
                        <span className="drop-indicator-label">{draggingAsset.originalName || draggingAsset.filename}</span>
                      </div>
                    )}
                    {timeline?.clips
                      ?.filter((c) => c.trackIndex === 0)
                      .map((clip) => {
                        const isSelected = selectedClipIds.has(clip.id);
                        const isDragging = draggingClip?.id === clip.id;
                        return (
                          <div
                            key={clip.id}
                            className={`clip${isSelected ? ' selected' : ''}${isDragging ? ' dragging' : ''}`}
                            style={{
                              left: clip.startTime * pixelsPerSecond,
                              width: Math.max(30, (clip.endTime - clip.startTime) * pixelsPerSecond),
                            }}
                            onMouseDown={(e) => handleClipDragStart(e, clip.id, clip.startTime)}
                          >
                            {clip.mediaAsset?.originalName || clip.mediaAsset?.filename || 'Clip'}
                          </div>
                        );
                      })}
                  </div>
                </div>
                <div className="track">
                  <span>Audio</span>
                  <div
                    className={`track-content ${draggingAsset ? 'drop-target' : ''} ${dropIndicator?.trackIndex === 1 ? 'drop-active' : ''}`}
                    onClick={handleTimelineClick}
                    onDragOver={(e) => handleTrackDragOver(e, 1)}
                    onDragLeave={handleTrackDragLeave}
                    onDrop={(e) => handleTrackDrop(e, 1)}
                  >
                    {/* Drop Indicator */}
                    {dropIndicator?.trackIndex === 1 && draggingAsset && (
                      <div
                        className="drop-indicator audio"
                        style={{
                          left: `${dropIndicator.time * pixelsPerSecond}px`,
                          width: `${(draggingAsset.duration || 5) * pixelsPerSecond}px`,
                        }}
                      >
                        <span className="drop-indicator-label">{draggingAsset.originalName || draggingAsset.filename}</span>
                      </div>
                    )}
                    {timeline?.clips
                      ?.filter((c) => c.trackIndex === 1)
                      .map((clip) => {
                        const isSelected = selectedClipIds.has(clip.id);
                        const isDragging = draggingClip?.id === clip.id;
                        return (
                          <div
                            key={clip.id}
                            className={`clip audio${isSelected ? ' selected' : ''}${isDragging ? ' dragging' : ''}`}
                            style={{
                              left: clip.startTime * pixelsPerSecond,
                              width: Math.max(30, (clip.endTime - clip.startTime) * pixelsPerSecond),
                            }}
                            onMouseDown={(e) => handleClipDragStart(e, clip.id, clip.startTime)}
                          >
                            {clip.mediaAsset?.originalName || clip.mediaAsset?.filename || 'Clip'}
                          </div>
                        );
                      })}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Panels Container */}
        <div className="editor-right-panels">
          {/* AI Suggestions Panel */}
          {showAISuggestions && (
            <AISuggestions
              mediaAssets={assets}
              clips={timeline?.clips || []}
              timelineDuration={timelineDuration}
              selectedClip={selectedClip}
              onAddClip={(clipData) => addClip(clipData)}
              onApplyColorGrading={(clipId: string, grading: ColorGrading) => {
                handleUpdateClip(clipId, { properties: { colorGrading: grading } });
              }}
              currentTime={currentTime}
            />
          )}

          {/* Properties Panel */}
          <Properties
            selectedClip={selectedClip}
            onUpdateClip={handleUpdateClip}
            onSplitClip={handleSplitClip}
            onDeleteClip={handleDeleteClip}
            currentTime={currentTime}
          />
        </div>
      </main>

      {/* Auto-Edit Modal */}
      {showAutoEdit && (
        <div className="modal-overlay" onClick={() => setShowAutoEdit(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>AI Auto-Edit</h2>
              <p>Upload your script and let AI create your video automatically</p>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Your Script</label>
                <textarea
                  value={script}
                  onChange={(e) => setScript(e.target.value)}
                  placeholder="Enter your script here...

Examples:
[00:05] Opening scene with logo
[00:10] Introduce the product
[00:20] Show features
[00:30] Call to action

Or use plain text:
1. Start with an attention-grabbing intro
2. Explain the main concept
3. Add supporting details
4. End with a strong conclusion"
                />
                <p className="form-hint">
                  Use timestamps [MM:SS] or plain text. Each paragraph becomes a scene.
                </p>
              </div>
              <div className="form-group">
                <label>Selected Media ({selectedAssetIds.size} files)</label>
                <p className="form-hint">
                  {selectedAssetIds.size === 0
                    ? 'Select media files from the library to use in your video'
                    : `${selectedAssetIds.size} media file(s) selected`}
                </p>
              </div>
            </div>
            <div className="modal-footer">
              <button
                className="btn-secondary"
                onClick={() => setShowAutoEdit(false)}
                disabled={autoEditing}
              >
                Cancel
              </button>
              <button
                className="btn-primary"
                onClick={handleAutoEdit}
                disabled={autoEditing || !script.trim() || selectedAssetIds.size === 0}
              >
                {autoEditing ? (
                  <>
                    <span className="spinner" style={{ marginRight: '0.5rem' }}></span>
                    Generating...
                  </>
                ) : (
                  'Generate Video'
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Text-to-Edit Modal */}
      <TextToEditModal />

      {/* Export Modal */}
      <ExportModal isOpen={showExport} onClose={() => setShowExport(false)} />

      {/* AI Chatbot */}
      <div className="chatbot-container">
        {showChatbot && (
          <div className="chatbot-window">
            <div className="chatbot-header">
              <span>AI Assistant</span>
              <button className="chatbot-close" onClick={() => setShowChatbot(false)}>
                x
              </button>
            </div>
            <div className="chatbot-messages">
              {chatMessages.map((msg, idx) => (
                <div key={idx} className={`chatbot-message ${msg.role}`}>
                  {msg.content}
                </div>
              ))}
              {chatLoading && (
                <div className="chatbot-message assistant">
                  <span className="spinner"></span> Thinking...
                </div>
              )}
              <div ref={chatMessagesEndRef} />
            </div>
            <div className="chatbot-input-container">
              <input
                type="text"
                placeholder="Ask me anything..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                disabled={chatLoading}
              />
              <button onClick={handleSendMessage} disabled={chatLoading || !chatInput.trim()}>
                Send
              </button>
            </div>
          </div>
        )}
        <button className="chatbot-toggle" onClick={() => setShowChatbot(!showChatbot)}>
          {showChatbot ? 'x' : 'AI'}
        </button>
      </div>
    </div>
  );
}
