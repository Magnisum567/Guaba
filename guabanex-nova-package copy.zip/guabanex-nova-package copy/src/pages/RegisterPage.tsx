import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import { RegisterForm } from '../components/auth';
import { useAuthStore } from '../stores';

export function RegisterPage() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuthStore();

  useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  const handleSwitchToLogin = () => {
    navigate('/login');
  };

  return <RegisterForm onSwitchToLogin={handleSwitchToLogin} />;
}
