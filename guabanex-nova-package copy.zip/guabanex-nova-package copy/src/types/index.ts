// User types
export interface User {
  id: string;
  email: string;
  username: string;
  firstName?: string;
  lastName?: string;
  role: 'USER' | 'EDITOR' | 'ADMIN';
  avatar?: string;
  createdAt: string;
}

// Project types
export interface Project {
  id: string;
  name: string;
  description?: string;
  thumbnail?: string;
  duration: number;
  frameRate: number;
  resolution: string;
  status: 'DRAFT' | 'IN_PROGRESS' | 'REVIEW' | 'COMPLETED' | 'ARCHIVED';
  settings: Record<string, any>;
  aiSettings: Record<string, any>;
  userId: string;
  createdAt: string;
  updatedAt: string;
  lastOpenedAt?: string;
  timelines?: Timeline[];
  mediaAssets?: MediaAsset[];
  _count?: {
    mediaAssets: number;
    collaborations: number;
  };
}

// Timeline types
export interface Timeline {
  id: string;
  projectId: string;
  name: string;
  duration: number;
  tracks: Track[];
  markers: Marker[];
  clips?: Clip[];
  transitions?: Transition[];
  effects?: Effect[];
  createdAt: string;
  updatedAt: string;
}

export interface Track {
  id: string;
  name: string;
  type: 'video' | 'audio' | 'text';
  muted: boolean;
  locked: boolean;
  height: number;
}

export interface Clip {
  id: string;
  timelineId: string;
  mediaAssetId?: string;
  mediaAsset?: MediaAsset;
  trackIndex: number;
  startTime: number;
  endTime: number;
  inPoint: number;
  outPoint: number;
  properties: ClipProperties;
  aiSuggestions: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

export interface ColorGrading {
  brightness: number;
  contrast: number;
  saturation: number;
  temperature: number;
  tint: number;
  exposure: number;
  highlights: number;
  shadows: number;
  vibrance: number;
  hue: number;
  gamma: number;
  lutFile?: string;
  lutIntensity: number;
}

export interface ClipProperties {
  volume: number;
  speed: number;
  opacity: number;
  effects: string[];
  colorCorrection?: ColorCorrection;
  colorGrading?: ColorGrading;
  audioEffects?: AudioEffect[];
}

export interface ColorCorrection {
  exposure: number;
  contrast: number;
  saturation: number;
  temperature: number;
  tint: number;
  highlights: number;
  shadows: number;
}

export interface AudioEffect {
  type: string;
  properties: Record<string, any>;
}

export interface Transition {
  id: string;
  timelineId: string;
  type: 'fade' | 'dissolve' | 'wipe' | 'slide' | 'custom';
  duration: number;
  position: number;
  properties: Record<string, any>;
  aiGenerated: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Effect {
  id: string;
  timelineId: string;
  type: string;
  trackIndex: number;
  startTime: number;
  endTime: number;
  properties: Record<string, any>;
  aiGenerated: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Marker {
  id: string;
  time: number;
  label: string;
  color: string;
}

// Media types
export interface MediaAsset {
  id: string;
  projectId: string;
  userId: string;
  filename: string;
  originalName: string;
  type: 'VIDEO' | 'AUDIO' | 'IMAGE' | 'SEQUENCE';
  mimeType: string;
  size: number;
  duration?: number;
  url: string;
  thumbnailUrl?: string;
  proxyUrl?: string;
  metadata: MediaMetadata;
  aiMetadata: Record<string, any>;
  status: 'PENDING' | 'PROCESSING' | 'READY' | 'FAILED';
  createdAt: string;
  updatedAt: string;
}

export interface MediaMetadata {
  width?: number;
  height?: number;
  frameRate?: number;
  codec?: string;
  bitrate?: number;
  channels?: number;
  sampleRate?: number;
}

// Collaboration types
export interface Collaborator {
  id: string;
  userId: string;
  projectId: string;
  role: 'VIEWER' | 'COMMENTER' | 'EDITOR' | 'OWNER';
  user: User;
  invitedAt: string;
  acceptedAt?: string;
}

export interface CollaboratorCursor {
  userId: string;
  userName: string;
  color: string;
  position: number;
  trackIndex?: number;
}

export interface ResourceLock {
  resourceId: string;
  resourceType: 'clip' | 'track' | 'timeline';
  lockedBy: string;
  lockedByName: string;
  lockedAt: Date;
}

export interface PresenceInfo {
  userId: string;
  userName: string;
  avatar?: string;
  isActive: boolean;
  lastSeen: Date;
}

// Text-to-Edit types
export interface TextToEditRequest {
  projectId: string;
  prompt: string;
  settings: TextToEditSettings;
}

export interface TextToEditSettings {
  targetDuration?: number;
  includeTransitions: boolean;
  includeColorGrading: boolean;
  includeTextOverlays: boolean;
  audioMixing: boolean;
}

export interface ParsedPrompt {
  intent: EditIntent;
  parameters: {
    targetDuration?: number;
    clipSelectionCriteria?: string;
    style?: string;
    transitionType?: string;
  };
  constraints: {
    mustInclude?: string[];
    mustExclude?: string[];
    chronological?: boolean;
  };
}

export type EditIntent =
  | 'highlight_reel'
  | 'montage'
  | 'trim'
  | 'style_transfer'
  | 'color_grade'
  | 'add_transitions'
  | 'audio_mix'
  | 'text_overlay'
  | 'pacing_adjust'
  | 'composite';

export interface ClipSuggestion {
  mediaAssetId: string;
  mediaAsset: MediaAsset;
  thumbnailUrl: string;
  startTime: number;
  endTime: number;
  score: number;
  reason: string;
  isSelected: boolean;
  alternatives: ClipSuggestion[];
}

export interface DraftTimeline {
  id: string;
  clips: DraftClip[];
  transitions: DraftTransition[];
  effects: DraftEffect[];
  textOverlays: DraftTextOverlay[];
  totalDuration: number;
  previewUrl?: string;
}

export interface DraftClip {
  mediaAssetId: string;
  startTime: number;
  endTime: number;
  inPoint: number;
  outPoint: number;
  trackIndex: number;
}

export interface DraftTransition {
  type: string;
  duration: number;
  position: number;
  clipAIndex: number;
  clipBIndex: number;
}

export interface DraftEffect {
  type: string;
  trackIndex: number;
  startTime: number;
  endTime: number;
  properties: Record<string, any>;
}

export interface DraftTextOverlay {
  text: string;
  startTime: number;
  endTime: number;
  position: { x: number; y: number };
  style: TextOverlayStyle;
}

export interface TextOverlayStyle {
  fontSize: number;
  fontFamily: string;
  color: string;
  backgroundColor?: string;
  animation?: string;
}

// Chat types
export interface ChatMessage {
  id?: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp?: Date;
}

// AI Analysis types
export interface AIAnalysisCache {
  mediaAssetId: string;
  sceneAnalysis?: SceneAnalysis;
  emotionAnalysis?: EmotionAnalysis;
  styleAnalysis?: StyleAnalysis;
  analyzedAt: string;
  status: 'pending' | 'analyzing' | 'complete' | 'failed';
}

export interface SceneAnalysis {
  scenes: SceneSegment[];
  dominantObjects: string[];
  dominantActions: string[];
  overallDescription: string;
}

export interface SceneSegment {
  startTime: number;
  endTime: number;
  description: string;
  objects: string[];
  actions: string[];
  setting: string;
  confidence: number;
}

export interface EmotionAnalysis {
  segments: EmotionSegment[];
  dominantEmotion: string;
  emotionalArc: string;
  facesDetected: number;
}

export interface EmotionSegment {
  startTime: number;
  endTime: number;
  emotions: {
    emotion: string;
    confidence: number;
  }[];
  faces: number;
}

export interface StyleAnalysis {
  colorPalette: ColorInfo[];
  mood: string;
  visualStyle: string;
  lightingType: string;
  contrast: 'low' | 'medium' | 'high';
  saturation: 'desaturated' | 'neutral' | 'saturated' | 'vibrant';
  suggestedLUT: string;
  matchingStyles: StyleMatch[];
}

export interface ColorInfo {
  hex: string;
  name: string;
  percentage: number;
}

export interface StyleMatch {
  name: string;
  similarity: number;
  description: string;
}

// AI Editing Engine Types
export interface AIClipSuggestion {
  id: string;
  mediaAssetId: string;
  mediaAsset?: MediaAsset;
  suggestedTrackIndex: number;
  suggestedStartTime: number;
  suggestedEndTime: number;
  inPoint: number;
  outPoint: number;
  confidence: number;
  reason: string;
  category: 'highlight' | 'b-roll' | 'transition' | 'filler' | 'opening' | 'closing';
  tags: string[];
}

export interface SceneBoundary {
  id: string;
  timestamp: number;
  type: 'cut' | 'fade' | 'dissolve' | 'wipe' | 'motion';
  confidence: number;
  shotBefore: ShotInfo;
  shotAfter: ShotInfo;
}

export interface ShotInfo {
  type: 'wide' | 'medium' | 'close-up' | 'extreme-close-up' | 'establishing' | 'over-shoulder' | 'pov' | 'aerial';
  movement: 'static' | 'pan' | 'tilt' | 'zoom' | 'dolly' | 'tracking' | 'handheld' | 'crane';
  duration: number;
  description: string;
}

export interface ClipMetadata {
  mediaAssetId: string;
  tags: string[];
  emotions: EmotionTag[];
  shotType: ShotInfo['type'];
  movement: ShotInfo['movement'];
  people: number;
  objects: string[];
  setting: string;
  lighting: 'natural' | 'artificial' | 'mixed' | 'low-key' | 'high-key';
  audio: AudioMetadata;
}

export interface EmotionTag {
  emotion: string;
  intensity: number;
  timestamp: number;
}

export interface AudioMetadata {
  hasDialogue: boolean;
  hasMusic: boolean;
  hasSoundEffects: boolean;
  loudness: number;
  silencePercentage: number;
}

export interface CutSuggestion {
  id: string;
  clipId: string;
  timestamp: number;
  type: 'trim-start' | 'trim-end' | 'split' | 'remove';
  confidence: number;
  reason: string;
  frameAccurate: boolean;
}

export interface PacingAnalysis {
  overallPace: 'slow' | 'moderate' | 'fast' | 'dynamic';
  averageShotDuration: number;
  rhythmScore: number;
  suggestions: PacingSuggestion[];
  energyCurve: EnergyPoint[];
}

export interface PacingSuggestion {
  id: string;
  type: 'speed-up' | 'slow-down' | 'add-pause' | 'remove-gap' | 'reorder';
  startTime: number;
  endTime: number;
  reason: string;
  priority: 'low' | 'medium' | 'high';
}

export interface EnergyPoint {
  timestamp: number;
  energy: number;
  label?: string;
}

export interface TransitionSuggestion {
  id: string;
  fromClipId: string;
  toClipId: string;
  type: 'cut' | 'dissolve' | 'fade' | 'wipe' | 'zoom' | 'slide' | 'morph';
  duration: number;
  confidence: number;
  reason: string;
  contextMatch: number;
}

export interface ContentContext {
  timelineId: string;
  genre: string;
  mood: string;
  targetDuration: number;
  audienceType: string;
  editingStyle: 'cinematic' | 'documentary' | 'social-media' | 'commercial' | 'music-video';
}

// Cinematic Style Matching Types
export interface CinematicStyle {
  id: string;
  name: string;
  director?: string;
  film?: string;
  year?: number;
  description: string;
  characteristics: string[];
  colorGrading: ColorGrading;
  thumbnail?: string;
  category: 'director' | 'film' | 'genre' | 'era' | 'mood';
}

export interface StyleMatchResult {
  style: CinematicStyle;
  matchScore: number;
  matchReasons: string[];
  adjustments: Partial<ColorGrading>;
}

export interface AIColorSuggestion {
  id: string;
  type: 'auto-correct' | 'style-match' | 'mood-enhance' | 'scene-match';
  title: string;
  description: string;
  beforeGrading: Partial<ColorGrading>;
  afterGrading: ColorGrading;
  confidence: number;
  previewUrl?: string;
}
