import type { Project } from '../../types';

interface ProjectCardProps {
  project: Project;
  onOpen: (projectId: string) => void;
  onDelete?: (projectId: string) => void;
}

export function ProjectCard({ project, onOpen, onDelete }: ProjectCardProps) {
  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onDelete && confirm(`Delete "${project.name}"?`)) {
      onDelete(project.id);
    }
  };

  return (
    <div className="project-card">
      <div className="project-card-header">
        <h3>{project.name}</h3>
        {onDelete && (
          <button
            className="delete-btn"
            onClick={handleDelete}
            title="Delete project"
          >
            &times;
          </button>
        )}
      </div>
      <p>{project.description || 'No description'}</p>
      <div className="project-meta">
        <span className="date">
          Created: {new Date(project.createdAt).toLocaleDateString()}
        </span>
        {project._count && (
          <span className="count">
            {project._count.mediaAssets} files
          </span>
        )}
      </div>
      <button onClick={() => onOpen(project.id)}>Open Project</button>
    </div>
  );
}
