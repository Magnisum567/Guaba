import type { Project } from '../../types';
import { ProjectCard } from './ProjectCard';

interface ProjectGridProps {
  projects: Project[];
  onOpenProject: (projectId: string) => void;
  onDeleteProject?: (projectId: string) => void;
  onCreateProject: () => void;
  isLoading?: boolean;
}

export function ProjectGrid({
  projects,
  onOpenProject,
  onDeleteProject,
  onCreateProject,
  isLoading,
}: ProjectGridProps) {
  if (isLoading) {
    return (
      <div className="projects-loading">
        <div className="spinner"></div>
        <p>Loading projects...</p>
      </div>
    );
  }

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h2>Your Projects</h2>
        <button onClick={onCreateProject} className="create-btn">
          + New Project
        </button>
      </div>

      {projects.length === 0 ? (
        <div className="empty-state">
          <p>No projects yet. Create your first project to get started!</p>
          <button onClick={onCreateProject} className="create-btn">
            Create Project
          </button>
        </div>
      ) : (
        <div className="projects-grid">
          {projects.map((project) => (
            <ProjectCard
              key={project.id}
              project={project}
              onOpen={onOpenProject}
              onDelete={onDeleteProject}
            />
          ))}
        </div>
      )}
    </div>
  );
}
