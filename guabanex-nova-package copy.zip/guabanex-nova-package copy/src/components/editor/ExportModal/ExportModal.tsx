import { useState } from 'react';
import { useProjectStore } from '../../../stores';
import { exports as exportsApi } from '../../../api';
import './ExportModal.css';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ExportModal({ isOpen, onClose }: ExportModalProps) {
  const { currentProject } = useProjectStore();
  const [format, setFormat] = useState('mp4');
  const [quality, setQuality] = useState('high');
  const [resolution, setResolution] = useState('1920x1080');
  const [isExporting, setIsExporting] = useState(false);
  const [exportStatus, setExportStatus] = useState<'idle' | 'processing' | 'complete' | 'error'>('idle');
  const [exportId, setExportId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleExport = async () => {
    if (!currentProject) return;

    setIsExporting(true);
    setExportStatus('processing');
    setError(null);

    try {
      const response = await exportsApi.create({
        projectId: currentProject.id,
        format,
        quality,
        resolution,
      });

      setExportId(response.data.id);

      // In a real implementation, we'd poll for status or use WebSocket
      // For now, simulate completion after a delay
      setTimeout(() => {
        setExportStatus('complete');
        setIsExporting(false);
      }, 3000);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Export failed');
      setExportStatus('error');
      setIsExporting(false);
    }
  };

  const handleDownload = async () => {
    if (!exportId) return;

    try {
      const response = await exportsApi.download(exportId);
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `${currentProject?.name || 'export'}.${format}`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      setError('Download failed - export may still be processing');
    }
  };

  const handleClose = () => {
    setExportStatus('idle');
    setExportId(null);
    setError(null);
    onClose();
  };

  return (
    <div className="modal-overlay" onClick={handleClose}>
      <div className="export-modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Export Video</h2>
          <button className="close-button" onClick={handleClose}>&times;</button>
        </div>

        <div className="modal-body">
          {exportStatus === 'idle' && (
            <>
              <div className="form-group">
                <label>Format</label>
                <select value={format} onChange={(e) => setFormat(e.target.value)}>
                  <option value="mp4">MP4 (H.264)</option>
                  <option value="mov">MOV (ProRes)</option>
                  <option value="webm">WebM (VP9)</option>
                  <option value="avi">AVI</option>
                </select>
              </div>

              <div className="form-group">
                <label>Quality</label>
                <select value={quality} onChange={(e) => setQuality(e.target.value)}>
                  <option value="low">Low (Fast export)</option>
                  <option value="medium">Medium</option>
                  <option value="high">High (Recommended)</option>
                  <option value="ultra">Ultra (Slow export)</option>
                </select>
              </div>

              <div className="form-group">
                <label>Resolution</label>
                <select value={resolution} onChange={(e) => setResolution(e.target.value)}>
                  <option value="1280x720">720p (HD)</option>
                  <option value="1920x1080">1080p (Full HD)</option>
                  <option value="2560x1440">1440p (2K)</option>
                  <option value="3840x2160">2160p (4K)</option>
                </select>
              </div>

              <div className="export-summary">
                <h4>Export Summary</h4>
                <p><strong>Project:</strong> {currentProject?.name}</p>
                <p><strong>Duration:</strong> {currentProject?.duration ? `${Math.floor(currentProject.duration / 60)}:${Math.floor(currentProject.duration % 60).toString().padStart(2, '0')}` : 'N/A'}</p>
                <p><strong>Output:</strong> {resolution} {format.toUpperCase()} ({quality})</p>
              </div>
            </>
          )}

          {exportStatus === 'processing' && (
            <div className="export-progress">
              <div className="spinner-large"></div>
              <h3>Exporting...</h3>
              <p>Please wait while your video is being processed.</p>
              <div className="progress-bar">
                <div className="progress-fill"></div>
              </div>
            </div>
          )}

          {exportStatus === 'complete' && (
            <div className="export-complete">
              <div className="success-icon">&#10003;</div>
              <h3>Export Complete!</h3>
              <p>Your video is ready for download.</p>
              <button className="btn-primary download-btn" onClick={handleDownload}>
                Download Video
              </button>
            </div>
          )}

          {exportStatus === 'error' && (
            <div className="export-error">
              <div className="error-icon">!</div>
              <h3>Export Failed</h3>
              <p>{error}</p>
              <button className="btn-primary" onClick={() => setExportStatus('idle')}>
                Try Again
              </button>
            </div>
          )}
        </div>

        {exportStatus === 'idle' && (
          <div className="modal-footer">
            <button className="btn-secondary" onClick={handleClose}>
              Cancel
            </button>
            <button
              className="btn-primary"
              onClick={handleExport}
              disabled={isExporting}
            >
              {isExporting ? 'Exporting...' : 'Start Export'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
