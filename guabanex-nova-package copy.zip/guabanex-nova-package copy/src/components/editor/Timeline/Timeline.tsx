import { useRef, useCallback, useEffect, useState } from 'react';
import {
  DndContext,
  DragOverlay,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  type DragStartEvent,
  type DragEndEvent,
} from '@dnd-kit/core';
import { useTimelineStore, useMediaStore } from '../../../stores';
import { Track } from './Track';
import { Clip } from './Clip';
import { TimeRuler } from './TimeRuler';
import { Playhead } from './Playhead';
import type { Clip as ClipType } from '../../../types';
import './Timeline.css';

export function Timeline() {
  const containerRef = useRef<HTMLDivElement>(null);
  const tracksRef = useRef<HTMLDivElement>(null);

  const {
    timeline,
    zoom,
    scrollPosition,
    currentTime,
    selectedClipIds,
    hoveredClipId,
    setScrollPosition,
    setCurrentTime,
    moveClip,
    selectClip,
    clearSelection,
    setHoveredClip,
    zoomIn,
    zoomOut,
  } = useTimelineStore();

  const { getAssetById } = useMediaStore();

  const [activeClip, setActiveClip] = useState<ClipType | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 5,
      },
    })
  );

  // Pixels per second based on zoom
  const pixelsPerSecond = 50 * zoom;

  // Handle scroll
  const handleScroll = useCallback(
    (e: React.UIEvent<HTMLDivElement>) => {
      setScrollPosition(e.currentTarget.scrollLeft);
    },
    [setScrollPosition]
  );

  // Handle clicking on timeline to seek
  const handleTimelineClick = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (e.target === e.currentTarget || (e.target as HTMLElement).classList.contains('track-content')) {
        const rect = e.currentTarget.getBoundingClientRect();
        const x = e.clientX - rect.left + scrollPosition;
        const time = x / pixelsPerSecond;
        setCurrentTime(Math.max(0, time));
        clearSelection();
      }
    },
    [scrollPosition, pixelsPerSecond, setCurrentTime, clearSelection]
  );

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      switch (e.key) {
        case '=':
        case '+':
          zoomIn();
          break;
        case '-':
          zoomOut();
          break;
        case 'Delete':
        case 'Backspace':
          // Delete selected clips
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [zoomIn, zoomOut]);

  const handleDragStart = (event: DragStartEvent) => {
    const clipId = event.active.id as string;
    const clip = timeline?.clips?.find((c) => c.id === clipId);
    if (clip) {
      setActiveClip(clip);
      selectClip(clipId);
    }
  };

  const handleDragEnd = (event: DragEndEvent) => {
    setActiveClip(null);

    if (!event.over || !activeClip) return;

    const { delta } = event;
    if (!delta) return;

    // Calculate new start time based on drag distance
    const deltaTime = delta.x / pixelsPerSecond;
    const newStartTime = Math.max(0, activeClip.startTime + deltaTime);

    // Snap to grid (0.5 second increments)
    const snappedTime = Math.round(newStartTime * 2) / 2;

    moveClip(activeClip.id, snappedTime, activeClip.trackIndex);
  };

  // Group clips by track
  const clipsByTrack = timeline?.clips?.reduce(
    (acc, clip) => {
      if (!acc[clip.trackIndex]) {
        acc[clip.trackIndex] = [];
      }
      acc[clip.trackIndex].push(clip);
      return acc;
    },
    {} as Record<number, ClipType[]>
  ) || {};

  const duration = timeline?.duration || 60;
  const timelineWidth = duration * pixelsPerSecond;

  return (
    <div className="timeline" ref={containerRef}>
      <div className="timeline-header">
        <h4>Timeline</h4>
        <div className="timeline-controls">
          <button className="zoom-btn" onClick={zoomOut} title="Zoom out (-)">
            -
          </button>
          <span className="zoom-level">{Math.round(zoom * 100)}%</span>
          <button className="zoom-btn" onClick={zoomIn} title="Zoom in (+)">
            +
          </button>
        </div>
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
      >
        <div className="timeline-body" onScroll={handleScroll}>
          <TimeRuler
            duration={duration}
            pixelsPerSecond={pixelsPerSecond}
            scrollPosition={scrollPosition}
          />

          <div
            className="timeline-tracks-container"
            ref={tracksRef}
            onClick={handleTimelineClick}
          >
            <div
              className="timeline-tracks"
              style={{ width: `${timelineWidth}px` }}
            >
              <Playhead
                currentTime={currentTime}
                pixelsPerSecond={pixelsPerSecond}
              />

              {/* Video Track */}
              <Track
                index={0}
                name="Video"
                type="video"
                clips={clipsByTrack[0] || []}
                pixelsPerSecond={pixelsPerSecond}
                selectedClipIds={selectedClipIds}
                hoveredClipId={hoveredClipId}
                onClipSelect={selectClip}
                onClipHover={setHoveredClip}
                getAssetById={getAssetById}
              />

              {/* Audio Track */}
              <Track
                index={1}
                name="Audio"
                type="audio"
                clips={clipsByTrack[1] || []}
                pixelsPerSecond={pixelsPerSecond}
                selectedClipIds={selectedClipIds}
                hoveredClipId={hoveredClipId}
                onClipSelect={selectClip}
                onClipHover={setHoveredClip}
                getAssetById={getAssetById}
              />
            </div>
          </div>
        </div>

        <DragOverlay>
          {activeClip ? (
            <Clip
              clip={activeClip}
              pixelsPerSecond={pixelsPerSecond}
              isSelected={true}
              isHovered={false}
              isDragging={true}
              asset={getAssetById(activeClip.mediaAssetId || '')}
            />
          ) : null}
        </DragOverlay>
      </DndContext>
    </div>
  );
}
