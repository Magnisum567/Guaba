interface PlayheadProps {
  currentTime: number;
  pixelsPerSecond: number;
}

export function Playhead({ currentTime, pixelsPerSecond }: PlayheadProps) {
  const position = currentTime * pixelsPerSecond;

  return (
    <div className="playhead" style={{ left: `${position}px` }}>
      <div className="playhead-head" />
      <div className="playhead-line" />
    </div>
  );
}
