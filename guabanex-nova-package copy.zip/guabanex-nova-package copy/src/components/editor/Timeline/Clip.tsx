import { useDraggable } from '@dnd-kit/core';
import { CSS } from '@dnd-kit/utilities';
import type { Clip as ClipType, MediaAsset } from '../../../types';

interface ClipProps {
  clip: ClipType;
  pixelsPerSecond: number;
  isSelected: boolean;
  isHovered: boolean;
  isDragging?: boolean;
  onSelect?: (clipId: string, multiSelect?: boolean) => void;
  onHover?: (clipId: string | null) => void;
  asset?: MediaAsset;
}

export function Clip({
  clip,
  pixelsPerSecond,
  isSelected,
  isHovered,
  isDragging = false,
  onSelect,
  onHover,
  asset,
}: ClipProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
  } = useDraggable({
    id: clip.id,
    data: { clip },
  });

  const duration = clip.endTime - clip.startTime;
  const width = duration * pixelsPerSecond;
  const left = clip.startTime * pixelsPerSecond;

  const style = {
    width: `${width}px`,
    left: `${left}px`,
    transform: CSS.Translate.toString(transform),
  };

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onSelect) {
      onSelect(clip.id, e.shiftKey || e.metaKey);
    }
  };

  const handleMouseEnter = () => {
    if (onHover) {
      onHover(clip.id);
    }
  };

  const handleMouseLeave = () => {
    if (onHover) {
      onHover(null);
    }
  };

  const displayName = asset?.filename || asset?.originalName || 'Untitled Clip';
  const shortName = displayName.length > 20
    ? displayName.slice(0, 17) + '...'
    : displayName;

  return (
    <div
      ref={setNodeRef}
      className={`clip ${isSelected ? 'selected' : ''} ${isHovered ? 'hovered' : ''} ${isDragging ? 'dragging' : ''}`}
      style={style}
      onClick={handleClick}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      {...listeners}
      {...attributes}
    >
      <div className="clip-content">
        {asset?.thumbnailUrl && (
          <div
            className="clip-thumbnail"
            style={{ backgroundImage: `url(${asset.thumbnailUrl})` }}
          />
        )}
        <span className="clip-name">{shortName}</span>
      </div>
      <div className="clip-handles">
        <div className="handle handle-left" />
        <div className="handle handle-right" />
      </div>
    </div>
  );
}
