import { useMemo } from 'react';

interface TimeRulerProps {
  duration: number;
  pixelsPerSecond: number;
  scrollPosition?: number;
}

export function TimeRuler({ duration, pixelsPerSecond }: TimeRulerProps) {
  const markers = useMemo(() => {
    const result = [];

    // Determine interval based on zoom level
    let interval = 1; // seconds
    if (pixelsPerSecond < 20) interval = 10;
    else if (pixelsPerSecond < 50) interval = 5;
    else if (pixelsPerSecond > 100) interval = 0.5;

    const majorInterval = interval * 5;

    for (let time = 0; time <= duration; time += interval) {
      const isMajor = time % majorInterval === 0;
      const position = time * pixelsPerSecond;

      result.push({
        time,
        position,
        isMajor,
        label: formatTime(time),
      });
    }

    return result;
  }, [duration, pixelsPerSecond]);

  return (
    <div className="time-ruler" style={{ width: `${duration * pixelsPerSecond}px` }}>
      {markers.map((marker, i) => (
        <div
          key={i}
          className={`ruler-mark ${marker.isMajor ? 'major' : 'minor'}`}
          style={{ left: `${marker.position}px` }}
        >
          {marker.isMajor && (
            <span className="ruler-label">{marker.label}</span>
          )}
        </div>
      ))}
    </div>
  );
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}
