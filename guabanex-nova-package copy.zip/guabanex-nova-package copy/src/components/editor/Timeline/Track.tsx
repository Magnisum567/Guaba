import { useDroppable } from '@dnd-kit/core';
import { Clip } from './Clip';
import type { Clip as ClipType, MediaAsset } from '../../../types';

interface TrackProps {
  index: number;
  name: string;
  type: 'video' | 'audio' | 'text';
  clips: ClipType[];
  pixelsPerSecond: number;
  selectedClipIds: Set<string>;
  hoveredClipId: string | null;
  onClipSelect: (clipId: string, multiSelect?: boolean) => void;
  onClipHover: (clipId: string | null) => void;
  getAssetById: (assetId: string) => MediaAsset | undefined;
}

export function Track({
  index,
  name,
  type,
  clips,
  pixelsPerSecond,
  selectedClipIds,
  hoveredClipId,
  onClipSelect,
  onClipHover,
  getAssetById,
}: TrackProps) {
  const { setNodeRef, isOver } = useDroppable({
    id: `track-${index}`,
    data: { trackIndex: index, type },
  });

  return (
    <div className={`track ${type} ${isOver ? 'drop-target' : ''}`}>
      <div className="track-header">
        <span className="track-name">{name}</span>
        <div className="track-controls">
          <button className="track-btn" title="Mute">
            M
          </button>
          <button className="track-btn" title="Lock">
            L
          </button>
        </div>
      </div>
      <div className="track-content" ref={setNodeRef}>
        {clips.map((clip) => (
          <Clip
            key={clip.id}
            clip={clip}
            pixelsPerSecond={pixelsPerSecond}
            isSelected={selectedClipIds.has(clip.id)}
            isHovered={hoveredClipId === clip.id}
            onSelect={onClipSelect}
            onHover={onClipHover}
            asset={getAssetById(clip.mediaAssetId || '')}
          />
        ))}
      </div>
    </div>
  );
}
