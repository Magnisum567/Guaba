import { useState, useEffect } from 'react';
import { useAIEditingStore, useAIColorGradingStore } from '../../../stores';
import type { MediaAsset, Clip, CinematicStyle, ColorGrading } from '../../../types';
import './AISuggestions.css';

interface AISuggestionsProps {
  mediaAssets: MediaAsset[];
  clips: Clip[];
  timelineDuration: number;
  selectedClip: Clip | null;
  onAddClip: (clip: Omit<Clip, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onApplyColorGrading: (clipId: string, grading: ColorGrading) => void;
  currentTime: number;
}

type TabType = 'clips' | 'pacing' | 'transitions' | 'styles';

export function AISuggestions({
  mediaAssets,
  clips,
  timelineDuration,
  selectedClip,
  onAddClip,
  onApplyColorGrading,
}: AISuggestionsProps) {
  const [activeTab, setActiveTab] = useState<TabType>('clips');
  const [styleSearch, setStyleSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CinematicStyle['category'] | 'all'>('all');

  const {
    clipSuggestions,
    pacingAnalysis,
    transitionSuggestions,
    cutSuggestions,
    sceneBoundaries,
    isAnalyzing,
    analysisProgress,
    generateClipSuggestions,
    analyzeTimeline,
    applyClipSuggestion,
    dismissSuggestion,
  } = useAIEditingStore();

  const {
    cinematicStyles,
    styleMatches,
    favoriteStyleIds,
    recentlyUsedIds,
    analyzeClipForStyle,
    addToFavorites,
    removeFromFavorites,
    getStylesByCategory,
    searchStyles,
  } = useAIColorGradingStore();

  // Auto-analyze when media or clips change
  useEffect(() => {
    if (mediaAssets.length > 0 && clips.length === 0) {
      generateClipSuggestions(mediaAssets, clips);
    }
  }, [mediaAssets.length]);

  useEffect(() => {
    if (clips.length > 0) {
      analyzeTimeline(clips, timelineDuration);
    }
  }, [clips.length, timelineDuration]);

  // Analyze selected clip for style matching
  useEffect(() => {
    if (selectedClip && activeTab === 'styles') {
      const currentGrading = selectedClip.properties?.colorGrading || {};
      analyzeClipForStyle(selectedClip.id, currentGrading);
    }
  }, [selectedClip?.id, activeTab]);

  const handleApplyClipSuggestion = (suggestionId: string) => {
    const suggestion = applyClipSuggestion(suggestionId);
    if (suggestion && suggestion.mediaAsset) {
      onAddClip({
        mediaAssetId: suggestion.mediaAssetId,
        mediaAsset: suggestion.mediaAsset,
        trackIndex: suggestion.suggestedTrackIndex,
        startTime: suggestion.suggestedStartTime,
        endTime: suggestion.suggestedEndTime,
        inPoint: suggestion.inPoint,
        outPoint: suggestion.outPoint,
        timelineId: '',
        properties: {
          volume: 100,
          speed: 1,
          opacity: 100,
          effects: [],
        },
        aiSuggestions: {
          category: suggestion.category,
          confidence: suggestion.confidence,
          reason: suggestion.reason,
        },
      });
    }
  };

  const handleApplyStyle = (style: CinematicStyle) => {
    if (selectedClip) {
      onApplyColorGrading(selectedClip.id, style.colorGrading);
    }
  };

  const filteredStyles = styleSearch
    ? searchStyles(styleSearch)
    : selectedCategory === 'all'
      ? cinematicStyles
      : getStylesByCategory(selectedCategory);

  const favoriteStyles = cinematicStyles.filter(s => favoriteStyleIds.includes(s.id));
  const recentStyles = recentlyUsedIds.map(id => cinematicStyles.find(s => s.id === id)).filter(Boolean) as CinematicStyle[];

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="ai-suggestions-panel">
      <div className="ai-suggestions-header">
        <h3>AI Assistant</h3>
        {isAnalyzing && (
          <div className="analyzing-indicator">
            <div className="mini-spinner"></div>
            <span>Analyzing... {Math.round(analysisProgress)}%</span>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="ai-tabs">
        <button
          className={`ai-tab ${activeTab === 'clips' ? 'active' : ''}`}
          onClick={() => setActiveTab('clips')}
        >
          <svg viewBox="0 0 24 24" width="14" height="14">
            <path fill="currentColor" d="M4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm16-4H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8 12.5v-9l6 4.5-6 4.5z"/>
          </svg>
          Clips
        </button>
        <button
          className={`ai-tab ${activeTab === 'pacing' ? 'active' : ''}`}
          onClick={() => setActiveTab('pacing')}
        >
          <svg viewBox="0 0 24 24" width="14" height="14">
            <path fill="currentColor" d="M3.5 18.49l6-6.01 4 4L22 6.92l-1.41-1.41-7.09 7.97-4-4L2 16.99z"/>
          </svg>
          Pacing
        </button>
        <button
          className={`ai-tab ${activeTab === 'transitions' ? 'active' : ''}`}
          onClick={() => setActiveTab('transitions')}
        >
          <svg viewBox="0 0 24 24" width="14" height="14">
            <path fill="currentColor" d="M15 4l-1.41 1.41L18.17 10H2v2h16.17l-4.59 4.59L15 18l6-6-6-6z"/>
          </svg>
          Cuts
        </button>
        <button
          className={`ai-tab ${activeTab === 'styles' ? 'active' : ''}`}
          onClick={() => setActiveTab('styles')}
        >
          <svg viewBox="0 0 24 24" width="14" height="14">
            <path fill="currentColor" d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8zm-5.5 9c-.83 0-1.5-.67-1.5-1.5S5.67 9 6.5 9 8 9.67 8 10.5 7.33 12 6.5 12zm3-4C8.67 8 8 7.33 8 6.5S8.67 5 9.5 5s1.5.67 1.5 1.5S10.33 8 9.5 8zm5 0c-.83 0-1.5-.67-1.5-1.5S13.67 5 14.5 5s1.5.67 1.5 1.5S15.33 8 14.5 8zm3 4c-.83 0-1.5-.67-1.5-1.5S16.67 9 17.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/>
          </svg>
          Styles
        </button>
      </div>

      {/* Tab Content */}
      <div className="ai-tab-content">
        {/* Clip Suggestions Tab */}
        {activeTab === 'clips' && (
          <div className="clips-suggestions">
            {clipSuggestions.length > 0 ? (
              <>
                <div className="suggestions-intro">
                  <span className="ai-badge">AI</span>
                  <span>{clipSuggestions.length} clips recommended for your timeline</span>
                </div>
                <div className="suggestion-list">
                  {clipSuggestions.map((suggestion) => (
                    <div key={suggestion.id} className="suggestion-card">
                      <div className="suggestion-thumbnail">
                        {suggestion.mediaAsset?.thumbnailUrl ? (
                          <img src={suggestion.mediaAsset.thumbnailUrl} alt="" />
                        ) : (
                          <div className="thumbnail-placeholder">
                            <svg viewBox="0 0 24 24" width="20" height="20">
                              <path fill="currentColor" d="M18 4l2 4h-3l-2-4h-2l2 4h-3l-2-4H8l2 4H7L5 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4h-4z"/>
                            </svg>
                          </div>
                        )}
                        <span className={`category-badge ${suggestion.category}`}>
                          {suggestion.category}
                        </span>
                      </div>
                      <div className="suggestion-info">
                        <p className="suggestion-name">
                          {suggestion.mediaAsset?.originalName || 'Untitled'}
                        </p>
                        <p className="suggestion-reason">{suggestion.reason}</p>
                        <div className="suggestion-meta">
                          <span className="confidence">
                            {Math.round(suggestion.confidence * 100)}% match
                          </span>
                          <div className="suggestion-tags">
                            {suggestion.tags.slice(0, 2).map((tag, i) => (
                              <span key={i} className="tag">{tag}</span>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="suggestion-actions">
                        <button
                          className="apply-btn"
                          onClick={() => handleApplyClipSuggestion(suggestion.id)}
                          title="Add to timeline"
                        >
                          <svg viewBox="0 0 24 24" width="16" height="16">
                            <path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
                          </svg>
                        </button>
                        <button
                          className="dismiss-btn"
                          onClick={() => dismissSuggestion(suggestion.id)}
                          title="Dismiss"
                        >
                          <svg viewBox="0 0 24 24" width="14" height="14">
                            <path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                          </svg>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="empty-state">
                <svg viewBox="0 0 24 24" width="32" height="32">
                  <path fill="currentColor" d="M4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm16-4H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8 12.5v-9l6 4.5-6 4.5z"/>
                </svg>
                <p>No clip suggestions yet</p>
                <span>Add media to your library to get AI-powered recommendations</span>
                <button
                  className="generate-btn"
                  onClick={() => generateClipSuggestions(mediaAssets, clips)}
                  disabled={mediaAssets.length === 0}
                >
                  Generate Suggestions
                </button>
              </div>
            )}
          </div>
        )}

        {/* Pacing Analysis Tab */}
        {activeTab === 'pacing' && (
          <div className="pacing-analysis">
            {pacingAnalysis ? (
              <>
                <div className="pacing-overview">
                  <div className="pace-indicator">
                    <span className="pace-label">Overall Pace</span>
                    <span className={`pace-value ${pacingAnalysis.overallPace}`}>
                      {pacingAnalysis.overallPace}
                    </span>
                  </div>
                  <div className="pace-stats">
                    <div className="stat">
                      <span className="stat-value">{pacingAnalysis.averageShotDuration.toFixed(1)}s</span>
                      <span className="stat-label">Avg Shot</span>
                    </div>
                    <div className="stat">
                      <span className="stat-value">{Math.round(pacingAnalysis.rhythmScore * 100)}%</span>
                      <span className="stat-label">Rhythm</span>
                    </div>
                    <div className="stat">
                      <span className="stat-value">{sceneBoundaries.length}</span>
                      <span className="stat-label">Cuts</span>
                    </div>
                  </div>
                </div>

                {/* Energy Curve Visualization */}
                <div className="energy-curve">
                  <span className="curve-label">Energy Curve</span>
                  <div className="curve-visual">
                    {pacingAnalysis.energyCurve.map((point, i) => (
                      <div
                        key={i}
                        className="energy-bar"
                        style={{ height: `${point.energy * 100}%` }}
                        title={`${formatTime(point.timestamp)}: ${Math.round(point.energy * 100)}%`}
                      />
                    ))}
                  </div>
                </div>

                {/* Pacing Suggestions */}
                {pacingAnalysis.suggestions.length > 0 && (
                  <div className="pacing-suggestions">
                    <span className="section-label">Suggestions</span>
                    {pacingAnalysis.suggestions.map((suggestion) => (
                      <div key={suggestion.id} className={`pacing-suggestion ${suggestion.priority}`}>
                        <div className="suggestion-icon">
                          {suggestion.type === 'remove-gap' && (
                            <svg viewBox="0 0 24 24" width="14" height="14">
                              <path fill="currentColor" d="M19 13H5v-2h14v2z"/>
                            </svg>
                          )}
                          {suggestion.type === 'speed-up' && (
                            <svg viewBox="0 0 24 24" width="14" height="14">
                              <path fill="currentColor" d="M15 4l-1.41 1.41L18.17 10H2v2h16.17l-4.59 4.59L15 18l6-6-6-6z"/>
                            </svg>
                          )}
                        </div>
                        <div className="suggestion-content">
                          <span className="suggestion-time">
                            {formatTime(suggestion.startTime)} - {formatTime(suggestion.endTime)}
                          </span>
                          <p>{suggestion.reason}</p>
                        </div>
                        <span className={`priority-badge ${suggestion.priority}`}>
                          {suggestion.priority}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <div className="empty-state">
                <svg viewBox="0 0 24 24" width="32" height="32">
                  <path fill="currentColor" d="M3.5 18.49l6-6.01 4 4L22 6.92l-1.41-1.41-7.09 7.97-4-4L2 16.99z"/>
                </svg>
                <p>No pacing analysis yet</p>
                <span>Add clips to your timeline to analyze pacing and rhythm</span>
              </div>
            )}
          </div>
        )}

        {/* Transitions & Cuts Tab */}
        {activeTab === 'transitions' && (
          <div className="transitions-cuts">
            {/* Scene Boundaries */}
            {sceneBoundaries.length > 0 && (
              <div className="scene-boundaries">
                <span className="section-label">Scene Boundaries ({sceneBoundaries.length})</span>
                <div className="boundary-list">
                  {sceneBoundaries.slice(0, 5).map((boundary) => (
                    <div key={boundary.id} className="boundary-item">
                      <span className="boundary-time">{formatTime(boundary.timestamp)}</span>
                      <div className="boundary-info">
                        <span className="boundary-type">{boundary.type}</span>
                        <span className="shot-transition">
                          {boundary.shotBefore.type} → {boundary.shotAfter.type}
                        </span>
                      </div>
                      <span className="boundary-confidence">
                        {Math.round(boundary.confidence * 100)}%
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Cut Suggestions */}
            {cutSuggestions.length > 0 && (
              <div className="cut-suggestions">
                <span className="section-label">Intelligent Cut Suggestions</span>
                {cutSuggestions.map((cut) => (
                  <div key={cut.id} className="cut-suggestion">
                    <div className="cut-icon">
                      {cut.type === 'trim-start' && <span>◀</span>}
                      {cut.type === 'trim-end' && <span>▶</span>}
                      {cut.type === 'split' && <span>✂</span>}
                    </div>
                    <div className="cut-info">
                      <span className="cut-type">{cut.type.replace('-', ' ')}</span>
                      <span className="cut-time">at {formatTime(cut.timestamp)}</span>
                      <p className="cut-reason">{cut.reason}</p>
                    </div>
                    <span className="cut-confidence">
                      {Math.round(cut.confidence * 100)}%
                    </span>
                  </div>
                ))}
              </div>
            )}

            {/* Transition Suggestions */}
            {transitionSuggestions.length > 0 && (
              <div className="transition-suggestions">
                <span className="section-label">Transition Recommendations</span>
                {transitionSuggestions.slice(0, 4).map((transition) => (
                  <div key={transition.id} className="transition-item">
                    <span className={`transition-type ${transition.type}`}>
                      {transition.type}
                    </span>
                    <div className="transition-info">
                      <span className="transition-duration">{transition.duration.toFixed(1)}s</span>
                      <p className="transition-reason">{transition.reason}</p>
                    </div>
                    <span className="transition-match">
                      {Math.round(transition.contextMatch * 100)}%
                    </span>
                  </div>
                ))}
              </div>
            )}

            {sceneBoundaries.length === 0 && cutSuggestions.length === 0 && (
              <div className="empty-state">
                <svg viewBox="0 0 24 24" width="32" height="32">
                  <path fill="currentColor" d="M15 4l-1.41 1.41L18.17 10H2v2h16.17l-4.59 4.59L15 18l6-6-6-6z"/>
                </svg>
                <p>No cut suggestions yet</p>
                <span>Add clips to get intelligent editing recommendations</span>
              </div>
            )}
          </div>
        )}

        {/* Cinematic Styles Tab */}
        {activeTab === 'styles' && (
          <div className="cinematic-styles">
            {/* Search and Filter */}
            <div className="styles-controls">
              <div className="search-box">
                <svg viewBox="0 0 24 24" width="14" height="14">
                  <path fill="currentColor" d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                </svg>
                <input
                  type="text"
                  placeholder="Search styles, directors, films..."
                  value={styleSearch}
                  onChange={(e) => setStyleSearch(e.target.value)}
                />
              </div>
              <div className="category-filters">
                {(['all', 'director', 'film', 'genre', 'era', 'mood'] as const).map((cat) => (
                  <button
                    key={cat}
                    className={`category-btn ${selectedCategory === cat ? 'active' : ''}`}
                    onClick={() => setSelectedCategory(cat)}
                  >
                    {cat === 'all' ? 'All' : cat.charAt(0).toUpperCase() + cat.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            {/* Style Matches for Selected Clip */}
            {selectedClip && styleMatches.length > 0 && (
              <div className="style-matches">
                <span className="section-label">
                  <span className="ai-badge">AI</span>
                  Recommended for this clip
                </span>
                <div className="match-list">
                  {styleMatches.slice(0, 3).map((match) => (
                    <div key={match.style.id} className="style-match-card">
                      <div className="match-header">
                        <span className="match-name">{match.style.name}</span>
                        <span className="match-score">{Math.round(match.matchScore * 100)}%</span>
                      </div>
                      <p className="match-reasons">{match.matchReasons.join(' • ')}</p>
                      <button
                        className="apply-style-btn"
                        onClick={() => handleApplyStyle(match.style)}
                      >
                        Apply Style
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Favorites */}
            {favoriteStyles.length > 0 && !styleSearch && (
              <div className="style-section favorites">
                <span className="section-label">Favorites</span>
                <div className="styles-grid">
                  {favoriteStyles.slice(0, 4).map((style) => (
                    <StyleCard
                      key={style.id}
                      style={style}
                      isFavorite={true}
                      onApply={() => handleApplyStyle(style)}
                      onToggleFavorite={() => removeFromFavorites(style.id)}
                      disabled={!selectedClip}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Recent */}
            {recentStyles.length > 0 && !styleSearch && favoriteStyles.length === 0 && (
              <div className="style-section recent">
                <span className="section-label">Recently Used</span>
                <div className="styles-grid">
                  {recentStyles.slice(0, 4).map((style) => (
                    <StyleCard
                      key={style.id}
                      style={style}
                      isFavorite={favoriteStyleIds.includes(style.id)}
                      onApply={() => handleApplyStyle(style)}
                      onToggleFavorite={() =>
                        favoriteStyleIds.includes(style.id)
                          ? removeFromFavorites(style.id)
                          : addToFavorites(style.id)
                      }
                      disabled={!selectedClip}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* All Styles */}
            <div className="style-section all-styles">
              <span className="section-label">
                {styleSearch ? `Results for "${styleSearch}"` : 'All Styles'}
                <span className="count">({filteredStyles.length})</span>
              </span>
              <div className="styles-grid">
                {filteredStyles.map((style) => (
                  <StyleCard
                    key={style.id}
                    style={style}
                    isFavorite={favoriteStyleIds.includes(style.id)}
                    onApply={() => handleApplyStyle(style)}
                    onToggleFavorite={() =>
                      favoriteStyleIds.includes(style.id)
                        ? removeFromFavorites(style.id)
                        : addToFavorites(style.id)
                    }
                    disabled={!selectedClip}
                  />
                ))}
              </div>
            </div>

            {!selectedClip && (
              <div className="style-notice">
                <svg viewBox="0 0 24 24" width="16" height="16">
                  <path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>
                </svg>
                Select a clip to apply cinematic styles
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// Style Card Component
interface StyleCardProps {
  style: CinematicStyle;
  isFavorite: boolean;
  onApply: () => void;
  onToggleFavorite: () => void;
  disabled: boolean;
}

function StyleCard({ style, isFavorite, onApply, onToggleFavorite, disabled }: StyleCardProps) {
  // Generate preview gradient from color grading values
  const getPreviewGradient = () => {
    const { temperature, tint } = style.colorGrading;
    const warmth = temperature > 0 ? `rgba(255, ${200 - temperature}, 100, 0.3)` : `rgba(100, ${200 + temperature}, 255, 0.3)`;
    const accent = tint > 0 ? `rgba(255, 100, 255, 0.2)` : `rgba(100, 255, 200, 0.2)`;
    return `linear-gradient(135deg, ${warmth}, ${accent})`;
  };

  return (
    <div className={`style-card ${disabled ? 'disabled' : ''}`}>
      <div className="style-preview" style={{ background: getPreviewGradient() }}>
        <button
          className={`favorite-btn ${isFavorite ? 'active' : ''}`}
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite();
          }}
        >
          <svg viewBox="0 0 24 24" width="14" height="14">
            <path
              fill={isFavorite ? 'currentColor' : 'none'}
              stroke="currentColor"
              strokeWidth="2"
              d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
            />
          </svg>
        </button>
        <span className="style-category">{style.category}</span>
      </div>
      <div className="style-info">
        <h4>{style.name}</h4>
        {style.film && <span className="style-film">{style.film}</span>}
        {style.director && !style.film && <span className="style-director">{style.director}</span>}
        <p className="style-desc">{style.description}</p>
        <div className="style-chars">
          {style.characteristics.slice(0, 3).map((char, i) => (
            <span key={i} className="char-tag">{char}</span>
          ))}
        </div>
      </div>
      <button
        className="apply-style-btn"
        onClick={onApply}
        disabled={disabled}
      >
        Apply
      </button>
    </div>
  );
}
