import { useState } from 'react';

interface PlayerControlsProps {
  isPlaying: boolean;
  playbackRate: number;
  currentTime: number;
  duration: number;
  onTogglePlayback: () => void;
  onSkipForward: (seconds?: number) => void;
  onSkipBackward: (seconds?: number) => void;
  onGoToStart: () => void;
  onGoToEnd: () => void;
  onSeek: (time: number) => void;
  onPlaybackRateChange: (rate: number) => void;
}

const PLAYBACK_RATES = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2];

export function PlayerControls({
  isPlaying,
  playbackRate,
  currentTime,
  duration,
  onTogglePlayback,
  onSkipForward,
  onSkipBackward,
  onGoToStart,
  onGoToEnd,
  onSeek,
  onPlaybackRateChange,
}: PlayerControlsProps) {
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = x / rect.width;
    const newTime = percentage * duration;
    onSeek(Math.max(0, Math.min(newTime, duration)));
  };

  return (
    <div className="player-controls">
      {/* Progress bar */}
      <div className="progress-bar" onClick={handleProgressClick}>
        <div className="progress-track">
          <div className="progress-fill" style={{ width: `${progress}%` }} />
          <div className="progress-handle" style={{ left: `${progress}%` }} />
        </div>
      </div>

      {/* Control buttons */}
      <div className="control-buttons">
        <div className="control-group left">
          <button
            className="control-btn"
            onClick={onGoToStart}
            title="Go to start (Home)"
          >
            <svg viewBox="0 0 24 24" width="20" height="20">
              <path fill="currentColor" d="M6 6h2v12H6zm3.5 6l8.5 6V6z" />
            </svg>
          </button>

          <button
            className="control-btn"
            onClick={() => onSkipBackward(5)}
            title="Skip back 5s (J)"
          >
            <svg viewBox="0 0 24 24" width="20" height="20">
              <path fill="currentColor" d="M11 18V6l-8.5 6 8.5 6zm.5-6l8.5 6V6l-8.5 6z" />
            </svg>
          </button>

          <button
            className="control-btn play-btn"
            onClick={onTogglePlayback}
            title={isPlaying ? 'Pause (K/Space)' : 'Play (K/Space)'}
          >
            {isPlaying ? (
              <svg viewBox="0 0 24 24" width="24" height="24">
                <path fill="currentColor" d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" width="24" height="24">
                <path fill="currentColor" d="M8 5v14l11-7z" />
              </svg>
            )}
          </button>

          <button
            className="control-btn"
            onClick={() => onSkipForward(5)}
            title="Skip forward 5s (L)"
          >
            <svg viewBox="0 0 24 24" width="20" height="20">
              <path fill="currentColor" d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z" />
            </svg>
          </button>

          <button
            className="control-btn"
            onClick={onGoToEnd}
            title="Go to end (End)"
          >
            <svg viewBox="0 0 24 24" width="20" height="20">
              <path fill="currentColor" d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z" />
            </svg>
          </button>
        </div>

        <div className="control-group right">
          <div className="speed-control">
            <button
              className="control-btn speed-btn"
              onClick={() => setShowSpeedMenu(!showSpeedMenu)}
              title="Playback speed"
            >
              {playbackRate}x
            </button>
            {showSpeedMenu && (
              <div className="speed-menu">
                {PLAYBACK_RATES.map((rate) => (
                  <button
                    key={rate}
                    className={`speed-option ${rate === playbackRate ? 'active' : ''}`}
                    onClick={() => {
                      onPlaybackRateChange(rate);
                      setShowSpeedMenu(false);
                    }}
                  >
                    {rate}x
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
