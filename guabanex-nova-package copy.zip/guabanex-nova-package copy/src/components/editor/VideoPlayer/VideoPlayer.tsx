import { useRef, useEffect, useCallback } from 'react';
import { useTimelineStore } from '../../../stores';
import './VideoPlayer.css';

interface VideoPlayerProps {
  src?: string;
  poster?: string;
}

export function VideoPlayer({ src, poster }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);

  const {
    currentTime,
    isPlaying,
    playbackRate,
    setCurrentTime,
    pause,
    togglePlayback,
    goToStart,
  } = useTimelineStore();

  // Sync video with store state
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.play().catch(() => {
        // Auto-play was prevented
        pause();
      });
    } else {
      video.pause();
    }
  }, [isPlaying, pause]);

  // Sync playback rate
  useEffect(() => {
    const video = videoRef.current;
    if (video) {
      video.playbackRate = playbackRate;
    }
  }, [playbackRate]);

  // Seek to currentTime when it changes externally
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    // Only seek if the difference is significant (to avoid feedback loops)
    if (Math.abs(video.currentTime - currentTime) > 0.1) {
      video.currentTime = currentTime;
    }
  }, [currentTime]);

  const handleTimeUpdate = useCallback(() => {
    const video = videoRef.current;
    if (video && isPlaying) {
      setCurrentTime(video.currentTime);
    }
  }, [isPlaying, setCurrentTime]);

  const handleLoadedMetadata = useCallback(() => {
    const video = videoRef.current;
    if (video && video.duration && isFinite(video.duration)) {
      // Reset to start when new video loads
      setCurrentTime(0);
    }
  }, [setCurrentTime]);

  const handleEnded = useCallback(() => {
    pause();
    goToStart();
  }, [pause, goToStart]);

  return (
    <div className="video-player">
      <div className="video-container">
        {src ? (
          <video
            ref={videoRef}
            src={src}
            poster={poster}
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={handleLoadedMetadata}
            onEnded={handleEnded}
            onClick={togglePlayback}
            preload="auto"
            style={{ cursor: 'pointer' }}
          />
        ) : (
          <div className="video-placeholder">
            <span>No video selected</span>
            <p>Click to upload or select media from library</p>
          </div>
        )}
        {/* Play/Pause overlay indicator */}
        {src && (
          <div className={`play-overlay ${isPlaying ? 'playing' : ''}`}>
            {isPlaying ? '⏸' : '▶'}
          </div>
        )}
      </div>
    </div>
  );
}
