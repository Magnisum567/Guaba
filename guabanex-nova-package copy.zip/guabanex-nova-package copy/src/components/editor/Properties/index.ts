export { Properties } from './Properties';
