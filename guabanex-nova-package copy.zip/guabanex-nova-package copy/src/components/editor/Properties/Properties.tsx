import { useState, useRef, useEffect } from 'react';
import type { Clip, ColorGrading } from '../../../types';
import { useAIAnalysisStore } from '../../../stores';
import './Properties.css';

interface PropertiesProps {
  selectedClip: Clip | null;
  onUpdateClip: (clipId: string, updates: Partial<Clip>) => void;
  onSplitClip: (clipId: string, splitTime: number) => void;
  onDeleteClip: (clipId: string) => void;
  currentTime: number;
}

const defaultColorGrading: ColorGrading = {
  brightness: 0,
  contrast: 0,
  saturation: 0,
  temperature: 0,
  tint: 0,
  exposure: 0,
  highlights: 0,
  shadows: 0,
  vibrance: 0,
  hue: 0,
  gamma: 0,
  lutFile: undefined,
  lutIntensity: 100,
};

const presetLUTs = [
  { name: 'None', value: '' },
  { name: 'Cinematic Warm', value: 'cinematic-warm' },
  { name: 'Cinematic Cool', value: 'cinematic-cool' },
  { name: 'Film Noir', value: 'film-noir' },
  { name: 'Vintage', value: 'vintage' },
  { name: 'Teal & Orange', value: 'teal-orange' },
  { name: 'Bleach Bypass', value: 'bleach-bypass' },
  { name: 'High Contrast', value: 'high-contrast' },
  { name: 'Muted', value: 'muted' },
];

export function Properties({
  selectedClip,
  onUpdateClip,
  onSplitClip,
  onDeleteClip,
  currentTime,
}: PropertiesProps) {
  const [activeTab, setActiveTab] = useState<'color' | 'transform' | 'audio' | 'ai'>('color');
  const lutInputRef = useRef<HTMLInputElement>(null);

  // AI Analysis
  const { getAnalysis, analyzeMedia } = useAIAnalysisStore();
  const analysis = selectedClip?.mediaAssetId ? getAnalysis(selectedClip.mediaAssetId) : undefined;

  // Auto-analyze when clip is selected
  useEffect(() => {
    if (selectedClip?.mediaAssetId && !analysis) {
      analyzeMedia(selectedClip.mediaAssetId);
    }
  }, [selectedClip?.mediaAssetId, analysis, analyzeMedia]);

  const colorGrading: ColorGrading = selectedClip?.properties?.colorGrading || defaultColorGrading;

  const handleColorChange = (property: keyof ColorGrading, value: number) => {
    if (!selectedClip) return;

    const newColorGrading = {
      ...colorGrading,
      [property]: value,
    };

    onUpdateClip(selectedClip.id, {
      properties: {
        ...selectedClip.properties,
        colorGrading: newColorGrading,
      },
    });
  };

  const handleSplit = () => {
    if (!selectedClip) return;
    if (currentTime > selectedClip.startTime && currentTime < selectedClip.endTime) {
      onSplitClip(selectedClip.id, currentTime);
    }
  };

  const handleResetColor = () => {
    if (!selectedClip) return;
    onUpdateClip(selectedClip.id, {
      properties: {
        ...selectedClip.properties,
        colorGrading: defaultColorGrading,
      },
    });
  };

  const handleLUTChange = (lutValue: string) => {
    if (!selectedClip) return;
    const newColorGrading = {
      ...colorGrading,
      lutFile: lutValue || undefined,
    };
    onUpdateClip(selectedClip.id, {
      properties: {
        ...selectedClip.properties,
        colorGrading: newColorGrading,
      },
    });
  };

  const handleLUTFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedClip) return;
    const newColorGrading = {
      ...colorGrading,
      lutFile: `custom:${file.name}`,
    };
    onUpdateClip(selectedClip.id, {
      properties: {
        ...selectedClip.properties,
        colorGrading: newColorGrading,
      },
    });
  };

  const handleApplySuggestedLUT = (lutName: string) => {
    if (!selectedClip) return;
    handleLUTChange(lutName);
    setActiveTab('color');
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Slider component with local state for smooth dragging
  const Slider = ({
    label,
    value,
    onChange,
    min = -100,
    max = 100,
    unit = '',
    disabled = false
  }: {
    label: string;
    value: number;
    onChange: (v: number) => void;
    min?: number;
    max?: number;
    unit?: string;
    disabled?: boolean;
  }) => {
    const [localValue, setLocalValue] = useState(value);
    const [isDragging, setIsDragging] = useState(false);
    const pendingValueRef = useRef(value);

    // Sync local value with prop when not dragging
    useEffect(() => {
      if (!isDragging) {
        setLocalValue(value);
      }
    }, [value, isDragging]);

    // Handle mouse release anywhere on the document
    useEffect(() => {
      if (!isDragging) return;

      const handleGlobalMouseUp = () => {
        setIsDragging(false);
        if (pendingValueRef.current !== value) {
          onChange(pendingValueRef.current);
        }
      };

      document.addEventListener('mouseup', handleGlobalMouseUp);
      document.addEventListener('touchend', handleGlobalMouseUp);

      return () => {
        document.removeEventListener('mouseup', handleGlobalMouseUp);
        document.removeEventListener('touchend', handleGlobalMouseUp);
      };
    }, [isDragging, value, onChange]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const newValue = Number(e.target.value);
      setLocalValue(newValue);
      pendingValueRef.current = newValue;
    };

    const handleMouseDown = () => {
      setIsDragging(true);
      pendingValueRef.current = localValue;
    };

    return (
      <div className={`slider-control ${disabled ? 'disabled' : ''}`}>
        <div className="slider-header">
          <label>{label}</label>
          <span className="slider-value">{localValue}{unit}</span>
        </div>
        <input
          type="range"
          value={localValue}
          onChange={handleChange}
          onMouseDown={handleMouseDown}
          onTouchStart={handleMouseDown}
          min={min}
          max={max}
          disabled={disabled}
        />
      </div>
    );
  };

  const isDisabled = !selectedClip;

  return (
    <div className="editor-properties properties-panel">
      <h3>Properties</h3>

      {/* Clip Info Header - only show if clip selected */}
      {selectedClip ? (
        <>
          <div className="clip-header">
            <div className="clip-thumbnail">
              {selectedClip.mediaAsset?.thumbnailUrl ? (
                <img src={`http://localhost:3001${selectedClip.mediaAsset.thumbnailUrl}`} alt="" />
              ) : (
                <div className="thumbnail-placeholder">
                  <svg viewBox="0 0 24 24" width="24" height="24">
                    <path fill="currentColor" d="M18 4l2 4h-3l-2-4h-2l2 4h-3l-2-4H8l2 4H7L5 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4h-4z"/>
                  </svg>
                </div>
              )}
            </div>
            <div className="clip-details">
              <p className="clip-name">{selectedClip.mediaAsset?.originalName || selectedClip.mediaAsset?.filename || 'Clip'}</p>
              <p className="clip-duration">{formatTime(selectedClip.endTime - selectedClip.startTime)}</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="quick-actions">
            <button className="action-btn" onClick={handleSplit} title="Split at playhead">
              <svg viewBox="0 0 24 24" width="14" height="14">
                <path fill="currentColor" d="M11 2v20h2V2h-2zm-4 8v4h2v-4H7zm8 0v4h2v-4h-2z"/>
              </svg>
              Split
            </button>
            <button className="action-btn delete" onClick={() => onDeleteClip(selectedClip.id)} title="Delete clip">
              <svg viewBox="0 0 24 24" width="14" height="14">
                <path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
              </svg>
              Delete
            </button>
          </div>
        </>
      ) : (
        <div className="no-clip-notice">
          <p>No clip selected</p>
          <span>Select a clip to apply these settings</span>
        </div>
      )}

      {/* Tabs */}
      <div className="properties-tabs">
        <button
          className={`tab ${activeTab === 'color' ? 'active' : ''}`}
          onClick={() => setActiveTab('color')}
        >
          Color
        </button>
        <button
          className={`tab ${activeTab === 'transform' ? 'active' : ''}`}
          onClick={() => setActiveTab('transform')}
        >
          Transform
        </button>
        <button
          className={`tab ${activeTab === 'audio' ? 'active' : ''}`}
          onClick={() => setActiveTab('audio')}
        >
          Audio
        </button>
        <button
          className={`tab ${activeTab === 'ai' ? 'active' : ''}`}
          onClick={() => setActiveTab('ai')}
        >
          AI
        </button>
      </div>

      {/* Tab Content */}
      <div className="tab-content">
        {activeTab === 'color' && (
          <div className="color-controls">
            {/* LUT Section */}
            <div className="control-section">
              <div className="section-header">
                <span>Color Look / LUT</span>
              </div>
              <div className="lut-controls">
                <select
                  value={colorGrading.lutFile?.startsWith('custom:') ? '' : (colorGrading.lutFile || '')}
                  onChange={(e) => handleLUTChange(e.target.value)}
                  className="lut-select"
                  disabled={isDisabled}
                >
                  {presetLUTs.map((lut) => (
                    <option key={lut.value} value={lut.value}>{lut.name}</option>
                  ))}
                </select>
                <button
                  className="lut-upload-btn"
                  onClick={() => lutInputRef.current?.click()}
                  title="Upload custom LUT"
                  disabled={isDisabled}
                >
                  <svg viewBox="0 0 24 24" width="16" height="16">
                    <path fill="currentColor" d="M9 16h6v-6h4l-7-7-7 7h4v6zm-4 2h14v2H5v-2z"/>
                  </svg>
                </button>
                <input
                  ref={lutInputRef}
                  type="file"
                  accept=".cube,.3dl,.lut"
                  onChange={handleLUTFileUpload}
                  style={{ display: 'none' }}
                />
              </div>
              {colorGrading.lutFile && (
                <Slider
                  label="LUT Intensity"
                  value={colorGrading.lutIntensity}
                  onChange={(v) => handleColorChange('lutIntensity', v)}
                  min={0}
                  max={100}
                  unit="%"
                  disabled={isDisabled}
                />
              )}
            </div>

            {/* Basic Adjustments */}
            <div className="control-section">
              <div className="section-header">
                <span>Basic</span>
                <button className="reset-btn" onClick={handleResetColor} disabled={isDisabled}>Reset All</button>
              </div>
              <Slider label="Exposure" value={colorGrading.exposure} onChange={(v) => handleColorChange('exposure', v)} disabled={isDisabled} />
              <Slider label="Brightness" value={colorGrading.brightness} onChange={(v) => handleColorChange('brightness', v)} disabled={isDisabled} />
              <Slider label="Contrast" value={colorGrading.contrast} onChange={(v) => handleColorChange('contrast', v)} disabled={isDisabled} />
              <Slider label="Gamma" value={colorGrading.gamma} onChange={(v) => handleColorChange('gamma', v)} disabled={isDisabled} />
            </div>

            {/* Tone */}
            <div className="control-section">
              <div className="section-header">
                <span>Tone</span>
              </div>
              <Slider label="Highlights" value={colorGrading.highlights} onChange={(v) => handleColorChange('highlights', v)} disabled={isDisabled} />
              <Slider label="Shadows" value={colorGrading.shadows} onChange={(v) => handleColorChange('shadows', v)} disabled={isDisabled} />
            </div>

            {/* Color */}
            <div className="control-section">
              <div className="section-header">
                <span>Color</span>
              </div>
              <Slider label="Saturation" value={colorGrading.saturation} onChange={(v) => handleColorChange('saturation', v)} disabled={isDisabled} />
              <Slider label="Vibrance" value={colorGrading.vibrance} onChange={(v) => handleColorChange('vibrance', v)} disabled={isDisabled} />
              <Slider label="Temperature" value={colorGrading.temperature} onChange={(v) => handleColorChange('temperature', v)} disabled={isDisabled} />
              <Slider label="Tint" value={colorGrading.tint} onChange={(v) => handleColorChange('tint', v)} disabled={isDisabled} />
              <Slider label="Hue" value={colorGrading.hue} onChange={(v) => handleColorChange('hue', v)} min={-180} max={180} unit="°" disabled={isDisabled} />
            </div>
          </div>
        )}

        {activeTab === 'transform' && (
          <div className="transform-controls">
            <div className="control-section">
              <div className="section-header">
                <span>Position</span>
              </div>
              <div className="position-grid">
                <div className="input-group">
                  <label>X</label>
                  <input type="number" defaultValue={0} step={1} />
                </div>
                <div className="input-group">
                  <label>Y</label>
                  <input type="number" defaultValue={0} step={1} />
                </div>
              </div>
            </div>
            <div className="control-section">
              <div className="section-header">
                <span>Scale & Rotation</span>
              </div>
              <div className="slider-control">
                <div className="slider-header">
                  <label>Scale</label>
                  <span className="slider-value">100%</span>
                </div>
                <input type="range" defaultValue={100} min={0} max={500} />
              </div>
              <div className="slider-control">
                <div className="slider-header">
                  <label>Rotation</label>
                  <span className="slider-value">0°</span>
                </div>
                <input type="range" defaultValue={0} min={-180} max={180} />
              </div>
            </div>
            <div className="control-section">
              <div className="section-header">
                <span>Opacity</span>
              </div>
              <div className="slider-control">
                <div className="slider-header">
                  <label>Opacity</label>
                  <span className="slider-value">100%</span>
                </div>
                <input type="range" defaultValue={100} min={0} max={100} />
              </div>
            </div>
          </div>
        )}

        {activeTab === 'audio' && (
          <div className="audio-controls">
            <div className="control-section">
              <div className="section-header">
                <span>Volume</span>
              </div>
              <div className="slider-control">
                <div className="slider-header">
                  <label>Volume</label>
                  <span className="slider-value">100%</span>
                </div>
                <input type="range" defaultValue={100} min={0} max={200} />
              </div>
              <div className="slider-control">
                <div className="slider-header">
                  <label>Pan</label>
                  <span className="slider-value">C</span>
                </div>
                <input type="range" defaultValue={0} min={-100} max={100} />
              </div>
            </div>
            <div className="control-section">
              <div className="section-header">
                <span>Options</span>
              </div>
              <label className="checkbox-control">
                <input type="checkbox" />
                <span>Mute audio</span>
              </label>
            </div>
          </div>
        )}

        {activeTab === 'ai' && (
          <div className="ai-controls">
            {!selectedClip ? (
              <div className="ai-empty">
                <p>Select a clip to view AI analysis</p>
              </div>
            ) : analysis?.status === 'analyzing' ? (
              <div className="ai-loading">
                <div className="spinner"></div>
                <p>Analyzing media...</p>
                <span>Scene detection, emotion analysis, and style matching</span>
              </div>
            ) : analysis?.status === 'complete' ? (
              <>
                {/* Re-analyze button */}
                <div className="ai-actions">
                  <button
                    className="reanalyze-btn"
                    onClick={() => selectedClip?.mediaAssetId && analyzeMedia(selectedClip.mediaAssetId, true)}
                  >
                    <svg viewBox="0 0 24 24" width="14" height="14">
                      <path fill="currentColor" d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/>
                    </svg>
                    Re-analyze
                  </button>
                  <span className="cache-info">Cached {new Date(analysis.analyzedAt).toLocaleDateString()}</span>
                </div>

                {/* Scene Detection */}
                <div className="control-section">
                  <div className="section-header">
                    <span>Scene Detection</span>
                    <span className="ai-badge">AI</span>
                  </div>
                  {analysis.sceneAnalysis && (
                    <div className="ai-result-card">
                      <p className="ai-description">{analysis.sceneAnalysis.overallDescription}</p>
                      <div className="ai-tags">
                        <div className="tag-group">
                          <span className="tag-label">Objects:</span>
                          {analysis.sceneAnalysis.dominantObjects.map((obj, i) => (
                            <span key={i} className="tag">{obj}</span>
                          ))}
                        </div>
                        <div className="tag-group">
                          <span className="tag-label">Actions:</span>
                          {analysis.sceneAnalysis.dominantActions.map((action, i) => (
                            <span key={i} className="tag">{action}</span>
                          ))}
                        </div>
                      </div>
                      <div className="scene-segments">
                        <span className="segment-label">{analysis.sceneAnalysis.scenes.length} scenes detected</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Emotion Analysis */}
                <div className="control-section">
                  <div className="section-header">
                    <span>Emotion Analysis</span>
                    <span className="ai-badge">AI</span>
                  </div>
                  {analysis.emotionAnalysis && (
                    <div className="ai-result-card">
                      <div className="emotion-summary">
                        <div className="emotion-stat">
                          <span className="stat-value">{analysis.emotionAnalysis.dominantEmotion}</span>
                          <span className="stat-label">Dominant Emotion</span>
                        </div>
                        <div className="emotion-stat">
                          <span className="stat-value">{analysis.emotionAnalysis.facesDetected}</span>
                          <span className="stat-label">Faces Detected</span>
                        </div>
                      </div>
                      <div className="emotion-arc">
                        <span className="arc-label">Emotional Arc:</span>
                        <span className="arc-value">{analysis.emotionAnalysis.emotionalArc}</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Style Matching */}
                <div className="control-section">
                  <div className="section-header">
                    <span>Style Matching</span>
                    <span className="ai-badge">AI</span>
                  </div>
                  {analysis.styleAnalysis && (
                    <div className="ai-result-card">
                      <div className="style-info">
                        <div className="style-row">
                          <span className="style-label">Mood:</span>
                          <span className="style-value">{analysis.styleAnalysis.mood}</span>
                        </div>
                        <div className="style-row">
                          <span className="style-label">Visual Style:</span>
                          <span className="style-value">{analysis.styleAnalysis.visualStyle}</span>
                        </div>
                        <div className="style-row">
                          <span className="style-label">Lighting:</span>
                          <span className="style-value">{analysis.styleAnalysis.lightingType}</span>
                        </div>
                      </div>

                      <div className="color-palette">
                        <span className="palette-label">Color Palette:</span>
                        <div className="palette-colors">
                          {analysis.styleAnalysis.colorPalette.map((color, i) => (
                            <div
                              key={i}
                              className="palette-swatch"
                              style={{ backgroundColor: color.hex }}
                              title={`${color.name} (${color.percentage}%)`}
                            />
                          ))}
                        </div>
                      </div>

                      <div className="suggested-styles">
                        <span className="styles-label">Suggested Color Grades:</span>
                        {analysis.styleAnalysis.matchingStyles.map((style, i) => (
                          <button
                            key={i}
                            className="style-suggestion"
                            onClick={() => handleApplySuggestedLUT(style.name.toLowerCase().replace(/\s+/g, '-'))}
                          >
                            <div className="suggestion-info">
                              <span className="suggestion-name">{style.name}</span>
                              <span className="suggestion-match">{Math.round(style.similarity * 100)}% match</span>
                            </div>
                            <span className="suggestion-desc">{style.description}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </>
            ) : analysis?.status === 'failed' ? (
              <div className="ai-failed">
                <svg className="error-icon" viewBox="0 0 24 24" width="32" height="32">
                  <path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
                </svg>
                <p>Analysis failed</p>
                <span>There was an error analyzing this media</span>
                <button
                  className="retry-btn"
                  onClick={() => selectedClip?.mediaAssetId && analyzeMedia(selectedClip.mediaAssetId, true)}
                >
                  <svg viewBox="0 0 24 24" width="14" height="14">
                    <path fill="currentColor" d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/>
                  </svg>
                  Retry Analysis
                </button>
              </div>
            ) : (
              <div className="ai-empty">
                <button
                  className="analyze-btn"
                  onClick={() => selectedClip?.mediaAssetId && analyzeMedia(selectedClip.mediaAssetId)}
                >
                  <svg viewBox="0 0 24 24" width="20" height="20">
                    <path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                  </svg>
                  Analyze with AI
                </button>
                <span>Get scene detection, emotion analysis, and style recommendations</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
