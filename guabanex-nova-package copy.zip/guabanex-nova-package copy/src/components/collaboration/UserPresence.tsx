import { useCollaborationStore } from '../../stores';
import './Collaboration.css';

export function UserPresence() {
  const { activeUsers, isConnected } = useCollaborationStore();
  const users = Array.from(activeUsers.values());

  if (!isConnected) {
    return (
      <div className="user-presence disconnected">
        <span className="connection-status">Offline</span>
      </div>
    );
  }

  return (
    <div className="user-presence">
      <span className="connection-status connected">Live</span>
      <div className="user-avatars">
        {users.slice(0, 5).map((user) => (
          <div
            key={user.userId}
            className="user-avatar"
            title={user.userName}
            style={{
              backgroundImage: user.avatar ? `url(${user.avatar})` : undefined,
            }}
          >
            {!user.avatar && user.userName.charAt(0).toUpperCase()}
          </div>
        ))}
        {users.length > 5 && (
          <div className="user-avatar more">+{users.length - 5}</div>
        )}
      </div>
    </div>
  );
}
