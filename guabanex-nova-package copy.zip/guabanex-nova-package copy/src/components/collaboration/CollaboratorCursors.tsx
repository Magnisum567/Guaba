import { useCollaborationStore } from '../../stores';
import './Collaboration.css';

interface CollaboratorCursorsProps {
  timelineWidth: number;
  duration: number;
}

export function CollaboratorCursors({ timelineWidth, duration }: CollaboratorCursorsProps) {
  const { cursors } = useCollaborationStore();
  const cursorList = Array.from(cursors.values());

  if (cursorList.length === 0) return null;

  return (
    <div className="collaborator-cursors">
      {cursorList.map((cursor) => {
        const position = (cursor.position / duration) * timelineWidth;

        return (
          <div
            key={cursor.userId}
            className="collaborator-cursor"
            style={{
              left: `${position}px`,
              borderColor: cursor.color,
            }}
          >
            <div
              className="cursor-label"
              style={{ backgroundColor: cursor.color }}
            >
              {cursor.userName}
            </div>
            <div
              className="cursor-line"
              style={{ backgroundColor: cursor.color }}
            />
          </div>
        );
      })}
    </div>
  );
}
