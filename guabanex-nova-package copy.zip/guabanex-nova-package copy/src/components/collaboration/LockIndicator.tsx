import { useCollaborationStore, useAuthStore } from '../../stores';
import './Collaboration.css';

interface LockIndicatorProps {
  resourceId: string;
  className?: string;
}

export function LockIndicator({ resourceId, className = '' }: LockIndicatorProps) {
  const { locks } = useCollaborationStore();
  const { user } = useAuthStore();
  const lock = locks.get(resourceId);

  if (!lock) return null;

  const isOwnLock = lock.lockedBy === user?.id;

  return (
    <div className={`lock-indicator ${isOwnLock ? 'own-lock' : 'other-lock'} ${className}`}>
      <span className="lock-icon">{isOwnLock ? '✏️' : '🔒'}</span>
      {!isOwnLock && (
        <span className="lock-user">{lock.lockedByName}</span>
      )}
    </div>
  );
}
