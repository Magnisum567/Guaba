import { useTextToEditStore } from '../../../stores';

export function EditingOptions() {
  const { settings, updateSettings } = useTextToEditStore();

  return (
    <div className="editing-options">
      <h4>Editing Options</h4>

      <div className="options-grid">
        <div className="option-item">
          <label htmlFor="target-duration">Target Duration (seconds)</label>
          <input
            id="target-duration"
            type="number"
            min="5"
            max="600"
            step="5"
            value={settings.targetDuration || ''}
            onChange={(e) =>
              updateSettings({
                targetDuration: e.target.value ? parseInt(e.target.value) : undefined,
              })
            }
            placeholder="Auto"
          />
        </div>

        <div className="option-item toggle">
          <input
            id="include-transitions"
            type="checkbox"
            checked={settings.includeTransitions}
            onChange={(e) => updateSettings({ includeTransitions: e.target.checked })}
          />
          <label htmlFor="include-transitions">
            <span className="toggle-label">Include Transitions</span>
            <span className="toggle-desc">Add smooth transitions between clips</span>
          </label>
        </div>

        <div className="option-item toggle">
          <input
            id="include-color-grading"
            type="checkbox"
            checked={settings.includeColorGrading}
            onChange={(e) => updateSettings({ includeColorGrading: e.target.checked })}
          />
          <label htmlFor="include-color-grading">
            <span className="toggle-label">Color Grading</span>
            <span className="toggle-desc">Apply AI-suggested color corrections</span>
          </label>
        </div>

        <div className="option-item toggle">
          <input
            id="include-text-overlays"
            type="checkbox"
            checked={settings.includeTextOverlays}
            onChange={(e) => updateSettings({ includeTextOverlays: e.target.checked })}
          />
          <label htmlFor="include-text-overlays">
            <span className="toggle-label">Text Overlays</span>
            <span className="toggle-desc">Add titles and captions if appropriate</span>
          </label>
        </div>

        <div className="option-item toggle">
          <input
            id="audio-mixing"
            type="checkbox"
            checked={settings.audioMixing}
            onChange={(e) => updateSettings({ audioMixing: e.target.checked })}
          />
          <label htmlFor="audio-mixing">
            <span className="toggle-label">Audio Mixing</span>
            <span className="toggle-desc">Adjust audio levels and add fade in/out</span>
          </label>
        </div>
      </div>
    </div>
  );
}
