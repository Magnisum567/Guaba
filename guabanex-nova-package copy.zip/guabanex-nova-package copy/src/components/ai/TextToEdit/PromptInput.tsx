import { useState } from 'react';
import { useTextToEditStore } from '../../../stores';

const EXAMPLE_PROMPTS = [
  {
    label: 'Highlight Reel',
    prompt: 'Create a 30-second highlight reel with the most exciting moments',
  },
  {
    label: 'Action Montage',
    prompt: 'Make an action-packed montage with fast cuts and energetic pacing',
  },
  {
    label: 'Cinematic Edit',
    prompt: 'Edit this into a cinematic sequence with dramatic transitions and color grading',
  },
  {
    label: 'Social Media',
    prompt: 'Create a 15-second clip optimized for social media with quick cuts',
  },
  {
    label: 'Documentary Style',
    prompt: 'Create a documentary-style edit with smooth transitions and natural pacing',
  },
];

export function PromptInput() {
  const { prompt, setPrompt } = useTextToEditStore();
  const [showExamples, setShowExamples] = useState(false);

  const handleExampleClick = (examplePrompt: string) => {
    setPrompt(examplePrompt);
    setShowExamples(false);
  };

  return (
    <div className="prompt-input-container">
      <label htmlFor="prompt-input">Describe how you want to edit your footage:</label>

      <textarea
        id="prompt-input"
        className="prompt-textarea"
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder="e.g., Create a 30-second highlight reel with the most exciting moments, add smooth transitions between clips, and apply a warm color grade..."
        rows={4}
      />

      <div className="prompt-helpers">
        <button
          type="button"
          className="examples-toggle"
          onClick={() => setShowExamples(!showExamples)}
        >
          {showExamples ? 'Hide Examples' : 'Show Examples'}
        </button>

        <span className="char-count">{prompt.length} characters</span>
      </div>

      {showExamples && (
        <div className="examples-grid">
          {EXAMPLE_PROMPTS.map((example) => (
            <button
              key={example.label}
              className="example-button"
              onClick={() => handleExampleClick(example.prompt)}
            >
              <strong>{example.label}</strong>
              <span>{example.prompt}</span>
            </button>
          ))}
        </div>
      )}

      <div className="prompt-tips">
        <strong>Tips:</strong>
        <ul>
          <li>Specify a target duration (e.g., "30 seconds", "2 minutes")</li>
          <li>Describe the style or mood you want (e.g., "energetic", "cinematic")</li>
          <li>Mention specific transition types if desired (e.g., "fade", "dissolve")</li>
          <li>Include any content preferences (e.g., "focus on action shots")</li>
        </ul>
      </div>
    </div>
  );
}
