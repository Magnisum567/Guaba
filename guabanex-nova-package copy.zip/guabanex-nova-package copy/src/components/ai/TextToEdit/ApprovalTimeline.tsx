import { useMemo } from 'react';
import { useTextToEditStore, useMediaStore } from '../../../stores';
import type { MediaAsset } from '../../../types';

export function ApprovalTimeline() {
  const { draftTimeline, previewUrl } = useTextToEditStore();
  const { assets } = useMediaStore();

  const mediaMap = useMemo(() => {
    const map = new Map<string, MediaAsset>();
    assets.forEach((asset) => {
      map.set(asset.id, asset);
    });
    return map;
  }, [assets]);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!draftTimeline) {
    return (
      <div className="approval-timeline-empty">
        <p>No draft timeline available.</p>
      </div>
    );
  }

  const { clips, transitions, effects, textOverlays, totalDuration } = draftTimeline;

  return (
    <div className="approval-timeline-container">
      <div className="draft-summary">
        <h3>Draft Timeline Preview</h3>
        <div className="summary-stats">
          <span>{clips.length} clips</span>
          <span>{transitions.length} transitions</span>
          <span>{effects.length} effects</span>
          <span>Total: {formatDuration(totalDuration)}</span>
        </div>
      </div>

      {previewUrl && (
        <div className="preview-video">
          <video src={previewUrl} controls />
        </div>
      )}

      <div className="timeline-preview">
        <div className="timeline-track video-track">
          <div className="track-label">Video</div>
          <div className="track-clips">
            {clips
              .filter((c) => c.trackIndex === 0)
              .map((clip, index) => {
                const mediaAsset = mediaMap.get(clip.mediaAssetId);
                const width = ((clip.endTime - clip.startTime) / totalDuration) * 100;
                const left = (clip.startTime / totalDuration) * 100;

                return (
                  <div
                    key={`clip-${index}`}
                    className="preview-clip"
                    style={{ width: `${width}%`, left: `${left}%` }}
                    title={mediaAsset?.originalName || 'Clip'}
                  >
                    <span className="clip-label">
                      {mediaAsset?.originalName?.substring(0, 10) || `Clip ${index + 1}`}
                    </span>
                  </div>
                );
              })}

            {transitions.map((transition, index) => {
              const left = (transition.position / totalDuration) * 100;
              return (
                <div
                  key={`transition-${index}`}
                  className="preview-transition"
                  style={{ left: `${left}%` }}
                  title={`${transition.type} (${transition.duration}s)`}
                >
                  <span className="transition-icon">&#x2194;</span>
                </div>
              );
            })}
          </div>
        </div>

        {clips.some((c) => c.trackIndex === 1) && (
          <div className="timeline-track audio-track">
            <div className="track-label">Audio</div>
            <div className="track-clips">
              {clips
                .filter((c) => c.trackIndex === 1)
                .map((clip, index) => {
                  const width = ((clip.endTime - clip.startTime) / totalDuration) * 100;
                  const left = (clip.startTime / totalDuration) * 100;

                  return (
                    <div
                      key={`audio-${index}`}
                      className="preview-clip audio"
                      style={{ width: `${width}%`, left: `${left}%` }}
                    />
                  );
                })}
            </div>
          </div>
        )}

        {textOverlays.length > 0 && (
          <div className="timeline-track text-track">
            <div className="track-label">Text</div>
            <div className="track-clips">
              {textOverlays.map((overlay, index) => {
                const width = ((overlay.endTime - overlay.startTime) / totalDuration) * 100;
                const left = (overlay.startTime / totalDuration) * 100;

                return (
                  <div
                    key={`text-${index}`}
                    className="preview-clip text"
                    style={{ width: `${width}%`, left: `${left}%` }}
                    title={overlay.text}
                  >
                    <span className="text-label">{overlay.text.substring(0, 15)}...</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <div className="timeline-ruler">
          {Array.from({ length: Math.ceil(totalDuration / 10) + 1 }).map((_, i) => (
            <div
              key={i}
              className="ruler-mark"
              style={{ left: `${(i * 10 / totalDuration) * 100}%` }}
            >
              <span>{formatDuration(i * 10)}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="effects-list">
        {effects.length > 0 && (
          <div className="effects-section">
            <h4>Applied Effects</h4>
            <ul>
              {effects.map((effect, index) => (
                <li key={index}>
                  <strong>{effect.type}</strong>: {formatDuration(effect.startTime)} -{' '}
                  {formatDuration(effect.endTime)}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
