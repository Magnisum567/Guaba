import { useMemo } from 'react';
import { useTextToEditStore } from '../../../stores';
import type { ClipSuggestion } from '../../../types';

export function ClipGrid() {
  const { suggestions, toggleClipSelection, swapClip, reorderClips } = useTextToEditStore();

  const selectedCount = useMemo(
    () => suggestions.filter((s) => s.isSelected).length,
    [suggestions]
  );

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleDragStart = (e: React.DragEvent, index: number) => {
    e.dataTransfer.setData('text/plain', index.toString());
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent, toIndex: number) => {
    e.preventDefault();
    const fromIndex = parseInt(e.dataTransfer.getData('text/plain'));
    if (fromIndex !== toIndex) {
      reorderClips(fromIndex, toIndex);
    }
  };

  const handleSwapWithAlternative = (index: number, alt: ClipSuggestion) => {
    swapClip(index, alt);
  };

  if (suggestions.length === 0) {
    return (
      <div className="clip-grid-empty">
        <p>No clips found matching your criteria.</p>
        <p>Try adjusting your prompt or editing options.</p>
      </div>
    );
  }

  return (
    <div className="clip-grid-container">
      <div className="clip-grid-header">
        <h3>Suggested Clips</h3>
        <span className="selection-count">
          {selectedCount} of {suggestions.length} selected
        </span>
      </div>

      <p className="clip-grid-instructions">
        Drag to reorder. Click checkbox to include/exclude. Click alternatives to swap.
      </p>

      <div className="clip-grid">
        {suggestions.map((suggestion, index) => (
          <div
            key={`${suggestion.mediaAssetId}-${index}`}
            className={`clip-card ${suggestion.isSelected ? 'selected' : ''}`}
            draggable
            onDragStart={(e) => handleDragStart(e, index)}
            onDragOver={handleDragOver}
            onDrop={(e) => handleDrop(e, index)}
          >
            <div className="clip-order">{index + 1}</div>

            <div className="clip-checkbox">
              <input
                type="checkbox"
                checked={suggestion.isSelected}
                onChange={() => toggleClipSelection(index)}
                id={`clip-${index}`}
              />
              <label htmlFor={`clip-${index}`} />
            </div>

            <div className="clip-thumbnail">
              {suggestion.thumbnailUrl ? (
                <img src={suggestion.thumbnailUrl} alt={suggestion.mediaAsset?.originalName || 'Clip'} />
              ) : (
                <div className="thumbnail-placeholder">
                  <span>No Preview</span>
                </div>
              )}
              <div className="clip-duration">
                {formatDuration(suggestion.endTime - suggestion.startTime)}
              </div>
            </div>

            <div className="clip-info">
              <div className="clip-name">
                {suggestion.mediaAsset?.originalName || 'Untitled Clip'}
              </div>
              <div className="clip-time">
                {formatDuration(suggestion.startTime)} - {formatDuration(suggestion.endTime)}
              </div>
              <div className="clip-reason">{suggestion.reason}</div>
              <div className="clip-score">
                Score: {Math.round(suggestion.score * 100)}%
              </div>
            </div>

            {suggestion.alternatives && suggestion.alternatives.length > 0 && (
              <div className="clip-alternatives">
                <span className="alternatives-label">Alternatives:</span>
                <div className="alternatives-list">
                  {suggestion.alternatives.slice(0, 3).map((alt, altIndex) => (
                    <button
                      key={`alt-${altIndex}`}
                      className="alternative-button"
                      onClick={() => handleSwapWithAlternative(index, alt)}
                      title={alt.reason}
                    >
                      {alt.thumbnailUrl ? (
                        <img src={alt.thumbnailUrl} alt="Alternative" />
                      ) : (
                        <span>Alt {altIndex + 1}</span>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
