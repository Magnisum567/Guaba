import { useEffect } from 'react';
import { useTextToEditStore } from '../../../stores';
import { useProjectStore } from '../../../stores';
import { PromptInput } from './PromptInput';
import { ClipGrid } from './ClipGrid';
import { ApprovalTimeline } from './ApprovalTimeline';
import { EditingOptions } from './EditingOptions';
import './TextToEdit.css';

export function TextToEditModal() {
  const {
    isOpen,
    step,
    isLoading,
    error,
    parsedPrompt,
    closeModal,
    reset,
    parsePrompt,
    generateDraft,
    applyEdits,
    clearError,
  } = useTextToEditStore();

  const { currentProject } = useProjectStore();

  // Close on Escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        closeModal();
      }
    };
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [isOpen, closeModal]);

  if (!isOpen) return null;

  const projectId = currentProject?.id;

  const handleParsePrompt = async () => {
    if (projectId) {
      await parsePrompt(projectId);
    }
  };

  const handleGenerateDraft = async () => {
    if (projectId) {
      await generateDraft(projectId);
    }
  };

  const handleApplyEdits = async () => {
    if (projectId) {
      await applyEdits(projectId);
    }
  };

  const handleBack = () => {
    if (step === 'suggesting') {
      reset();
    } else if (step === 'previewing') {
      useTextToEditStore.setState({ step: 'suggesting', draftTimeline: null, previewUrl: null });
    }
  };

  const renderStepIndicator = () => {
    const steps = [
      { key: 'idle', label: 'Enter Prompt' },
      { key: 'suggesting', label: 'Review Clips' },
      { key: 'previewing', label: 'Preview & Apply' },
    ];

    const currentIndex = steps.findIndex((s) => s.key === step || (step === 'parsing' && s.key === 'idle'));

    return (
      <div className="step-indicator">
        {steps.map((s, index) => (
          <div
            key={s.key}
            className={`step ${index <= currentIndex ? 'active' : ''} ${index < currentIndex ? 'completed' : ''}`}
          >
            <span className="step-number">{index + 1}</span>
            <span className="step-label">{s.label}</span>
          </div>
        ))}
      </div>
    );
  };

  const renderContent = () => {
    switch (step) {
      case 'idle':
      case 'parsing':
        return (
          <div className="text-to-edit-content">
            <PromptInput />
            <EditingOptions />
            <div className="action-buttons">
              <button className="btn-secondary" onClick={closeModal}>
                Cancel
              </button>
              <button
                className="btn-primary"
                onClick={handleParsePrompt}
                disabled={isLoading}
              >
                {isLoading ? 'Analyzing...' : 'Analyze Prompt'}
              </button>
            </div>
          </div>
        );

      case 'suggesting':
        return (
          <div className="text-to-edit-content">
            {parsedPrompt && (
              <div className="parsed-intent">
                <strong>Detected Intent:</strong> {parsedPrompt.intent.replace('_', ' ')}
                {parsedPrompt.parameters.targetDuration && (
                  <span> - Target: {parsedPrompt.parameters.targetDuration}s</span>
                )}
              </div>
            )}
            <ClipGrid />
            <div className="action-buttons">
              <button className="btn-secondary" onClick={handleBack}>
                Back
              </button>
              <button
                className="btn-primary"
                onClick={handleGenerateDraft}
                disabled={isLoading}
              >
                {isLoading ? 'Generating...' : 'Generate Draft'}
              </button>
            </div>
          </div>
        );

      case 'previewing':
      case 'applying':
        return (
          <div className="text-to-edit-content">
            <ApprovalTimeline />
            <div className="action-buttons">
              <button className="btn-secondary" onClick={handleBack} disabled={isLoading}>
                Back
              </button>
              <button
                className="btn-primary"
                onClick={handleApplyEdits}
                disabled={isLoading}
              >
                {isLoading ? 'Applying...' : 'Apply to Timeline'}
              </button>
            </div>
          </div>
        );

      case 'complete':
        return (
          <div className="text-to-edit-content success-content">
            <div className="success-icon">&#10003;</div>
            <h3>Edits Applied Successfully!</h3>
            <p>Your timeline has been updated with the AI-generated edits.</p>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="modal-overlay" onClick={closeModal}>
      <div className="text-to-edit-modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Text-to-Edit</h2>
          <button className="close-button" onClick={closeModal}>
            &times;
          </button>
        </div>

        {renderStepIndicator()}

        {error && (
          <div className="error-banner">
            <span>{error}</span>
            <button onClick={clearError}>&times;</button>
          </div>
        )}

        {renderContent()}
      </div>
    </div>
  );
}
