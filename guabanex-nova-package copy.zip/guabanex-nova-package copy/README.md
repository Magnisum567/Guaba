# Guabanex Nova - AI Video Editor

## Quick Start

### Development Mode
```bash
npm install
npm run dev
```
Then open http://localhost:5173

### Production Build
The `dist/` folder contains the production build. To serve it:
```bash
npx serve dist
```

## Features

### Core Editor
- **Video Editor** - Timeline with tracks and clips
- **Color Grading** - Exposure, brightness, contrast, saturation, highlights, shadows, etc.
- **LUT Support** - Preset and custom LUT files
- **Offline Support** - Works without backend using local blob URLs
- **Modern UI** - Sleek, dark theme design

### AI-Powered Features

#### AI Analysis Cache
- Scene detection with object/action recognition
- Emotion analysis with face detection
- Style matching with color palette extraction
- Results cached in localStorage (24-hour TTL)

#### AI Clip Suggestions
- Intelligent clip placement and ordering
- Automatic categorization (highlight, b-roll, transition, opening, closing)
- Confidence scoring for each suggestion
- Smart tagging based on content analysis

#### Scene Detection
- Automatic boundary detection
- Shot classification (wide, medium, close-up, etc.)
- Camera movement detection (static, pan, tilt, tracking, etc.)

#### Pacing Analysis
- Overall pace assessment (slow, moderate, fast, dynamic)
- Average shot duration calculation
- Rhythm scoring
- Energy curve visualization
- Gap and long clip detection with suggestions

#### Intelligent Cut Detection
- Frame-perfect edit suggestions
- Trim recommendations (start/end)
- Split point detection
- Content-aware cut suggestions

#### Transition Intelligence
- AI-generated transition recommendations
- Context matching scores
- Multiple transition types (cut, dissolve, fade, wipe, etc.)

#### Cinematic Style Matching
Over 20 film/director styles including:

**Directors:**
- Wes Anderson (pastel colors, symmetry)
- David Fincher (dark, desaturated, green shadows)
- Christopher Nolan (natural, deep blacks, IMAX clarity)
- Denis Villeneuve (atmospheric, muted, orange/teal)
- Quentin Tarantino (vibrant, warm, 70s aesthetic)
- Wong Kar-wai (dreamlike, neon, romantic)

**Films:**
- Blade Runner (1982) - Cyberpunk noir, neon blues
- Blade Runner 2049 - Orange/teal extremes
- Mad Max: Fury Road - Extreme saturation, desert tones
- The Matrix - Green tint, digital aesthetic
- Amélie - Golden green, whimsical
- Moonlight - Deep blues, rich skin tones
- La La Land - Vivid, golden hour glamour
- Joker - Gritty 70s, green/yellow
- Dune - Desert orange, epic atmosphere

**Genres & Moods:**
- Film Noir, Horror, Sci-Fi, Romantic Comedy
- Golden Hour, Blue Hour, Moody & Dark, Bright & Airy
- Vintage 70s, 80s Neon

## Project Structure

```
src/
├── api.ts              # API client
├── App.tsx             # Main app with routing
├── App.css             # Global styles
├── components/
│   ├── auth/           # Login, Register forms
│   ├── dashboard/      # Project cards, grid
│   └── editor/
│       ├── AISuggestions/  # AI clip, pacing, style suggestions
│       ├── Properties/     # Color grading, transform, audio, AI tabs
│       ├── VideoPlayer/
│       ├── Timeline/
│       └── MediaLibrary/
├── pages/
│   └── EditorPage.tsx  # Main editor page
├── stores/             # Zustand state management
│   ├── timelineStore.ts
│   ├── mediaStore.ts
│   ├── aiAnalysisStore.ts
│   ├── aiEditingStore.ts
│   ├── aiColorGradingStore.ts
│   └── ...
└── types/
    └── index.ts        # TypeScript interfaces
```

## Requirements

- Node.js 18+
- Backend API on http://localhost:3001 (optional - works with mock data)
